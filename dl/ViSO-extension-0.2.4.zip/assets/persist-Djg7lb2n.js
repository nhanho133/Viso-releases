import { t as log } from "./log-BabVsn0h.js";
//#region src/offscreen/persist.ts
/**
* Asking the browser not to throw the user's memories away.
*
* OPFS defaults to *best-effort* storage. That word is doing a lot of work: it
* means Chrome may delete the entire database, without warning and without
* asking, when the disk gets tight. For a tool whose whole proposition is
* "write it here instead of on paper", silent deletion is not a bug class it
* can afford to be exposed to.
*
* Two things move the needle, and both are needed:
*
*  1. The `unlimitedStorage` permission, which exempts an extension's data from
*     the eviction quota. That is declared in the manifest.
*  2. `navigator.storage.persist()`, which marks the origin persistent. This is
*     a Window-only API — it does not exist in the worker where the database
*     actually lives — so it is called here, in the offscreen document, which
*     is the only Window ViSO reliably has.
*
* The result is recorded rather than assumed. "We asked for persistence" and
* "we have persistence" are different facts, and the Agent Hub tells the user
* which one is true so that a backup stops being optional advice when it isn't.
*
* Recording goes through a message rather than `chrome.storage` directly: an
* offscreen document is granted `chrome.runtime` and almost nothing else, so
* `chrome.storage` is undefined here. Writing to it threw on the very first
* run in a real browser.
*/
var PERSIST_STATE_KEY = "viso:storage-persisted";
async function ensurePersistentStorage() {
	const state = await requestPersistence();
	try {
		await chrome.runtime.sendMessage({
			type: "viso/persist-state",
			state
		});
	} catch (error) {
		log.warn("could not report the persistence result", describe(error));
	}
	if (state.persisted) log.info("storage is persistent", JSON.stringify(state));
	else if (isExempt(state)) log.info("storage is exempt from eviction (unlimitedStorage)", JSON.stringify(state));
	else log.warn("storage is best-effort: Chrome may evict the ViSO database", JSON.stringify(state));
	return state;
}
/**
* True when `unlimitedStorage` is doing the job `persist()` declined to.
*
* A constant, not a question asked at runtime. Two ways of asking have now
* been wrong on a real machine: the quota (hundreds of gigabytes means exempt
* — false on a laptop with a small disk, which reported 6.7GB) and then
* `chrome.runtime.getManifest()` from the offscreen document, which still left
* a tester staring at "Chrome may evict the ViSO database" on a healthy
* install. The permission is declared in manifest.config.ts for every build of
* ViSO; the only state genuinely at risk is one where the storage API could
* not be reached at all, and that one carries an `error`.
*/
function isExempt(state) {
	return state.error === void 0;
}
async function requestPersistence() {
	const checkedAt = Date.now();
	const storage = navigator.storage;
	if (storage?.persisted === void 0) return {
		persisted: false,
		quota: null,
		usage: null,
		checkedAt,
		error: "navigator.storage không khả dụng"
	};
	const measured = await measure(storage);
	try {
		if (await storage.persisted()) return {
			persisted: true,
			...measured,
			checkedAt
		};
		if (storage.persist === void 0) return {
			persisted: false,
			...measured,
			checkedAt,
			error: "persist() không có trong ngữ cảnh này"
		};
		return {
			persisted: await storage.persist(),
			...measured,
			checkedAt
		};
	} catch (error) {
		return {
			persisted: false,
			...measured,
			checkedAt,
			error: describe(error)
		};
	}
}
async function measure(storage) {
	try {
		const estimate = await storage.estimate();
		return {
			quota: estimate.quota ?? null,
			usage: estimate.usage ?? null
		};
	} catch {
		return {
			quota: null,
			usage: null
		};
	}
}
function describe(error) {
	return error instanceof Error ? error.message : String(error);
}
/**
* What was recorded last time.
*
* Callable only from a context that has `chrome.storage` — the Agent Hub and
* the service worker, not the offscreen document that produced the value.
*/
async function readPersistState() {
	try {
		const value = (await chrome.storage.local.get(PERSIST_STATE_KEY))[PERSIST_STATE_KEY];
		if (typeof value !== "object" || value === null) return null;
		return value;
	} catch {
		return null;
	}
}
//#endregion
export { readPersistState as i, ensurePersistentStorage as n, isExempt as r, PERSIST_STATE_KEY as t };
