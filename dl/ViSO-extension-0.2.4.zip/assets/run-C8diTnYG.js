import { t as parseQuery } from "./parse-fgDs-rmF.js";
//#region src/query/run.ts
var LIMIT = 25;
async function runQuery(raw, context, deps) {
	const spec = parseQuery(raw);
	const vector = spec.empty ? null : await deps.embedQuery(spec.text);
	return {
		hits: await deps.search({
			vector,
			terms: spec.terms,
			people: spec.people,
			from: spec.from,
			to: spec.to,
			context_hash: spec.scope === "page" ? context.context_hash : null,
			source_host: spec.scope === "host" ? context.source_host : null,
			intent: spec.intent,
			recent_only: spec.empty,
			limit: LIMIT
		}),
		spec,
		semantic: vector !== null
	};
}
/**
* One line saying what was actually searched.
*
* Shown above the results because the filters are inferred, not typed: a user
* who said "tuần trước" and gets three results deserves to see that the other
* twelve were excluded by a date range, not that they do not exist.
*/
function describeQuery(spec, count) {
	const parts = [];
	if (spec.windowLabel !== null) parts.push(spec.windowLabel);
	if (spec.scope === "page") parts.push("trên trang này");
	if (spec.scope === "host") parts.push("trên web này");
	if (spec.intent === "REMINDER") parts.push("lời nhắc");
	if (spec.intent === "TASK") parts.push("việc cần làm");
	if (spec.people.length > 0) parts.push(spec.people.join(", "));
	const scope = parts.length === 0 ? "" : ` · ${parts.join(" · ")}`;
	return count === 0 ? `Không có ghi chú nào${scope}` : `${count} ghi chú${scope}`;
}
//#endregion
export { runQuery as n, describeQuery as t };
