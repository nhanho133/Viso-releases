//#region src/content/ui/icons.ts
/**
* Line icons for the HUD, built as SVG nodes.
*
* Not an icon font and not innerHTML: Gmail enforces Trusted Types, which turns
* every HTML-string sink into an exception, and a font would be a network
* request from inside somebody else's page. Paths set through setAttribute are
* neither.
*/
var SVG_NS = "http://www.w3.org/2000/svg";
var PATHS = {
	note: [
		"M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z",
		"M14 3v5h5",
		"M9 13h6",
		"M9 17h4"
	],
	bell: ["M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9", "M13.7 21a2 2 0 0 1-3.4 0"],
	task: ["M9 11l3 3L21 5", "M20 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h11"],
	quote: ["M4 11h5V5H4v6c0 3 1 5 4 6", "M14 11h5V5h-5v6c0 3 1 5 4 6"],
	search: ["M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z", "M20 20l-4-4"],
	close: ["M6 6l12 12", "M18 6L6 18"],
	mic: [
		"M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z",
		"M19 11a7 7 0 0 1-14 0",
		"M12 18v3"
	],
	pencil: ["M12 20h9", "M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"],
	trash: [
		"M3 6h18",
		"M8 6V4h8v2",
		"M19 6l-1 14H6L5 6"
	],
	minus: ["M5 12h14"],
	chevron: ["M6 9l6 6 6-6"],
	external: [
		"M14 4h6v6",
		"M20 4l-9 9",
		"M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"
	],
	folder: ["M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"],
	calendar: [
		"M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z",
		"M4 10h16",
		"M8 2v4",
		"M16 2v4"
	],
	chevronLeft: ["M15 6l-6 6 6 6"],
	chevronRight: ["M9 6l6 6-6 6"],
	check: ["M5 12l5 5L20 7"],
	more: [
		"M5 12h.01",
		"M12 12h.01",
		"M19 12h.01"
	],
	plus: ["M12 5v14", "M5 12h14"],
	tag: ["M20 12l-8 8-9-9V4h7l10 8z", "M7.5 7.5h.01"],
	view: [
		"M4 6h16",
		"M4 12h16",
		"M4 18h10",
		"M17 15l3 3-3 3"
	],
	eye: ["M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z", "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"],
	"eye-off": [
		"M3 3l18 18",
		"M10.6 5.2A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4",
		"M6.6 6.6C3.6 8.5 2 12 2 12s3.5 7 10 7c1.6 0 3-.3 4.3-.9",
		"M9.9 9.9a3 3 0 0 0 4.2 4.2"
	],
	edge: [
		"M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z",
		"M17 5v14",
		"M20 12h-3"
	],
	sparkle: ["M12 3c.6 5 3.4 7.8 9 9-5.6 1.2-8.4 4-9 9-.6-5-3.4-7.8-9-9 5.6-1.2 8.4-4 9-9z"],
	gear: ["M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z", "M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"]
};
function icon(name, size = 18) {
	const svg = document.createElementNS(SVG_NS, "svg");
	svg.setAttribute("viewBox", "0 0 24 24");
	svg.setAttribute("width", String(size));
	svg.setAttribute("height", String(size));
	svg.setAttribute("fill", "none");
	svg.setAttribute("stroke", "currentColor");
	svg.setAttribute("stroke-width", "1.8");
	svg.setAttribute("stroke-linecap", "round");
	svg.setAttribute("stroke-linejoin", "round");
	svg.setAttribute("aria-hidden", "true");
	svg.setAttribute("focusable", "false");
	for (const d of PATHS[name]) {
		const path = document.createElementNS(SVG_NS, "path");
		path.setAttribute("d", d);
		svg.append(path);
	}
	return svg;
}
var decorSeq = 0;
/** A four-point star centred on (cx, cy), `r` from centre to tip. */
function starPath(cx, cy, r) {
	const w = r * .22;
	return [
		`M${cx} ${cy - r}`,
		`C${cx + w * .6} ${cy - w * 2} ${cx + w * 2} ${cy - w * .6} ${cx + r} ${cy}`,
		`C${cx + w * 2} ${cy + w * .6} ${cx + w * .6} ${cy + w * 2} ${cx} ${cy + r}`,
		`C${cx - w * .6} ${cy + w * 2} ${cx - w * 2} ${cy + w * .6} ${cx - r} ${cy}`,
		`C${cx - w * 2} ${cy - w * .6} ${cx - w * .6} ${cy - w * 2} ${cx} ${cy - r}`,
		"Z"
	].join(" ");
}
function starFill(svg, id) {
	const defs = document.createElementNS(SVG_NS, "defs");
	const grad = document.createElementNS(SVG_NS, "radialGradient");
	grad.setAttribute("id", id);
	for (const [offset, color] of [
		["0", "#ffffff"],
		["0.45", "#fff3b0"],
		["1", "#f2cf5b"]
	]) {
		const stop = document.createElementNS(SVG_NS, "stop");
		stop.setAttribute("offset", offset);
		stop.setAttribute("stop-color", color);
		grad.append(stop);
	}
	defs.append(grad);
	svg.append(defs);
}
/** One star, gold with a white heart. */
function star(size = 16, className = "") {
	const svg = document.createElementNS(SVG_NS, "svg");
	svg.setAttribute("viewBox", "0 0 24 24");
	svg.setAttribute("width", String(size));
	svg.setAttribute("height", String(size));
	svg.setAttribute("aria-hidden", "true");
	svg.setAttribute("focusable", "false");
	if (className !== "") svg.setAttribute("class", className);
	const id = `viso-star-${++decorSeq}`;
	starFill(svg, id);
	const path = document.createElementNS(SVG_NS, "path");
	path.setAttribute("d", starPath(12, 12, 11));
	path.setAttribute("fill", `url(#${id})`);
	svg.append(path);
	return svg;
}
/**
* A star with a long thin tail. `up-right`: the star sits left and the tail
* thins away to a dot (the title's). `down-left`: the star sits top-right and
* the tail falls away (the cards').
*/
function comet(width, tail, className = "") {
	const svg = document.createElementNS(SVG_NS, "svg");
	svg.setAttribute("viewBox", "0 0 120 50");
	svg.setAttribute("width", String(width));
	svg.setAttribute("height", String(Math.round(width * .42)));
	svg.setAttribute("aria-hidden", "true");
	svg.setAttribute("focusable", "false");
	svg.setAttribute("overflow", "visible");
	if (className !== "") svg.setAttribute("class", className);
	const starAt = tail === "up-right" ? {
		x: 16,
		y: 34
	} : {
		x: 104,
		y: 14
	};
	const end = tail === "up-right" ? {
		x: 116,
		y: 4
	} : {
		x: 4,
		y: 48
	};
	const from = tail === "up-right" ? {
		x: starAt.x + 12,
		y: starAt.y - 5
	} : {
		x: starAt.x - 12,
		y: starAt.y + 5
	};
	const id = `viso-comet-${++decorSeq}`;
	starFill(svg, `${id}-s`);
	const defs = svg.querySelector("defs");
	const grad = document.createElementNS(SVG_NS, "linearGradient");
	grad.setAttribute("id", `${id}-t`);
	grad.setAttribute("gradientUnits", "userSpaceOnUse");
	grad.setAttribute("x1", String(from.x));
	grad.setAttribute("y1", String(from.y));
	grad.setAttribute("x2", String(end.x));
	grad.setAttribute("y2", String(end.y));
	for (const [offset, opacity] of [
		["0", "0.95"],
		["0.7", "0.35"],
		["1", "0"]
	]) {
		const stop = document.createElementNS(SVG_NS, "stop");
		stop.setAttribute("offset", offset);
		stop.setAttribute("stop-color", "#ffffff");
		stop.setAttribute("stop-opacity", opacity);
		grad.append(stop);
	}
	defs.append(grad);
	const line = document.createElementNS(SVG_NS, "path");
	line.setAttribute("d", `M${from.x} ${from.y} L${end.x} ${end.y}`);
	line.setAttribute("stroke", `url(#${id}-t)`);
	line.setAttribute("stroke-width", "2.4");
	line.setAttribute("stroke-linecap", "round");
	svg.append(line);
	if (tail === "up-right") {
		const dot = document.createElementNS(SVG_NS, "circle");
		dot.setAttribute("cx", String(end.x));
		dot.setAttribute("cy", String(end.y));
		dot.setAttribute("r", "1.6");
		dot.setAttribute("fill", "#ffffff");
		svg.append(dot);
	}
	const path = document.createElementNS(SVG_NS, "path");
	path.setAttribute("d", starPath(starAt.x, starAt.y, 13));
	path.setAttribute("fill", `url(#${id}-s)`);
	svg.append(path);
	return svg;
}
//#endregion
export { icon as n, star as r, comet as t };
