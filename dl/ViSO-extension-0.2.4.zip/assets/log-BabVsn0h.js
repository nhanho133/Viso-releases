//#region src/shared/log.ts
/**
* Namespaced logger. ViSO runs on every page the user visits, so console noise
* is a real cost — everything below `warn` is off unless explicitly enabled.
*
* Two switches, because the contexts differ:
*
*   page / content script:  localStorage.setItem('viso:debug', '1')
*   service worker, workers, offscreen:  globalThis.__visoDebug = true
*
* The second exists because a service worker has no `localStorage` at all —
* reading it there throws, which would have left every background `log.debug`
* permanently silent exactly where it is hardest to debug without them.
*/
var PREFIX = "[ViSO]";
function debugEnabled() {
	if (globalThis.__visoDebug === true) return true;
	try {
		return typeof localStorage !== "undefined" && localStorage.getItem("viso:debug") === "1";
	} catch {
		return false;
	}
}
var log = {
	debug(...args) {
		if (debugEnabled()) console.debug(PREFIX, ...args);
	},
	info(...args) {
		if (debugEnabled()) console.info(PREFIX, ...args);
	},
	warn(...args) {
		console.warn(PREFIX, ...args);
	},
	error(...args) {
		console.error(PREFIX, ...args);
	}
};
//#endregion
export { log as t };
