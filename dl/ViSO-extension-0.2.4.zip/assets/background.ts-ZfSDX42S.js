import { t as log } from "./log-BabVsn0h.js";
import { t as PERSIST_STATE_KEY } from "./persist-Djg7lb2n.js";
import { n as parseWhen } from "./parse-fgDs-rmF.js";
import { n as runQuery$1, t as describeQuery } from "./run-C8diTnYG.js";
import { _ as isContentRequest, a as scopeFor, c as classifyIntent, d as hostLabel, f as sourceLabel, h as envelope, i as PER_FILE_PLATFORMS, n as EXTRACT_CONFIG, o as scopeLabel, r as samePage, s as readTyped, u as nextOccurrence } from "./config-B2gP0ogj.js";
//#region src/background/db-client.ts
/**
* Typed access to the memory store from the background service worker.
*
* Every call goes: background -> offscreen document -> db worker -> SQLite. The
* offscreen document is created lazily on first use and reused afterwards.
*/
var OFFSCREEN_PATH = "src/offscreen/offscreen.html";
var ensuring = null;
async function hasOffscreenDocument() {
	return (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length > 0;
}
async function createOffscreenDocument() {
	try {
		await chrome.offscreen.createDocument({
			url: OFFSCREEN_PATH,
			reasons: [chrome.offscreen.Reason.WORKERS, chrome.offscreen.Reason.USER_MEDIA],
			justification: "Hosts the local memory store and speech model in dedicated workers, and captures microphone audio for on-device transcription."
		});
	} catch (error) {
		if (await hasOffscreenDocument()) return;
		throw error;
	}
}
/** Single-flight so concurrent first calls create exactly one document. */
function ensureOffscreenDocument() {
	ensuring ??= (async () => {
		if (!await hasOffscreenDocument()) await createOffscreenDocument();
	})().finally(() => {
		ensuring = null;
	});
	return ensuring;
}
/**
* Sends one request to the store.
*
* Throws on failure rather than returning null: unlike a UI ping, a dropped
* write is not something a caller should be able to ignore by accident.
*/
async function db(request) {
	const result = await callOffscreen("viso/db", request);
	if (WRITE_OPS.has(request.op)) notifyWrite();
	return result;
}
/**
* Operations that change what a note says or whether it is listed.
*
* Vectors, surfacing counters and feedback are left out: none of them is part
* of what anyone outside the store is shown.
*/
var WRITE_OPS = /* @__PURE__ */ new Set([
	"insert",
	"update",
	"delete",
	"dismiss",
	"setNoteGroup"
]);
var writeListeners = /* @__PURE__ */ new Set();
/**
* Called after every successful write, whichever path made it.
*
* One hook here rather than a call at each save, edit, delete, undo and import:
* the Agent Hub also writes through `db`, and a list of call sites is a list of
* places to forget one.
*/
function onStoreWrite(listener) {
	writeListeners.add(listener);
	return () => writeListeners.delete(listener);
}
function notifyWrite() {
	for (const listener of writeListeners) try {
		listener();
	} catch (error) {
		log.warn("store write listener threw", error);
	}
}
/**
* Sends one request to the embedding worker.
*
* `load` can take minutes on first use — it downloads ~135MB — so callers are
* expected to have obtained the user's consent before invoking it.
*/
async function embed(request) {
	return callOffscreen("viso/embed", request);
}
async function callOffscreen(type, request) {
	await ensureOffscreenDocument();
	const reply = await chrome.runtime.sendMessage({
		type,
		target: "offscreen",
		request
	});
	if (typeof reply !== "object" || reply === null) throw new Error(`${type}(${request.op}): no reply from offscreen document`);
	const r = reply;
	if (r.ok !== true) {
		log.error("offscreen call failed", type, request.op, r.error);
		throw new Error(r.error ?? `${type}(${request.op}) failed`);
	}
	return r.result;
}
//#endregion
//#region src/shared/extensionIdentity.ts
/**
* The Native Messaging host the desktop app registers.
*
* Chrome requires lowercase letters, digits, underscores and dots.
*/
var NATIVE_HOST_NAME = "com.viso.bridge";
//#endregion
//#region src/shared/desktopSnapshot.ts
/** chrome.storage.local key holding the last sync outcome, for the Agent Hub. */
var DESKTOP_SYNC_STATUS_KEY = "viso:desktop-sync";
function toSnapshotNote(row) {
	return {
		uid: `ext:${row.id}`,
		text: row.text,
		intent: row.intent,
		createdAt: row.created_at,
		sourceUrl: row.source_url,
		deepLink: row.deep_link ?? row.source_url,
		sourceTitle: row.source_title,
		sourceLabel: sourceLabel(row.platform_type, row.source_url),
		selection: row.selection,
		remindAt: row.remind_at,
		groupName: row.group_name
	};
}
/** Favicons travel as data URLs; chunked so a large icon does not blow the call stack. */
function bytesToBase64(bytes) {
	const CHUNK = 32768;
	let binary = "";
	for (let i = 0; i < bytes.length; i += CHUNK) binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
	return btoa(binary);
}
/**
* Turns Chrome's Native Messaging error text into something the Hub can act on.
*
* Matched on Chrome's own wording, which is stable but not an API; anything
* unrecognised is reported as a plain error with the message kept.
*/
function classifyNativeError(message) {
	const m = message.toLowerCase();
	if (m.includes("host not found")) return "not-installed";
	if (m.includes("forbidden")) return "forbidden";
	if (m.includes("native host has exited") || m.includes("communicating with the native messaging host")) return "host-error";
	return "error";
}
//#endregion
//#region src/background/desktopSync.ts
/**
* Sends the note list to the ViSO desktop app over Native Messaging.
*
* Triggered by every write to the store and on browser start, and gathered: a
* voice note that saves, embeds and schedules a reminder is several writes in
* a second, and one snapshot after they settle says the same thing as five.
*
* Absence of the desktop app is the normal case and is not logged as a
* failure. It is recorded, so the Agent Hub can say what state the connection
* is in instead of leaving the user to guess.
*/
var DEBOUNCE_MS = 2e3;
var PAGE = 200;
/** Enough for every site a person keeps notes on; a ceiling so a runaway list cannot bloat the send. */
var MAX_FAVICONS = 300;
var timer = null;
var running$1 = null;
var pendingAgain = false;
function scheduleDesktopSync() {
	if (timer !== null) clearTimeout(timer);
	timer = setTimeout(() => {
		timer = null;
		syncDesktopNow();
	}, DEBOUNCE_MS);
}
/**
* Sends a snapshot now.
*
* Single-flight: a write that lands during a send is not lost, it schedules one
* more send after this one, so the desktop always ends on the latest list.
*/
function syncDesktopNow() {
	if (running$1 !== null) {
		pendingAgain = true;
		return running$1;
	}
	running$1 = syncOnce().finally(() => {
		running$1 = null;
		if (pendingAgain) {
			pendingAgain = false;
			scheduleDesktopSync();
		}
	});
	return running$1;
}
async function desktopSyncStatus() {
	try {
		const value = (await chrome.storage.local.get(DESKTOP_SYNC_STATUS_KEY))[DESKTOP_SYNC_STATUS_KEY];
		if (value !== void 0) return value;
	} catch {}
	return {
		state: "never",
		at: 0,
		count: 0
	};
}
async function syncOnce() {
	let snapshot;
	try {
		snapshot = await buildSnapshot();
	} catch (error) {
		return record({
			state: "error",
			at: Date.now(),
			count: 0,
			error: describe$1(error)
		});
	}
	try {
		const reply = await chrome.runtime.sendNativeMessage(NATIVE_HOST_NAME, snapshot);
		if (reply?.ok === true) return record({
			state: "ok",
			at: Date.now(),
			count: snapshot.notes.length
		});
		return record({
			state: "host-error",
			at: Date.now(),
			count: 0,
			error: reply?.error ?? "không có phản hồi"
		});
	} catch (error) {
		const message = describe$1(error);
		return record({
			state: classifyNativeError(message),
			at: Date.now(),
			count: 0,
			error: message
		});
	}
}
async function buildSnapshot() {
	const rows = [];
	for (let offset = 0;; offset += PAGE) {
		const page = await db({
			op: "list",
			query: {
				limit: PAGE,
				offset
			}
		});
		rows.push(...page);
		if (page.length < PAGE) break;
	}
	const favicons = {};
	const pageForHost = /* @__PURE__ */ new Map();
	for (const row of rows) {
		const host = hostLabel(row.source_url);
		if (host !== null && row.source_url !== null && !pageForHost.has(host)) pageForHost.set(host, row.source_url);
		if (pageForHost.size >= MAX_FAVICONS) break;
	}
	await Promise.all([...pageForHost].map(async ([host, pageUrl]) => {
		const dataUrl = await faviconDataUrl(pageUrl);
		if (dataUrl !== null) favicons[host] = dataUrl;
	}));
	return {
		type: "viso/snapshot",
		version: 1,
		sentAt: Date.now(),
		notes: rows.map(toSnapshotNote),
		favicons
	};
}
/** Chrome's cached icon for a page, as a data URL, or null when it has none to give. */
async function faviconDataUrl(pageUrl) {
	try {
		const url = new URL(chrome.runtime.getURL("/_favicon/"));
		url.searchParams.set("pageUrl", pageUrl);
		url.searchParams.set("size", "32");
		const response = await fetch(url.toString());
		if (!response.ok) return null;
		const bytes = new Uint8Array(await response.arrayBuffer());
		if (bytes.length === 0) return null;
		return `data:${response.headers.get("content-type") ?? "image/png"};base64,${bytesToBase64(bytes)}`;
	} catch {
		return null;
	}
}
async function record(status) {
	if (status.state === "ok") log.info(`sent ${status.count} note(s) to the desktop app`);
	else if (status.state === "not-installed") log.debug("desktop app not installed; nothing sent");
	else log.warn("desktop sync failed", status.state, status.error);
	try {
		await chrome.storage.local.set({ [DESKTOP_SYNC_STATUS_KEY]: status });
	} catch {}
	return status;
}
function describe$1(error) {
	return error instanceof Error ? error.message : String(error);
}
//#endregion
//#region src/background/reminders.ts
/**
* Reminders (spec §4.4 intent REMINDER).
*
* One alarm at a time, always for the soonest reminder still ahead. MV3 caps
* how many alarms an extension may hold and recycles the service worker
* freely, so scheduling one per reminder would be both wasteful and fragile —
* whereas a single alarm rescheduled after each firing survives any number of
* restarts, because the schedule lives in the database rather than in memory.
*/
var ALARM = "viso:reminder";
/** Chrome refuses alarms under a minute; sooner than that fires immediately. */
var MIN_DELAY_MS = 6e4;
/**
* Points the alarm at the next reminder due, or clears it when there are none.
*
* Safe to call as often as anything changes — it is one query and one alarm
* write, and being wrong here means a reminder that never arrives.
*/
async function rescheduleReminders() {
	const now = Date.now();
	try {
		if ((await db({
			op: "dueReminders",
			now
		})).length > 0) {
			await fireDue();
			return;
		}
		const next = await db({
			op: "nextReminderAt",
			now
		});
		if (next.at === null) {
			await chrome.alarms.clear(ALARM);
			return;
		}
		await chrome.alarms.create(ALARM, { when: Math.max(next.at, now + MIN_DELAY_MS) });
		log.debug("next reminder at", new Date(next.at).toISOString());
	} catch (error) {
		log.error("could not schedule reminders", error);
	}
}
/** Shows everything that has come due, then re-arms for whatever is next. */
async function fireDue() {
	const now = Date.now();
	let fired = 0;
	try {
		const due = await db({
			op: "dueReminders",
			now
		});
		for (const memory of due) {
			await notify(memory.id, memory.text, memory.source_title, memory.remind_at, now);
			await db({
				op: "markReminded",
				id: memory.id,
				at: now
			});
			fired++;
			if (memory.repeat_rule !== null && memory.remind_at !== null) {
				const next = nextOccurrence(memory.remind_at, memory.repeat_rule, now);
				await db({
					op: "update",
					id: memory.id,
					patch: { remind_at: next }
				});
				log.debug("repeat rescheduled", memory.id, new Date(next).toISOString());
			}
		}
	} catch (error) {
		log.error("reminder firing failed", error);
	}
	if (fired > 0) log.info(`fired ${fired} reminder(s)`);
	try {
		const next = await db({
			op: "nextReminderAt",
			now: Date.now()
		});
		if (next.at === null) await chrome.alarms.clear(ALARM);
		else await chrome.alarms.create(ALARM, { when: Math.max(next.at, Date.now() + MIN_DELAY_MS) });
	} catch (error) {
		log.error("could not re-arm the reminder alarm", error);
	}
}
/**
* A system notification, not an in-page card.
*
* A reminder has to arrive whether or not a tab happens to be open on a page
* ViSO runs in — surfacing it only in the active tab would mean the reminders
* that matter most, the ones for when you are elsewhere, silently never appear.
*/
async function notify(memoryId, text, source, dueAt, now) {
	try {
		const late = lateness(dueAt, now);
		await chrome.notifications.create(`viso:reminder:${memoryId}`, {
			type: "basic",
			iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
			title: late === null ? "ViSO nhắc bạn" : `ViSO nhắc bạn — trễ ${late}`,
			message: text,
			contextMessage: late === null ? source ?? void 0 : `Lẽ ra nhắc lúc ${clock(dueAt)}${source === null ? "" : ` · ${source}`}`,
			priority: 2
		});
	} catch (error) {
		log.error("could not show the reminder", memoryId, error);
	}
}
/**
* How late this reminder is, or null when it arrived on time.
*
* An extension's alarms only run while Chrome does, so a reminder set for 07:00
* on a laptop that was closed arrives whenever the browser next opens. The
* notification used to look identical to a punctual one, which is a promise
* quietly broken; saying "trễ 2 giờ" costs a few words and is the difference
* between a tool that was honest about its limits and one that was not.
*/
var LATE_THRESHOLD_MS = 3 * MIN_DELAY_MS;
function lateness(dueAt, now) {
	if (dueAt === null) return null;
	const delay = now - dueAt;
	if (delay < LATE_THRESHOLD_MS) return null;
	const minutes = Math.round(delay / 6e4);
	if (minutes < 60) return `${minutes} phút`;
	const hours = Math.round(minutes / 60);
	if (hours < 24) return `${hours} giờ`;
	return `${Math.round(hours / 24)} ngày`;
}
function clock(at) {
	const d = new Date(at);
	const hhmm = `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
	return (/* @__PURE__ */ new Date()).toDateString() === d.toDateString() ? hhmm : `${hhmm} ${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}`;
}
/**
* Fires the reminders that were waiting for this page.
*
* Called on every context change, which is why it is one indexed lookup and
* nothing more. Deliberately not routed through §7.2's relevance gate: the user
* asked for this, by name, at this place — there is nothing to be judged
* relevant, and the rate limit exists to stop ViSO guessing, not to stop it
* keeping a promise.
*/
async function fireContextReminders(contextHash, host) {
	const now = Date.now();
	try {
		const due = await db({
			op: "dueOnContext",
			context_hash: contextHash,
			host
		});
		for (const memory of due) {
			await notify(memory.id, memory.text, memory.source_title, null, now);
			await db({
				op: "markReminded",
				id: memory.id,
				at: now
			});
		}
		if (due.length > 0) log.info(`fired ${due.length} context reminder(s)`);
		return due.length;
	} catch (error) {
		log.error("context reminders failed", error);
		return 0;
	}
}
function isReminderAlarm(name) {
	return name === ALARM;
}
/** Opens the Agent Hub when a reminder notification is clicked. */
/**
* A reminder's notification, pressed: the place the note was written opens,
* the way the card does — the tab it is already in when there is one,
* otherwise a new one. A note with no place falls back to the Hub.
*/
function handleNotificationClick(notificationId) {
	if (!notificationId.startsWith("viso:reminder:")) return;
	chrome.notifications.clear(notificationId);
	const id = Number(notificationId.slice(14));
	(async () => {
		const row = Number.isInteger(id) ? await db({
			op: "get",
			id
		}) : null;
		const target = row?.deep_link ?? row?.source_url ?? null;
		if (target === null) {
			await focusOrOpen(chrome.runtime.getURL("src/agenthub/agenthub.html"), null);
			return;
		}
		await focusOrOpen(target, `ext:${id}`);
	})().catch((error) => log.error("could not open the reminder", notificationId, error));
}
/** Switches to a tab already on `url`, or opens one. */
async function focusOrOpen(url, noteUid) {
	const bare = url.split("#")[0] ?? url;
	const hit = (await chrome.tabs.query({ url: [
		"http://*/*",
		"https://*/*",
		"chrome-extension://*/*"
	] })).find((tab) => (tab.url ?? "").split("#")[0] === bare);
	const callOut = (tabId, loaded = false) => {
		if (noteUid === null) return;
		const tell = () => {
			chrome.tabs.sendMessage(tabId, envelope({
				type: "viso/show-note",
				uid: noteUid
			})).catch(() => void 0);
		};
		if (loaded) {
			setTimeout(tell, 300);
			return;
		}
		const onDone = (id, info) => {
			if (id !== tabId || info.status !== "complete") return;
			chrome.tabs.onUpdated.removeListener(onDone);
			setTimeout(tell, 600);
		};
		chrome.tabs.onUpdated.addListener(onDone);
		setTimeout(() => {
			chrome.tabs.onUpdated.removeListener(onDone);
			tell();
		}, 4e3);
	};
	if (hit?.id !== void 0) {
		await chrome.tabs.update(hit.id, { active: true });
		if (hit.windowId !== void 0) await chrome.windows.update(hit.windowId, { focused: true });
		callOut(hit.id, true);
		return;
	}
	const tab = await chrome.tabs.create({ url });
	if (tab.id !== void 0) callOut(tab.id);
}
//#endregion
//#region src/background/save.ts
/**
* Writing a memory (spec §6.2), shared by Quick Actions now and by voice at
* Module 11 (§8.3 requires one path, not two).
*
* Storing never waits on the model. Consent can be declined or simply not given
* yet, and losing what someone just wrote down because a 135MB download has not
* happened would be indefensible — the row is written without a vector and
* picked up by backfill later.
*/
/** The last save, so a second Enter or a repeated click does not make a twin. */
var lastSave = null;
async function saveMemory(intent, text, context, remindAt = null, remindOnContext = null, selection = null, repeatRule = null, groupId = null) {
	const ctxKey = context?.context_hash ?? context?.source_url ?? null;
	if (lastSave !== null && lastSave.text === text.trim() && lastSave.context === ctxKey && Date.now() - lastSave.at < 5e3) return {
		ok: true,
		memoryId: lastSave.id,
		embedded: false
	};
	const { id } = await db({
		op: "insert",
		input: {
			text,
			entities: context?.entities ?? [],
			source_url: context?.source_url ?? null,
			source_title: context?.title ?? null,
			deep_link: context?.deep_link ?? null,
			platform_type: context?.platform_type ?? null,
			intent,
			context_hash: context?.context_hash ?? null,
			embedding: null,
			embedding_model: null,
			remind_at: intent === "REMINDER" || intent === "TASK" ? remindAt : null,
			remind_on_context: intent === "REMINDER" ? remindOnContext : null,
			selection,
			repeat_rule: intent === "REMINDER" ? repeatRule : null,
			group_id: groupId
		}
	});
	if ((intent === "REMINDER" || intent === "TASK") && remindAt !== null) rescheduleReminders();
	attachEmbedding(id, text).then((embedded) => {
		if (embedded) return backfillEmbeddings(10);
		return 0;
	}).catch((error) => log.warn("post-save embedding failed", id, error));
	lastSave = {
		text: text.trim(),
		context: ctxKey,
		at: Date.now(),
		id
	};
	return {
		ok: true,
		memoryId: id,
		embedded: false
	};
}
/**
* Rewrites a memory's text in place.
*
* Three things have to move together, and each one silently breaks search if
* it does not:
*  - the stored vector, which described the words that were just deleted;
*  - the entity list, which is what the §7.2 gate and person search read;
*  - the reminder, when the new wording names a time the old one did not.
*
* The last is reported back rather than done quietly. Turning a note into a
* scheduled interruption is a big enough change that the user has to be told
* it happened.
*/
async function editMemory(id, raw) {
	const text = raw.trim();
	if (text === "") return {
		ok: false,
		error: "Nội dung ghi chú không được để trống"
	};
	const existing = await db({
		op: "get",
		id
	});
	if (existing === null) return {
		ok: false,
		error: "Ghi chú không còn tồn tại"
	};
	const read = classifyIntent(text);
	const typed = readTyped(text, existing.intent === "REMEMBER" ? null : existing.intent);
	const patch = {
		text: typed.text,
		entities: read.entities.map((entity) => entity.value)
	};
	const remindAt = typed.remindAt;
	if (remindAt !== null) {
		if (existing.intent === "REMEMBER") patch.intent = "REMINDER";
		patch.remind_at = remindAt;
	}
	if (!(await db({
		op: "update",
		id,
		patch
	})).updated) return {
		ok: false,
		error: "Không sửa được ghi chú"
	};
	if (remindAt !== null) rescheduleReminders();
	attachEmbedding(id, text).catch((error) => log.warn("post-edit embedding failed", id, error));
	return {
		ok: true,
		remindAt
	};
}
/** `When` carries local wall-clock strings; the store wants epoch ms. */
/**
* Gives a note a time after the fact: the card's "Đặt giờ".
*
* The phrase is read by the same parser a typed reminder goes through, so
* whatever works in the composer works here. A note that had no alarm becomes
* a reminder; a to-do keeps being a to-do and gains a deadline.
*/
async function setDue(id, phrase) {
	const existing = await db({
		op: "get",
		id
	});
	if (existing === null) return {
		ok: false,
		error: "Ghi chú không còn tồn tại"
	};
	const when = parseWhen(phrase.trim());
	const remindAt = when.date === void 0 ? null : whenToEpoch(when);
	if (remindAt === null) return {
		ok: false,
		error: "Chưa hiểu thời gian — thử \"mai 9h\" hoặc \"thứ 6 3h chiều\""
	};
	const patch = { remind_at: remindAt };
	if (existing.intent === "REMEMBER") patch.intent = "REMINDER";
	if (!(await db({
		op: "update",
		id,
		patch
	})).updated) return {
		ok: false,
		error: "Không lưu được thời gian"
	};
	rescheduleReminders();
	return {
		ok: true,
		remindAt
	};
}
function whenToEpoch(when) {
	if (when.date === void 0) return null;
	const [y, m, d] = when.date.split("-").map(Number);
	const [hh, mm] = (when.time ?? "09:00").split(":").map(Number);
	const at = new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1, hh ?? 9, mm ?? 0, 0, 0).getTime();
	return Number.isFinite(at) ? at : null;
}
async function attachEmbedding(id, text) {
	try {
		if (!(await embed({ op: "status" })).downloaded) return false;
		const { vector, model } = await embed({
			op: "embedPassage",
			text
		});
		await db({
			op: "setEmbedding",
			id,
			embedding: vector,
			model
		});
		return true;
	} catch (error) {
		log.warn("could not embed memory", id, error);
		return false;
	}
}
/**
* Vectorises memories that have no vector yet.
*
* Called after the weights land, and again opportunistically after each
* successful save. The second trigger is what makes this self-healing: a save
* that failed to embed for any transient reason — the model still loading, a
* worker restarting — would otherwise leave that memory invisible to retrieval
* forever, with nothing scheduled to try again.
*
* Batched and sequential on purpose: repair work must not compete with a
* retrieval the user is actually waiting on.
*/
async function backfillEmbeddings(batchSize = 25) {
	const pending = await db({
		op: "listPendingEmbedding",
		limit: batchSize
	});
	if (pending.length === 0) return 0;
	let done = 0;
	for (const row of pending) if (await attachEmbedding(row.id, row.text)) done++;
	log.info(`backfilled ${done}/${pending.length} embeddings`);
	return done;
}
//#endregion
//#region src/background/model-consent.ts
/** One download at a time, however many callers ask. */
var running = null;
/**
* The alarm that keeps trying until the model is here.
*
* A fresh install has to finish the download with no page ever opened, and
* with nothing to wait on the service worker dies mid-transfer; the offscreen
* document keeps going, but a dropped network, a closed browser or a first
* attempt that failed used to leave the model missing until the next browser
* start. Every few minutes this asks again; once the file is on disk the
* alarm is cleared and nothing runs.
*/
var MODEL_ALARM = "viso:model-ensure";
var MODEL_RETRY_MINUTES = 3;
function armModelRetry() {
	chrome.alarms.create(MODEL_ALARM, { periodInMinutes: MODEL_RETRY_MINUTES });
}
/**
* Downloads the model unless it is already here.
*
* Called on install and on browser start, and safe to call again: it asks the
* offscreen document what is on disk before spending anything.
*/
async function ensureModel() {
	if (running !== null) return running;
	running = (async () => {
		try {
			armModelRetry();
			const state = await embed({ op: "status" });
			if (state.downloaded) {
				await chrome.alarms.clear(MODEL_ALARM);
				return;
			}
			log.info(`downloading the embedding model (${state.label})`);
			const result = await embed({ op: "load" });
			log.info("embedding model ready:", result.model);
			await chrome.alarms.clear(MODEL_ALARM);
			backfillEmbeddings();
		} catch (error) {
			if (isChannelClosed(error)) {
				log.info("embedding model still downloading; it continues in the background");
				return;
			}
			log.error("embedding model failed to load", error);
			await relayProgress({
				modelId: "embedding",
				fileKey: "embedding",
				phase: "error",
				loaded: 0,
				total: 0,
				ratio: null,
				error: error instanceof Error ? error.message : String(error)
			});
		} finally {
			running = null;
		}
	})();
	return running;
}
/** The Agent Hub's own button: download it now, after a failure or a decline made long ago. */
async function requestModelNow(_kind) {
	await ensureModel();
}
/** Model state for the Agent Hub. */
async function modelStatus(_kind) {
	const state = await embed({ op: "status" });
	return {
		downloaded: state.downloaded,
		downloading: state.downloading || running !== null,
		totalBytes: state.totalBytes,
		label: state.label,
		bytesLoaded: state.bytesLoaded,
		bytesTotal: state.bytesTotal
	};
}
/**
* A progress broadcast from the offscreen document.
*
* Logged rather than shown: nothing on a page waits for this download now, and
* the Agent Hub reads the finished state instead of watching the bytes.
*/
async function relayProgress(progress) {
	if (progress.phase === "error") log.error("model download failed:", progress.error ?? "unknown");
	else if (progress.ratio !== null && progress.ratio >= 1) log.info("model file ready:", progress.fileKey);
	return Promise.resolve();
}
/** Chrome's wording for "the page you were talking to went away". */
function isChannelClosed(error) {
	const message = error instanceof Error ? error.message : String(error);
	return /message channel closed|Receiving end does not exist|Extension context invalidated/i.test(message);
}
//#endregion
//#region src/db/rpc.ts
/** app_state keys. Kept here so no two modules invent different spellings. */
var STATE_KEYS = {
	/** §7.2 global rate limit: epoch ms of the last surfaced Context Card. */
	LAST_CARD_AT: "last_card_at",
	SCHEMA_VERSION: "schema_version"
};
//#endregion
//#region src/relevance/gate.ts
/**
* Gating logic (spec §7.2) — the rule that decides whether ViSO speaks.
*
*     score < 0.6           -> nothing
*     0.6 <= score < 0.82   -> badge on the dot, no card
*     score >= 0.82         -> full Context Card
*     hard limit: at most 1 card per 5 minutes, whatever the score
*
* Written as a pure function over already-scored candidates so the whole
* decision table is testable without a DOM, a database or a model.
*/
var GATE = {
	/** [spec §7.2] Below this, stay silent. */
	BADGE_THRESHOLD: .6,
	/** [spec §7.2] At or above this, surface a Context Card. */
	CARD_THRESHOLD: .82,
	/** [spec §7.2] Hard rate limit between cards, regardless of score. */
	CARD_COOLDOWN_MS: 3e5,
	/**
	* [proposed] Per-memory cooldown. §7.2 rate-limits cards globally but says
	* nothing about showing the SAME memory again; without this, returning to a
	* page re-surfaces what the user just read. Not a spec rule — flag if wrong.
	*/
	MEMORY_COOLDOWN_MS: 864e5,
	/** [proposed] How many badge-level memories to count before capping display. */
	MAX_BADGE_COUNT: 9,
	/**
	* [proposed] Floor a memory must still clear when the same person is named
	* on both sides.
	*
	* Not zero. A shared name is strong evidence about *who*, and none at all
	* about whether the memory has anything to do with what is on screen — so a
	* note reading as pure noise against this page stays quiet even then.
	* Deliberately below §7.2's badge threshold: the point is to admit matches
	* the semantic score cannot see, and the measured cross-language band sits at
	* 0.30-0.43 once calibrated.
	*/
	ENTITY_FLOOR: .25
};
/**
* Applies §7.2 to a scored candidate set.
*
* A rate-limited card does NOT silently vanish: it falls back to a badge, which
* is the same signal §7.2 assigns to medium relevance. The user still sees that
* something is there, without the interruption.
*/
function evaluate(input) {
	const live = input.candidates.filter((c) => c.dismissedAt === null);
	if (live.length === 0) return {
		action: "silent",
		reason: "no-candidates"
	};
	const eligible = live.filter((c) => c.breakdown.score >= GATE.BADGE_THRESHOLD || isPersonMatch(c));
	if (eligible.length === 0) return {
		action: "silent",
		reason: "below-threshold"
	};
	const ranked = [...eligible].sort((a, b) => b.breakdown.score - a.breakdown.score);
	const badgeCount = Math.min(ranked.length, GATE.MAX_BADGE_COUNT);
	const best = ranked[0];
	if (best === void 0 || !cardWorthy(best)) return {
		action: "badge",
		count: badgeCount
	};
	const cardCandidate = ranked.find((c) => cardWorthy(c) && !surfacedRecently(c, input.now));
	if (cardCandidate === void 0) return {
		action: "badge",
		count: badgeCount
	};
	if (rateLimited(input.lastCardAt, input.now)) return {
		action: "badge",
		count: badgeCount
	};
	return {
		action: "card",
		memoryId: cardCandidate.memoryId,
		score: cardCandidate.breakdown.score
	};
}
/**
* Naming the same person is its own route past the threshold.
*
* §7.2's numbers judge how alike two texts read, and that measure collapses
* across languages: a Vietnamese note about an English page scored 0.825
* against a noise ceiling of 0.816. A shared email address does not collapse —
* it is the same person or it is not. For the people ViSO is for, who write
* notes in Vietnamese while reading English, this is the difference between the
* proactive half of the product working and being silent.
*
* It admits, it does not shout: the §7.2 rate limit, the per-memory cooldown
* and dismissal all still apply, so the ceiling remains one card per five
* minutes however many names line up.
*/
function isPersonMatch(candidate) {
	return candidate.breakdown.entity === "strong" && candidate.breakdown.score >= GATE.ENTITY_FLOOR;
}
function cardWorthy(candidate) {
	return candidate.breakdown.score >= GATE.CARD_THRESHOLD || isPersonMatch(candidate);
}
function rateLimited(lastCardAt, now) {
	if (lastCardAt === null) return false;
	return now - lastCardAt < GATE.CARD_COOLDOWN_MS;
}
function surfacedRecently(candidate, now) {
	if (candidate.lastSurfacedAt === null) return false;
	return now - candidate.lastSurfacedAt < GATE.MEMORY_COOLDOWN_MS;
}
/**
* The failure path §7.2 does not cover: retrieval could not run at all, because
* the model is not downloaded yet or embedding threw.
*
* Silence is the only correct answer — a card built without a relevance score
* would be a guess, and §5.5's principle ("thà không lưu gì còn hơn lưu sai")
* applies just as much to what gets shown.
*/
function noEmbeddingDecision() {
	return {
		action: "silent",
		reason: "no-embedding"
	};
}
//#endregion
//#region src/background/retrieval.ts
/**
* Proactive retrieval (spec §7.3): runs on a context change, never on a timer.
*
* The whole path is: embed the current context -> score every memory inside the
* db worker -> apply the §7.2 gate -> tell the tab what, if anything, to show.
*/
async function runRetrieval(context, tabId) {
	if (tabId === void 0) return;
	const decision = await decide(context);
	log.debug("gate decision", decision);
	switch (decision.action) {
		case "silent":
			await push(tabId, {
				type: "viso/dot-badge",
				badge: null
			});
			return;
		case "badge":
			await push(tabId, {
				type: "viso/dot-badge",
				badge: { count: decision.count }
			});
			return;
		case "card": {
			const memory = await db({
				op: "get",
				id: decision.memoryId
			});
			if (memory === null) return;
			await push(tabId, {
				type: "viso/dot-badge",
				badge: null
			});
			if (!await push(tabId, {
				type: "viso/context-card",
				memory: {
					id: memory.id,
					text: memory.text,
					sourceTitle: memory.source_title,
					deepLink: memory.deep_link,
					createdAt: memory.created_at
				},
				score: decision.score
			})) {
				log.debug("card was not delivered; clocks left alone");
				return;
			}
			const now = Date.now();
			await db({
				op: "markSurfaced",
				id: decision.memoryId,
				at: now
			});
			await db({
				op: "setState",
				key: STATE_KEYS.LAST_CARD_AT,
				value: String(now)
			});
			return;
		}
	}
}
async function decide(context) {
	if (!(await embed({ op: "status" })).downloaded) return noEmbeddingDecision();
	let vector;
	try {
		vector = (await embed({
			op: "embedQuery",
			text: queryTextFor(context)
		})).vector;
	} catch (error) {
		log.warn("embedding failed, staying silent", error);
		return noEmbeddingDecision();
	}
	const now = Date.now();
	const candidates = await db({
		op: "searchSimilar",
		query: {
			vector,
			contextEntities: context.entity_refs,
			now,
			limit: 20
		}
	});
	const stored = await db({
		op: "getState",
		key: STATE_KEYS.LAST_CARD_AT
	});
	const lastCardAt = stored.value === null ? null : Number(stored.value);
	return evaluate({
		candidates,
		lastCardAt: Number.isFinite(lastCardAt) ? lastCardAt : null,
		now
	});
}
/**
* What the current page is "about", as one string.
*
* Title first: it is the most reliable signal, and on a degraded extraction
* (§5.5) it is the only one there is.
*/
function queryTextFor(context) {
	return context.body === "" ? context.title : `${context.title}. ${context.body}`;
}
/** Returns whether the message reached the tab — callers act on that. */
async function push(tabId, message) {
	try {
		await chrome.tabs.sendMessage(tabId, envelope(message));
		return true;
	} catch {
		return false;
	}
}
//#endregion
//#region src/background/query.ts
/**
* The background's binding of the shared search (see @/query/run).
*
* Everything specific to this side lives here: how to reach the database, and
* what to do when the embedding model is missing or fails. That last one is a
* degrade, never an error — the user asked a question, and "the model is busy"
* is not an answer to it.
*/
async function runQuery(raw, context) {
	return runQuery$1(raw, context, {
		search: (query) => db({
			op: "search",
			query
		}),
		embedQuery: async (text) => {
			try {
				if (!(await embed({ op: "status" })).downloaded) return null;
				return (await embed({
					op: "embedQuery",
					text
				})).vector;
			} catch (error) {
				log.warn("query embedding failed, falling back to keywords", error);
				return null;
			}
		}
	});
}
//#endregion
//#region src/background/backup.ts
/**
* Everything, including dismissed notes.
*
* A backup that quietly drops what you deleted is not a backup; and `dismissed_at`
* travels with the row, so restoring it does not resurrect anything.
*/
async function exportAll() {
	const memories = [];
	const PAGE = 200;
	for (let offset = 0;; offset += PAGE) {
		const page = await db({
			op: "list",
			query: {
				limit: PAGE,
				offset,
				include_dismissed: true
			}
		});
		memories.push(...page);
		if (page.length < PAGE) break;
	}
	return {
		format: "viso-memories",
		version: 8,
		exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
		count: memories.length,
		memories
	};
}
/**
* Adds rows from a backup, skipping ones already present.
*
* Matched on text plus creation time rather than on id: ids are assigned by
* whichever database wrote them, so importing a file into a different profile —
* the case that matters — would otherwise duplicate everything or collide with
* unrelated rows.
*
* Vectors are not carried across. They are large, they are tied to a particular
* model version, and backfill regenerates them for free.
*/
async function importBackup(file) {
	const parsed = file;
	if (parsed?.format !== "viso-memories" || !Array.isArray(parsed.memories)) throw new Error("Không phải file sao lưu của ViSO");
	const existing = /* @__PURE__ */ new Set();
	for (let offset = 0;; offset += 200) {
		const page = await db({
			op: "list",
			query: {
				limit: 200,
				offset,
				include_dismissed: true
			}
		});
		for (const row of page) existing.add(`${row.created_at}|${row.text}`);
		if (page.length < 200) break;
	}
	const groupIds = /* @__PURE__ */ new Map();
	const groupIdFor = async (name) => {
		if (typeof name !== "string" || name.trim() === "") return null;
		const known = groupIds.get(name);
		if (known !== void 0) return known;
		try {
			const { group } = await db({
				op: "createGroup",
				name
			});
			groupIds.set(name, group.id);
			return group.id;
		} catch {
			return null;
		}
	};
	const result = {
		added: 0,
		skipped: 0,
		errors: 0
	};
	for (const row of parsed.memories) {
		const key = `${row.created_at}|${row.text}`;
		if (existing.has(key)) {
			result.skipped++;
			continue;
		}
		try {
			await db({
				op: "insert",
				input: {
					text: row.text,
					entities: Array.isArray(row.entities) ? row.entities : [],
					source_url: row.source_url ?? null,
					source_title: row.source_title ?? null,
					deep_link: row.deep_link ?? null,
					platform_type: row.platform_type ?? null,
					intent: row.intent ?? "REMEMBER",
					context_hash: row.context_hash ?? null,
					embedding: null,
					embedding_model: null,
					created_at: row.created_at,
					remind_at: row.remind_at ?? null,
					remind_on_context: row.remind_on_context ?? null,
					selection: row.selection ?? null,
					repeat_rule: row.repeat_rule ?? null,
					group_id: await groupIdFor(row.group_name)
				}
			});
			existing.add(key);
			result.added++;
		} catch (error) {
			log.warn("could not import a row", error);
			result.errors++;
		}
	}
	return result;
}
//#endregion
//#region src/background/desktopLink.ts
var DesktopLink = class {
	options;
	port = null;
	hello = null;
	nextId = 1;
	pending = /* @__PURE__ */ new Map();
	idleTimer = null;
	unavailableUntil = 0;
	inFront = false;
	state = "offline";
	desktopVersion = null;
	constructor(options) {
		this.options = options;
	}
	/** The browser came to the front: the Orb may be summoned over a page, so the app should know us. */
	focusGained() {
		this.inFront = true;
		this.clearIdle();
		this.ensure();
	}
	/** The browser went to the back. The link stays a while, in case the user comes right back. */
	focusLost() {
		this.inFront = false;
		this.clearIdle();
		this.idleTimer = setTimeout(() => {
			this.idleTimer = null;
			if (!this.inFront) this.disconnect();
		}, this.options.idleMs ?? 6e5);
	}
	/**
	* Opens the link and says hello, once. Resolves whether the app answered.
	* Never throws; the app not running is the normal case.
	*/
	ensure() {
		if (this.port !== null && this.hello !== null) return this.hello;
		if (Date.now() < this.unavailableUntil) return Promise.resolve(false);
		this.setState("connecting");
		this.hello = this.request({
			type: "viso/link-hello",
			protocol: 1,
			extensionVersion: this.options.extensionVersion
		}, this.options.helloTimeoutMs ?? 1500).then((reply) => {
			if (reply["ok"] === true) {
				this.desktopVersion = typeof reply["desktopVersion"] === "string" ? reply["desktopVersion"] : null;
				this.setState("connected");
				return true;
			}
			const error = String(reply["error"] ?? "");
			this.markUnavailable(error, error === "protocol-mismatch" ? "mismatch" : "offline");
			return false;
		}).catch((error) => {
			this.markUnavailable(describe(error), "offline");
			return false;
		});
		return this.hello;
	}
	/**
	* Asks the app to bring up the Orb, for this page.
	*
	* Returns false when there is no app to ask — the caller tells the user to
	* open it. A summon is worth a fresh attempt even inside the retry window:
	* the user just pressed the button, and the app may have started since.
	*/
	async summon(page) {
		this.unavailableUntil = 0;
		if (!await this.ensure()) return false;
		try {
			return (await this.request({
				type: "viso/orb-summon",
				page
			}, 3e3))["ok"] === true;
		} catch (error) {
			log.debug("summon failed:", describe(error));
			return false;
		}
	}
	/**
	* Changes one of the app's own items, on this browser's say-so.
	*
	* The row's buttons in the page's panel have to work whichever store the row
	* came from; the app's items are not ours to write, so they are asked for.
	*/
	async appNoteCommand(itemId, verb, text) {
		if (!await this.ensure()) return {
			ok: false,
			error: "Chưa kết nối app ViSO trên máy tính"
		};
		try {
			const reply = await this.request({
				type: "viso/app-note-command",
				itemId,
				verb,
				...text === void 0 ? {} : { text }
			}, 8e3);
			return reply.ok ? { ok: true } : {
				ok: false,
				error: reply.error
			};
		} catch (error) {
			return {
				ok: false,
				error: describe(error)
			};
		}
	}
	/**
	* The items the app holds about this page.
	*
	* A note said over a page lives in the desktop store — that is where the Orb
	* writes — so the panel has to ask for them rather than read its own. Empty
	* when there is no app: the panel then shows only what was typed here.
	*/
	async pageNotes(scopes, limit = 50) {
		if (!await this.ensure()) return [];
		try {
			const reply = await this.request({
				type: "viso/page-notes",
				scopes,
				limit
			}, 1200);
			return reply.ok ? reply.notes : [];
		} catch (error) {
			log.debug("page notes failed:", describe(error));
			return [];
		}
	}
	disconnect() {
		this.clearIdle();
		if (this.port !== null) {
			const port = this.port;
			this.port = null;
			this.hello = null;
			port.disconnect();
			this.failPending("the link was closed");
		}
		this.setState("offline");
	}
	request(message, timeoutMs) {
		const port = this.ensurePort();
		const id = this.nextId++;
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending.delete(id);
				reject(/* @__PURE__ */ new Error("the desktop app did not answer in time"));
			}, timeoutMs);
			this.pending.set(id, {
				resolve,
				reject,
				timer
			});
			try {
				port.postMessage({
					...message,
					id
				});
			} catch (error) {
				clearTimeout(timer);
				this.pending.delete(id);
				reject(error instanceof Error ? error : new Error(String(error)));
			}
		});
	}
	ensurePort() {
		if (this.port !== null) return this.port;
		const port = this.options.connect();
		port.onMessage.addListener((message) => void this.onMessage(message, port));
		port.onDisconnect.addListener(() => {
			const reason = this.options.lastError() ?? "the desktop app closed the link";
			if (this.port !== port) return;
			this.port = null;
			this.hello = null;
			this.failPending(reason);
			this.setState("offline");
			log.debug("desktop link closed:", reason);
		});
		this.port = port;
		return port;
	}
	/** A reply to us, or a request from the app. */
	async onMessage(message, port) {
		const id = message["id"];
		if (typeof id !== "number") return;
		const type = String(message["type"]);
		const waiting = this.pending.get(id);
		if (waiting !== void 0 && (type === "viso/link-hello" || type === "viso/orb-summon" || type === "viso/page-notes" || type === "viso/app-note-command")) {
			this.pending.delete(id);
			clearTimeout(waiting.timer);
			waiting.resolve(message);
			return;
		}
		const reply = await this.answer(message);
		if (reply === null) return;
		try {
			port.postMessage({
				...reply,
				type,
				id
			});
		} catch (error) {
			log.debug("could not answer the desktop:", describe(error));
		}
	}
	async answer(request) {
		const { handlers } = this.options;
		try {
			switch (request.type) {
				case "viso/orb-where": return {
					ok: true,
					...await handlers.where()
				};
				case "viso/orb-search": return {
					ok: true,
					items: await handlers.search(request.query)
				};
				case "viso/orb-open": return { ok: await handlers.open(request.uid) };
				case "viso/notes-changed":
					handlers.notesChanged(request.tabId);
					return { ok: true };
				case "viso/browser-notes": return {
					ok: true,
					notes: await handlers.browserNotes(request.scopes ?? [], request.limit ?? 50)
				};
				case "viso/note-command": {
					const result = await handlers.noteCommand(request.uid, request.verb, request.text);
					return result.ok ? {
						ok: true,
						text: result.text
					} : {
						ok: false,
						error: result.error ?? "failed"
					};
				}
				default: return null;
			}
		} catch (error) {
			return {
				ok: false,
				error: describe(error)
			};
		}
	}
	markUnavailable(reason, state) {
		this.unavailableUntil = Date.now() + (this.options.retryAfterMs ?? 6e4);
		log.debug("desktop link unavailable:", reason);
		if (this.port !== null) {
			const port = this.port;
			this.port = null;
			this.hello = null;
			port.disconnect();
		}
		this.setState(state);
	}
	failPending(reason) {
		for (const waiting of this.pending.values()) {
			clearTimeout(waiting.timer);
			waiting.reject(new Error(reason));
		}
		this.pending.clear();
	}
	clearIdle() {
		if (this.idleTimer !== null) clearTimeout(this.idleTimer);
		this.idleTimer = null;
	}
	setState(state) {
		if (this.state === state) return;
		this.state = state;
		this.options.onStateChange?.(state);
	}
};
var shared = null;
/** The background's one link, created with its handlers on first use. */
function initDesktopLink(handlers, onStateChange) {
	shared = new DesktopLink({
		connect: () => chrome.runtime.connectNative(NATIVE_HOST_NAME),
		lastError: () => chrome.runtime.lastError?.message ?? null,
		handlers,
		extensionVersion: chrome.runtime.getManifest().version,
		onStateChange
	});
	return shared;
}
function desktopLink() {
	return shared;
}
function describe(error) {
	return error instanceof Error ? error.message : String(error);
}
//#endregion
//#region src/background/orbBridge.ts
/** The site a note's link belongs to, for grouping one icon lookup per site. */
var hostOf$1 = (url) => hostLabel(url);
/**
* What the desktop Orb can do on a web page, answered from here.
*
* The desktop hears and understands; this side knows pages. It says which
* page is in front, files a note on it, searches every web note, and brings a
* note's page back up. The tab itself is asked for its context rather than
* the URL being parsed again: the content script already extracted the
* thread, the document, the platform, and a second reading would disagree
* with the first on exactly the pages that matter.
*/
var DESKTOP_LINK_STATE_KEY = "viso:desktop-link";
/** The context each tab last reported, so a save does not re-ask a page that has not moved. */
var contexts = /* @__PURE__ */ new Map();
/**
* When a browser window last stopped being the focused one.
*
* The desktop's own Notes panel takes the keyboard when it opens, and from
* here that is indistinguishable from the user switching to another app. This
* is what lets the app tell the two apart: it asks how long ago, and treats a
* browser that was in front seconds ago as still the place a note belongs.
* Zero means it has never been focused in this service worker's lifetime.
*/
var blurredAt = 0;
/**
* A row in a page's panel that the app owns, changed from the browser.
*
* The panel lists both stores and its buttons have to work on either; this is
* the half that is not ours to write, so it is asked for over the link.
*/
async function appNoteCommand(itemId, verb, text) {
	const link = desktopLink();
	if (link === null) return {
		ok: false,
		error: "Chưa kết nối app ViSO trên máy tính"
	};
	return link.appNoteCommand(itemId, verb, text);
}
/** The live link's state, for the Agent Hub's desktop card. */
async function linkStatus() {
	const link = desktopLink();
	if (link !== null) return {
		state: link.state,
		desktopVersion: link.desktopVersion
	};
	try {
		return {
			state: (await chrome.storage.local.get("viso:desktop-link"))["viso:desktop-link"]?.state ?? "offline",
			desktopVersion: null
		};
	} catch {
		return {
			state: "offline",
			desktopVersion: null
		};
	}
}
function startOrbBridge() {
	const link = initDesktopLink(handlers, (state) => {
		log.info("desktop link:", state, link.desktopVersion ?? "");
		rememberState(state);
	});
	chrome.windows.onFocusChanged.addListener((windowId) => {
		if (windowId === chrome.windows.WINDOW_ID_NONE) {
			blurredAt = Date.now();
			link.focusLost();
		} else link.focusGained();
	});
	chrome.windows.getLastFocused().then((window) => {
		if (window.focused) link.focusGained();
	}).catch(() => {});
	chrome.tabs.onRemoved.addListener((tabId) => contexts.delete(tabId));
}
/**
* The mic button or the browser's Ctrl+Space: bring up the Orb over this tab.
*
* The page is sent along, so the desktop does not have to ask where the user
* is — and so a summon from a tab that is not the active one still files on
* the tab whose button was pressed.
*/
async function summonOrb(tabId) {
	const link = desktopLink();
	if (link === null) return {
		ok: false,
		reason: "offline"
	};
	const page = tabId === void 0 ? null : await pageFor(tabId);
	if (await link.summon(page)) return { ok: true };
	return {
		ok: false,
		reason: link.state === "mismatch" ? "mismatch" : "offline"
	};
}
var handlers = {
	async where() {
		let window;
		try {
			window = await chrome.windows.getLastFocused();
		} catch {
			return {
				focused: false,
				focusedAgoMs: null,
				page: null
			};
		}
		const focused = window.focused === true;
		const focusedAgoMs = focused ? 0 : blurredAt === 0 ? null : Date.now() - blurredAt;
		if (window.id === void 0) return {
			focused,
			focusedAgoMs,
			page: null
		};
		const [tab] = await chrome.tabs.query({
			active: true,
			windowId: window.id
		});
		return {
			focused,
			focusedAgoMs,
			page: tab?.id === void 0 ? null : await pageFor(tab.id)
		};
	},
	async search(query) {
		const { hits } = await runQuery(query, {
			context_hash: null,
			source_host: null
		});
		const rows = hits.slice(0, 8);
		const icons = /* @__PURE__ */ new Map();
		for (const hit of rows) {
			const url = hit.memory.deep_link ?? hit.memory.source_url;
			const host = hostOf$1(url);
			if (host === null || icons.has(host)) continue;
			icons.set(host, url === null ? null : await faviconDataUrl(url).catch(() => null));
		}
		return rows.map((hit) => {
			const url = hit.memory.deep_link ?? hit.memory.source_url;
			const host = hostOf$1(url);
			return {
				uid: `ext:${hit.memory.id}`,
				text: hit.memory.text,
				intent: hit.memory.intent,
				createdAt: hit.memory.created_at,
				sourceTitle: hit.memory.source_title,
				sourceLabel: sourceLabel(hit.memory.platform_type, url),
				favicon: host === null ? null : icons.get(host) ?? null
			};
		});
	},
	/**
	* What this browser holds about a page, newest first.
	*
	* The same rows the page's own panel shows, answered to the app so the Orb
	* can resolve "số một" against the list the user is looking at rather than
	* against half of it.
	*/
	async browserNotes(scopes, limit) {
		const rows = [];
		for (const scope of scopes) {
			const found = scope.kind === "file" ? (await db({
				op: "listForPage",
				context_hash: scope.key,
				host: null,
				limit
			})).here : await db({
				op: "listForHost",
				host: scope.key,
				limit
			});
			for (const row of found) if (!rows.some((seen) => seen.id === row.id)) rows.push(row);
		}
		rows.sort((a, b) => b.created_at - a.created_at);
		return Promise.all(rows.slice(0, limit).map(async (row) => {
			const url = row.deep_link ?? row.source_url;
			return {
				uid: `ext:${row.id}`,
				text: row.text,
				intent: row.intent,
				createdAt: row.created_at,
				sourceTitle: row.source_title,
				sourceLabel: sourceLabel(row.platform_type, url),
				favicon: url === null ? null : await faviconDataUrl(url).catch(() => null)
			};
		}));
	},
	/**
	* Deletes or rewrites one of this browser's notes, on the Orb's say-so.
	*
	* The same two operations the panel offers by hand, reached by voice: the
	* Orb lists a page's notes from both stores, and the user picks one of ours.
	* Returns the note's text so the Orb can name what it just changed.
	*/
	async noteCommand(uid, verb, text) {
		const id = Number(uid.replace(/^ext:/, ""));
		if (!uid.startsWith("ext:") || !Number.isInteger(id)) return {
			ok: false,
			text: "",
			error: "that note is not this browser’s"
		};
		const row = await db({
			op: "get",
			id
		});
		if (row === null) return {
			ok: false,
			text: "",
			error: "that note is no longer here"
		};
		if (verb === "delete") {
			const { deleted } = await db({
				op: "delete",
				id
			});
			if (!deleted) return {
				ok: false,
				text: "",
				error: "could not delete it"
			};
			handlers.notesChanged(null);
			return {
				ok: true,
				text: row.text
			};
		}
		if (verb === "done" || verb === "undone") {
			const { updated } = await db({
				op: "update",
				id,
				patch: { done_at: verb === "done" ? Date.now() : null }
			});
			if (!updated) return {
				ok: false,
				text: "",
				error: "could not tick it"
			};
			handlers.notesChanged(null);
			return {
				ok: true,
				text: row.text
			};
		}
		if (verb === "group") {
			const name = (text ?? "").trim();
			let groupId = null;
			if (name !== "") groupId = (await db({
				op: "createGroup",
				name
			})).group.id;
			const { updated } = await db({
				op: "setNoteGroup",
				id,
				group_id: groupId
			});
			if (!updated) return {
				ok: false,
				text: "",
				error: "could not change its group"
			};
			handlers.notesChanged(null);
			return {
				ok: true,
				text: row.text
			};
		}
		const next = (text ?? "").trim();
		if (next === "") return {
			ok: false,
			text: "",
			error: "nothing to change it to"
		};
		const result = await editMemory(id, next);
		if (!result.ok) return {
			ok: false,
			text: "",
			error: result.error ?? "could not change it"
		};
		handlers.notesChanged(null);
		return {
			ok: true,
			text: next
		};
	},
	/**
	* The app's items changed: the panels showing them read again.
	*
	* A tab id is the page just saved into. Null is a delete or an edit made in
	* the app's own window, which any page's panel may be showing — so every tab
	* is told, and the ones with no ViSO on them ignore it.
	*/
	notesChanged(tabId) {
		const tell = (id) => {
			chrome.tabs.sendMessage(id, envelope({
				type: "viso/notes-changed",
				highlightId: null
			})).catch(() => void 0);
		};
		if (tabId !== null) {
			tell(tabId);
			return;
		}
		chrome.tabs.query({}).then((tabs) => {
			for (const tab of tabs) if (tab.id !== void 0) tell(tab.id);
		}).catch(() => void 0);
	},
	async open(uid) {
		const id = Number(uid.replace(/^ext:/, ""));
		if (!Number.isInteger(id)) return false;
		const row = await db({
			op: "get",
			id
		});
		const url = row?.deep_link ?? row?.source_url ?? null;
		if (row === null || url === null || !/^https?:/.test(url)) return false;
		const open = (await chrome.tabs.query({})).find((tab) => tab.url !== void 0 && samePage(url, tab.url));
		if (open?.id !== void 0) {
			if (open.windowId !== void 0) await chrome.windows.update(open.windowId, { focused: true });
			await chrome.tabs.update(open.id, { active: true });
			chrome.tabs.sendMessage(open.id, envelope({
				type: "viso/notes-changed",
				highlightId: id
			})).catch(() => void 0);
			return true;
		}
		await chrome.tabs.create({
			url,
			active: true
		});
		return true;
	}
};
async function pageFor(tabId) {
	const context = await contextFor(tabId, void 0);
	if (context === null) return null;
	const scope = scopeFor(context.platform_type, context.context_hash, context.source_url);
	const favicon = await faviconDataUrl(context.source_url).catch(() => null);
	return {
		tabId,
		url: context.source_url,
		deepLink: context.deep_link === "" ? null : context.deep_link,
		sourceHost: scope?.kind === "site" ? scope.host : hostLabel(context.source_url),
		title: context.title,
		platformType: context.platform_type,
		contextHash: context.context_hash,
		label: scope === null ? context.title : scopeLabel(scope, context.platform_type, context.source_url, context.title),
		favicon
	};
}
/**
* What the app holds about a page: this exact page, and the site around it.
*
* Notes said out loud live in the desktop store — the Orb writes there — so
* the panel on a page has to ask for them. Both scopes travel together: the
* panel lists this page's and offers the rest of the site's behind a chip.
*/
async function desktopPageNotes(scope, host) {
	const link = desktopLink();
	if (link === null) return [];
	const scopes = [];
	if (scope.kind === "file") scopes.push({
		kind: "file",
		key: scope.contextHash
	});
	const site = scope.kind === "site" ? scope.host : host;
	if (site !== null) scopes.push({
		kind: "site",
		key: site
	});
	if (scopes.length === 0) return [];
	return link.pageNotes(scopes);
}
/** Every item the app said over some page, for the panel's "Tất cả" view. */
async function desktopAllNotes() {
	const link = desktopLink();
	if (link === null) return [];
	return link.pageNotes([{
		kind: "all",
		key: ""
	}], 200);
}
/**
* The tab's context, asked of the tab.
*
* With `expectedHash` the cached answer is trusted when it still matches —
* the page has not moved since the Orb asked where it was. Without it, or on
* a mismatch, the tab is asked again; no answer means a page Chrome keeps
* extensions out of, or a tab that is gone.
*/
async function contextFor(tabId, expectedHash) {
	const cached = contexts.get(tabId);
	if (cached !== void 0 && expectedHash !== void 0 && cached.context_hash === expectedHash) return cached;
	try {
		const context = (await chrome.tabs.sendMessage(tabId, envelope({ type: "viso/current-context" })))?.context ?? null;
		if (context === null) contexts.delete(tabId);
		else contexts.set(tabId, context);
		return context;
	} catch (error) {
		log.debug("no context from tab", tabId, error);
		contexts.delete(tabId);
		return null;
	}
}
async function rememberState(state) {
	try {
		await chrome.storage.local.set({ [DESKTOP_LINK_STATE_KEY]: {
			state,
			at: Date.now()
		} });
	} catch {}
}
//#endregion
//#region src/background/background.ts
/**
* Background service worker (spec §2).
*
* Deliberately thin for now. MV3 terminates this worker after ~30s idle, so it
* holds no long-lived state — the memory store (Module 3) and the model runtime
* (Module 5, which will need an offscreen document) provide durability instead.
*/
/** A second chance to repair anything left unembedded by an earlier session. */
onStoreWrite(() => scheduleDesktopSync());
startOrbBridge();
chrome.runtime.onStartup.addListener(() => {
	scheduleDesktopSync();
	ensureModel();
	backfillEmbeddings().catch(() => {});
	rescheduleReminders();
});
chrome.alarms.onAlarm.addListener((alarm) => {
	if (alarm.name === "viso:model-ensure") ensureModel();
	if (isReminderAlarm(alarm.name)) fireDue();
});
chrome.notifications.onClicked.addListener(handleNotificationClick);
/**
* Puts ViSO into tabs that were already open.
*
* Chrome runs manifest content scripts only on navigation. After installing —
* or after every update, including each Reload during development — every tab
* already open has no dot until the user refreshes it, which reads as "ViSO
* does not show on this site". Injecting here closes that gap.
*
* http(s) only. Chrome forbids extensions on chrome://, the Web Store and the
* new tab page outright, file:// needs a per-extension switch the user has to
* turn on, and a discarded tab reloads — and gets the manifest script — when
* it is next activated. Each failure is expected and swallowed individually,
* so one restricted tab cannot stop the rest.
*/
async function injectIntoOpenTabs() {
	const files = chrome.runtime.getManifest().content_scripts?.[0]?.js ?? [];
	if (files.length === 0) return;
	const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
	const results = await Promise.allSettled(tabs.filter((tab) => tab.id !== void 0 && tab.discarded !== true).map((tab) => chrome.scripting.executeScript({
		target: { tabId: tab.id },
		files
	})));
	const injected = results.filter((result) => result.status === "fulfilled").length;
	log.info(`injected into ${injected}/${results.length} open tab(s)`);
}
chrome.runtime.onInstalled.addListener((details) => {
	log.info("installed:", details.reason);
	if (details.reason === "install" || details.reason === "update") injectIntoOpenTabs();
	if (details.reason === "install") openHub();
	ensureModel();
	scheduleDesktopSync();
	backfillEmbeddings().catch(() => {});
	rescheduleReminders();
	db({ op: "count" }).then(({ total }) => log.info("memory store ready,", total, "memories")).catch((error) => log.error("memory store failed to open", error));
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (!isContentRequest(message)) return false;
	switch (message.type) {
		case "viso/hello":
			log.debug("hello from tab", sender.tab?.id, message.url);
			sendResponse({
				ok: true,
				protocolVersion: 3
			});
			return false;
		case "viso/context-changed":
			log.debug("context changed", {
				tab: sender.tab?.id,
				reason: message.reason,
				signature: message.signature,
				url: message.url,
				extraction: message.extraction.ok ? {
					extractor: message.extraction.context.extractor,
					confidence: message.extraction.context.confidence,
					title: message.extraction.context.title
				} : { failed: message.extraction.reason }
			});
			if (message.extraction.ok && message.extraction.context.confidence >= EXTRACT_CONFIG.CONFIDENCE.READABILITY_BASE) runRetrieval(message.extraction.context, sender.tab?.id);
			if (message.extraction.ok) {
				const ctx = message.extraction.context;
				fireContextReminders(ctx.context_hash, hostOf(ctx.source_url));
			}
			sendResponse({ ok: true });
			return false;
		case "viso/dismiss-memory":
			db({
				op: "dismiss",
				id: message.memoryId
			});
			sendResponse({ ok: true });
			return false;
		case "viso/memory-feedback":
			db({
				op: "setFeedback",
				id: message.memoryId,
				feedback: message.feedback
			});
			sendResponse({ ok: true });
			return false;
		case "viso/save-memory":
			saveMemory(message.intent, message.text, message.context, message.remindAt ?? null, message.remindOnContext ?? null, message.selection ?? null, message.repeat ?? null, message.groupId ?? null).then(sendResponse, (error) => {
				const reason = error instanceof Error ? error.message : String(error);
				log.error("save failed", reason);
				sendResponse({
					ok: false,
					error: reason
				});
			});
			return true;
		case "viso/undo-save":
			db({
				op: "delete",
				id: message.memoryId
			});
			sendResponse({ ok: true });
			return false;
		case "viso/scope-notes": {
			const scope = scopeFor(message.platform_type, message.context_hash, message.source_url);
			if (scope === null) {
				sendResponse({
					ok: true,
					notes: [],
					scope: null
				});
				return false;
			}
			const limit = message.limit ?? 200;
			const host = scope.kind === "site" ? scope.host : hostOf(message.source_url);
			const here = scope.kind === "file" ? db({
				op: "listForPage",
				context_hash: scope.contextHash,
				host: null,
				limit
			}).then((result) => result.here) : db({
				op: "listForHost",
				host: scope.host,
				limit
			});
			const elsewhere = scope.kind === "file" && host !== null ? db({
				op: "listForHost",
				host,
				limit
			}).then((rows) => rows.filter((row) => row.context_hash !== scope.contextHash)) : Promise.resolve([]);
			const fromApp = Promise.race([desktopPageNotes(scope, host).catch(() => []), new Promise((resolve) => setTimeout(() => resolve([]), APP_NOTES_DEADLINE_MS))]);
			Promise.all([
				here,
				elsewhere,
				fromApp
			]).then(([own, site, app]) => {
				sendResponse({
					ok: true,
					notes: [
						...own.map((row) => toWire(row, false)),
						...site.map((row) => toWire(row, true)),
						...app.map(toAppWire)
					].sort((a, b) => b.createdAt - a.createdAt),
					scope: scope.kind
				});
			}).catch((error) => {
				log.error("scope-notes failed", error);
				sendResponse({
					ok: true,
					notes: [],
					scope: scope.kind
				});
			});
			return true;
		}
		case "viso/all-notes": {
			const own = db({
				op: "list",
				query: { limit: message.limit ?? 200 }
			});
			const fromApp = Promise.race([desktopAllNotes().catch(() => []), new Promise((resolve) => setTimeout(() => resolve([]), APP_NOTES_DEADLINE_MS))]);
			Promise.all([own, fromApp]).then(([rows, app]) => {
				sendResponse({
					ok: true,
					notes: [...rows.map((row) => toWire(row, true)), ...app.map(toAppWire)].sort((a, b) => b.createdAt - a.createdAt),
					scope: "all"
				});
			}).catch((error) => {
				log.error("all-notes failed", error);
				sendResponse({
					ok: true,
					notes: [],
					scope: "all"
				});
			});
			return true;
		}
		case "viso/query": {
			const host = hostOf(message.source_url);
			runQuery(message.text, {
				context_hash: message.context_hash,
				source_host: host
			}).then(({ hits, spec, semantic }) => sendResponse({
				ok: true,
				hits: hits.map((hit) => ({
					...toWire(hit.memory),
					matched: hit.matched
				})),
				summary: describeQuery(spec, hits.length),
				semantic
			})).catch((error) => {
				const reason = error instanceof Error ? error.message : String(error);
				log.error("query failed", reason);
				sendResponse({
					ok: true,
					hits: [],
					summary: `Không tìm được: ${reason}`,
					semantic: false
				});
			});
			return true;
		}
		case "viso/set-done":
			db({
				op: "update",
				id: message.memoryId,
				patch: { done_at: message.done ? Date.now() : null }
			}).then((r) => sendResponse({ ok: r.updated }), (error) => sendResponse({
				ok: false,
				error: String(error)
			}));
			return true;
		case "viso/set-due":
			setDue(message.memoryId, message.phrase).then(sendResponse, (error) => {
				sendResponse({
					ok: false,
					error: error instanceof Error ? error.message : String(error)
				});
			});
			return true;
		case "viso/edit-memory":
			editMemory(message.memoryId, message.text).then(sendResponse, (error) => {
				const reason = error instanceof Error ? error.message : String(error);
				log.error("edit failed", reason);
				sendResponse({
					ok: false,
					error: reason
				});
			});
			return true;
		case "viso/groups":
			db({ op: "listGroups" }).then((groups) => sendResponse({
				ok: true,
				groups: groups.map((group) => ({
					id: group.id,
					name: group.name,
					count: group.count
				}))
			})).catch(() => sendResponse({
				ok: true,
				groups: []
			}));
			return true;
		case "viso/create-group":
			db({
				op: "createGroup",
				name: message.name
			}).then(({ group, created }) => sendResponse({
				ok: true,
				created,
				group: {
					id: group.id,
					name: group.name,
					count: group.count
				}
			})).catch((error) => sendResponse({
				ok: false,
				error: error instanceof Error ? error.message : String(error)
			}));
			return true;
		case "viso/set-note-group":
			db({
				op: "setNoteGroup",
				id: message.memoryId,
				group_id: message.groupId
			}).then((result) => sendResponse({ ok: result.updated })).catch((error) => sendResponse({
				ok: false,
				error: error instanceof Error ? error.message : String(error)
			}));
			return true;
		case "viso/app-note":
			appNoteCommand(message.itemId, message.verb, message.text).then(sendResponse);
			return true;
		case "viso/delete-memory":
			db({
				op: "delete",
				id: message.memoryId
			});
			sendResponse({ ok: true });
			return false;
		case "viso/orb-summon":
			summonOrb(sender.tab?.id).then(sendResponse);
			return true;
		case "viso/open-hub":
			openHub();
			sendResponse({ ok: true });
			return false;
		default: {
			const unhandled = message;
			log.warn("unhandled content request", unhandled.type);
			return false;
		}
	}
});
/**
* Broadcasts from the offscreen document, and requests from the Agent Hub.
* None of these carry a protocol envelope, so they never reach the
* content-request handler above.
*/
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
	if (typeof message !== "object" || message === null) return false;
	const m = message;
	if (m.type === "viso/model-progress" && typeof m.progress === "object") {
		relayProgress(m.progress);
		return false;
	}
	if (m.type === "viso/persist-state" && typeof message.state === "object") {
		chrome.storage.local.set({ [PERSIST_STATE_KEY]: message.state }).catch((error) => log.warn("could not record the persistence result", error));
		return false;
	}
	if (m.type === "viso/hub-export") {
		exportAll().then((file) => sendResponse({
			ok: true,
			result: file
		})).catch((e) => sendResponse({
			ok: false,
			error: String(e)
		}));
		return true;
	}
	if (m.type === "viso/hub-import") {
		importBackup(m.file).then((result) => sendResponse({
			ok: true,
			result
		})).catch((e) => sendResponse({
			ok: false,
			error: e instanceof Error ? e.message : String(e)
		}));
		return true;
	}
	if (m.type === "viso/hub-models") {
		modelStatus("embedding").then((embedding) => sendResponse({
			ok: true,
			result: { embedding }
		})).catch((e) => sendResponse({
			ok: false,
			error: String(e)
		}));
		return true;
	}
	if (m.type === "viso/hub-download") {
		const kind = m.kind;
		if (kind !== "embedding") return false;
		requestModelNow(kind);
		sendResponse({
			ok: true,
			result: null
		});
		return false;
	}
	if (m.type === "viso/hub-desktop") {
		const wantsSync = m.sync === true;
		Promise.all([wantsSync ? syncDesktopNow() : desktopSyncStatus(), linkStatus()]).then(([sync, link]) => sendResponse({
			ok: true,
			result: {
				...sync,
				link
			}
		})).catch((e) => sendResponse({
			ok: false,
			error: String(e)
		}));
		return true;
	}
	if (m.type === "viso/hub-db" || m.type === "viso/hub-embed") {
		(m.type === "viso/hub-db" ? db(m.request) : embed(m.request)).then((result) => sendResponse({
			ok: true,
			result
		}), (error) => sendResponse({
			ok: false,
			error: error instanceof Error ? error.message : String(error)
		}));
		return true;
	}
	return false;
});
/**
* Platforms whose links open in a new tab.
*
* A document is a place you go to work, not a step in the page you are on:
* replacing the current tab with someone's spreadsheet loses whatever you were
* doing to get there. A Gmail thread or a Jira issue is movement within the
* site you are already in, so it stays in place.
*/
var NEW_TAB_PLATFORMS = PER_FILE_PLATFORMS;
/** How long the panel waits for the desktop app's share of a page's notes. */
var APP_NOTES_DEADLINE_MS = 800;
function toWire(row, site = false) {
	return {
		uid: `ext:${row.id}`,
		origin: "web",
		site,
		id: row.id,
		text: row.text,
		createdAt: row.created_at,
		remindAt: row.remind_at ?? null,
		doneAt: row.done_at ?? null,
		intent: row.intent,
		sourceTitle: row.source_title,
		sourceUrl: row.source_url,
		platformType: row.platform_type,
		deepLink: row.deep_link ?? row.source_url,
		selection: row.selection,
		openInNewTab: row.platform_type !== null && NEW_TAB_PLATFORMS.has(row.platform_type),
		contextHash: row.context_hash,
		groupId: row.group_id,
		groupName: row.group_name
	};
}
/**
* A note the Orb saved, as a row of the page's panel.
*
* Read-only here: the desktop app owns it, and the panel says so by offering
* no edit or delete rather than buttons that would have to fail. Its id is
* prefixed so the two stores cannot collide in one list.
*/
function toAppWire(item) {
	const intent = item.kind === "task" ? "TASK" : item.kind === "reminder" ? "REMINDER" : "REMEMBER";
	return {
		uid: `app:${item.id}`,
		origin: "desktop",
		site: item.site,
		id: 0,
		text: item.text,
		createdAt: item.createdAt,
		remindAt: item.dueAt ?? null,
		doneAt: item.done === true ? 1 : null,
		intent,
		sourceTitle: item.sourceTitle ?? item.sourceLabel,
		sourceUrl: item.deepLink,
		platformType: null,
		deepLink: item.deepLink,
		selection: null,
		openInNewTab: false,
		contextHash: null,
		groupId: null,
		groupName: item.groupName ?? null
	};
}
/** Mirrors the store's own derivation, so panel and database agree on "site". */
function hostOf(url) {
	if (url === null || url === "") return null;
	try {
		const host = new URL(url).hostname.replace(/^www\./, "");
		return host === "" ? null : host;
	} catch {
		return null;
	}
}
/**
* Toolbar click opens the Agent Hub, reusing the tab if one is already open
* rather than stacking duplicates each time.
*/
/**
* Focuses the Agent Hub, opening it if no tab has it yet.
*
* Shared by the toolbar button and by the notes shortcut's fallback, so both
* land in the same tab instead of stacking copies of it.
*/
function openHub() {
	const url = chrome.runtime.getURL("src/agenthub/agenthub.html");
	chrome.tabs.query({ url }).then((tabs) => {
		const existing = tabs[0];
		if (existing?.id !== void 0) {
			chrome.tabs.update(existing.id, { active: true });
			if (existing.windowId !== void 0) chrome.windows.update(existing.windowId, { focused: true });
			return;
		}
		chrome.tabs.create({ url });
	});
}
chrome.action.onClicked.addListener((tab) => {
	const tabId = tab.id;
	if (tabId === void 0) {
		openHub();
		return;
	}
	chrome.tabs.sendMessage(tabId, envelope({ type: "viso/toggle-panel" })).catch(() => openHub());
});
/**
* The keys. Ctrl+Space reaches Chrome only when the desktop app is not holding
* it system-wide — with the app running, the app hears the key and asks this
* extension where the user is, so nothing is summoned twice.
*/
chrome.commands.onCommand.addListener((command, tab) => {
	if (command === "summon-orb") {
		summonOrb(tab?.id).then((result) => {
			if (result.ok || tab?.id === void 0) return;
			chrome.tabs.sendMessage(tab.id, envelope({
				type: "viso/orb-unavailable",
				reason: result.reason
			})).catch(() => void 0);
		});
		return;
	}
	if (command === "toggle-notes") {
		const tabId = tab?.id;
		if (tabId === void 0) return;
		chrome.tabs.sendMessage(tabId, envelope({ type: "viso/toggle-panel" })).catch(() => {
			openHub();
		});
	}
});
//#endregion
