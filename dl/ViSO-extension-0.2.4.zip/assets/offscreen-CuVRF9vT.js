import "./modulepreload-polyfill-BsPm7yBB.js";
import { t as log } from "./log-BabVsn0h.js";
import { n as ensurePersistentStorage } from "./persist-Djg7lb2n.js";
//#region src/offscreen/offscreen.ts
var OFFSCREEN_TYPES = /* @__PURE__ */ new Set(["viso/db", "viso/embed"]);
function isOffscreenMessage(msg) {
	if (typeof msg !== "object" || msg === null) return false;
	const m = msg;
	return m["target"] === "offscreen" && typeof m["type"] === "string" && OFFSCREEN_TYPES.has(m["type"]);
}
/** Shared plumbing: correlate calls, fail everything in flight if a worker dies. */
var WorkerChannel = class {
	worker;
	nextId = 1;
	pending = /* @__PURE__ */ new Map();
	constructor(worker, name, onProgress) {
		this.worker = worker;
		worker.addEventListener("message", (event) => {
			const reply = event.data;
			if ("progress" in reply) {
				onProgress(reply.progress);
				return;
			}
			const resolve = this.pending.get(reply.id);
			if (resolve === void 0) return;
			this.pending.delete(reply.id);
			resolve(reply);
		});
		worker.addEventListener("error", (event) => {
			log.error(`${name} worker error`, event.message);
			for (const [id, resolve] of this.pending) resolve({
				id,
				ok: false,
				error: `${name} worker crashed: ${event.message}`
			});
			this.pending.clear();
		});
	}
	call(request) {
		const id = this.nextId++;
		return new Promise((resolve) => {
			this.pending.set(id, resolve);
			this.worker.postMessage({
				id,
				request
			});
		});
	}
};
function broadcastProgress(progress) {
	const message = {
		type: "viso/model-progress",
		progress
	};
	chrome.runtime.sendMessage(message).catch(() => {});
}
var dbChannel = new WorkerChannel(new Worker(new URL(
	/* @vite-ignore */
	"/assets/worker-DfYrfLAm.js",
	"" + import.meta.url
), { type: "module" }), "db", () => {});
var embedChannel = new WorkerChannel(new Worker(new URL(
	/* @vite-ignore */
	"/assets/worker-Duy-ox0r.js",
	"" + import.meta.url
), { type: "module" }), "embed", broadcastProgress);
ensurePersistentStorage();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
	if (!isOffscreenMessage(message)) return false;
	(message.type === "viso/db" ? dbChannel : embedChannel).call(message.request).then(sendResponse);
	return true;
});
//#endregion
