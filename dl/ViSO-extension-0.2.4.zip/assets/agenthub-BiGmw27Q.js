import "./modulepreload-polyfill-BsPm7yBB.js";
import { i as readPersistState, r as isExempt } from "./persist-Djg7lb2n.js";
import { n as icon, r as star, t as comet } from "./icons-BegmdKu1.js";
import { n as runQuery, t as describeQuery } from "./run-9NZ7aDl7.js";
//#region src/agenthub/styles.ts
var HUB_STYLES = `
/*
 * Agent Hub — the extension's home page, in the "Light Blue Minimal" design
 * the desktop panel and the HUD wear (Figma, 2026-09-14), with the theme's
 * cat and stars: a navy title bar with cat ears and the cat peeking over it,
 * then glass cards on a sky-blue sheet.
 */
:root {
  --sky-top: #eaf3ff;
  --sky-bottom: #cfe1fa;
  --navy: #0f2a66;
  --navy-2: #1a3f8f;
  --panel: linear-gradient(165deg, #d6e8fd 0%, #c9def9 50%, #c2d8f6 100%);
  --panel-edge: rgba(255, 255, 255, 0.85);
  --glass: rgba(255, 255, 255, 0.5);
  --glass-hover: rgba(255, 255, 255, 0.68);
  --glass-edge: rgba(255, 255, 255, 0.9);
  --tile: rgba(196, 218, 250, 0.75);
  --accent: #2f6fe8;
  --accent-soft: rgba(47, 111, 232, 0.16);
  --accent-gradient: linear-gradient(180deg, #3d84ff 0%, #2560e0 100%);
  --accent-glow: rgba(47, 111, 232, 0.35);
  --success: #22c55e;
  --danger: #d34b43;
  --warn: #f2b422;
  --text: #1b2b4b;
  --text-2: #5f7396;
  --text-3: #8ea0bd;
  --cat: #16181f;
  --cat-rim: #f2cf5b;
  --cat-eye: #ffd166;
  --cloud: #ffffff;
  --font: 'Inter', 'SF Pro Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  --radius-card: 20px;
  --radius-pill: 999px;
  color-scheme: light;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  padding: 36px 20px 80px;
  min-height: 100vh;
  background: linear-gradient(180deg, var(--sky-top) 0%, var(--sky-bottom) 100%) fixed;
  color: var(--text);
  font: 400 15px/1.5 var(--font);
  -webkit-font-smoothing: antialiased;
}

.wrap { max-width: 1040px; margin: 0 auto; }

/* ---- The window: a navy title bar with cat ears, the cat peeking over it ---- */

.window {
  position: relative;
  margin-top: 34px;
  border-radius: 28px;
  background: var(--panel);
  border: 1.5px solid var(--panel-edge);
  box-shadow: 0 24px 60px rgba(30, 60, 120, 0.22);
}

.titlebar {
  position: relative;
  display: flex;
  align-items: center;
  gap: 14px;
  height: 64px;
  padding: 0 28px 0 24px;
  border-radius: 26px 26px 0 0;
  background: linear-gradient(90deg, var(--navy) 0%, var(--navy-2) 60%, #2a5bc0 100%);
  color: #fff;
  overflow: visible;
}

/* The ears, growing out of the bar's top edge. */
.titlebar::before,
.titlebar::after {
  content: '';
  position: absolute;
  top: -18px;
  width: 34px;
  height: 30px;
  background: var(--navy);
  clip-path: polygon(0 100%, 50% 0, 100% 100%);
}
.titlebar::before { left: 22px; }
.titlebar::after { left: 62px; }

.titlebar__name {
  margin: 0;
  font-size: 26px;
  font-weight: 700;
  letter-spacing: -0.02em;
}

.titlebar__sub {
  margin: 0;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.72);
}

.titlebar__comet { flex: none; margin: -18px 0 0 -4px; }
.titlebar__spark { position: absolute; }
.titlebar__spark--a { left: 118px; top: 8px; }
.titlebar__spark--b { right: 190px; top: 14px; opacity: 0.8; }

.titlebar__cat {
  position: absolute;
  right: 36px;
  bottom: 12px;
  line-height: 0;
  filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.25));
}

.titlebar__actions {
  margin-left: auto;
  margin-right: 140px;
  display: flex;
  gap: 8px;
}

/* ---- The grid of sections ---- */

.grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 20px;
  padding: 24px;
}
@media (max-width: 820px) { .grid { grid-template-columns: 1fr; } }

.hub-card {
  position: relative;
  min-width: 0;
  padding: 18px 20px 20px;
  border-radius: var(--radius-card);
  background: var(--glass);
  border: 1.5px solid var(--glass-edge);
}
.hub-card--wide { grid-column: 1 / -1; }

.hub-card__head {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}

.hub-card__tile {
  flex: none;
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: var(--tile);
  color: var(--accent);
}

.hub-card__title {
  margin: 0;
  font-size: 19px;
  font-weight: 700;
  letter-spacing: -0.01em;
}

.hub-card__count {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-2);
}

.hub-card__spark { position: absolute; right: 18px; top: 16px; }

.hub-card__body { display: flex; flex-direction: column; gap: 10px; }

/* ---- A note ---- */

.memory {
  position: relative;
  padding: 12px 14px 12px;
  border-radius: 16px;
  background: var(--glass-hover);
  border: 1.5px solid var(--glass-edge);
}
.memory__row { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; }
.memory__kind {
  flex: none;
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  background: var(--tile);
  color: var(--accent);
}
.memory__kind--reminder { color: #b86e00; }
.memory__kind--task { color: #1f8a3a; }
.memory__text { margin: 0; font-size: 16px; font-weight: 500; line-height: 1.35; overflow-wrap: anywhere; }
.memory__meta {
  margin: 6px 0 0;
  font-size: 13px;
  color: var(--text-2);
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
}
.memory__meta a { color: var(--accent); text-decoration: none; font-weight: 500; overflow-wrap: anywhere; }
.memory__meta a:hover { text-decoration: underline; }

.tag {
  font-size: 11.5px;
  font-weight: 700;
  letter-spacing: 0.04em;
  padding: 2px 9px;
  border-radius: var(--radius-pill);
  background: var(--accent-soft);
  color: var(--accent);
}
.tag--group::before { content: '# '; opacity: 0.6; }

.empty { color: var(--text-2); font-size: 14px; margin: 0; }
.score { font-variant-numeric: tabular-nums; color: var(--accent); font-weight: 600; }

/* ---- Controls ---- */

.btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  height: 38px;
  padding: 0 16px;
  border-radius: var(--radius-pill);
  border: 1.5px solid var(--glass-edge);
  background: var(--glass);
  color: var(--text);
  cursor: pointer;
  text-decoration: none;
  transition: background 140ms ease;
}
.btn:hover { background: var(--glass-hover); }
.btn--primary,
.btn--primary:hover {
  background: var(--accent-gradient);
  border-color: transparent;
  color: #fff;
  box-shadow: 0 8px 20px var(--accent-glow);
}
.btn--primary:hover { filter: brightness(1.06); }
.btn:disabled { opacity: 0.55; cursor: default; box-shadow: none; }
.btn--ghost { background: rgba(255, 255, 255, 0.14); border-color: rgba(255, 255, 255, 0.35); color: #fff; }
.btn--ghost:hover { background: rgba(255, 255, 255, 0.24); }

.row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }

.search { display: flex; gap: 10px; }
.search__field {
  flex: 1;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 44px;
  padding: 0 16px;
  border-radius: var(--radius-pill);
  border: 1.5px solid var(--glass-edge);
  background: var(--glass);
  color: var(--text-2);
}
.search__field:focus-within { border-color: var(--accent); }
.search__field input {
  flex: 1;
  min-width: 0;
  font: inherit;
  font-size: 15px;
  border: none;
  outline: none;
  background: transparent;
  color: var(--text);
}
.search__field input::placeholder { color: var(--text-2); }

.chips { display: flex; flex-wrap: wrap; gap: 8px; }
.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  padding: 0 14px;
  border-radius: var(--radius-pill);
  border: 1.5px solid var(--glass-edge);
  background: var(--glass);
  font: inherit;
  font-size: 14px;
  font-weight: 500;
  color: var(--text);
  cursor: pointer;
}
.chip:hover { background: var(--glass-hover); }
.chip--on, .chip--on:hover { background: var(--accent-gradient); border-color: transparent; color: #fff; box-shadow: 0 6px 16px var(--accent-glow); }
.chip__count { color: var(--text-2); font-variant-numeric: tabular-nums; }
.chip--on .chip__count { color: rgba(255, 255, 255, 0.8); }

/* ---- Status lines: a dot, then the words ---- */

.status { display: flex; align-items: flex-start; gap: 10px; margin: 0; font-size: 14px; color: var(--text-2); line-height: 1.45; }
.status__dot { flex: none; width: 10px; height: 10px; margin-top: 6px; border-radius: 50%; background: var(--text-3); }
.status--ok .status__dot { background: var(--success); box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.18); }
.status--warn .status__dot { background: var(--warn); box-shadow: 0 0 0 4px rgba(242, 180, 34, 0.2); }
.status--bad .status__dot { background: var(--danger); box-shadow: 0 0 0 4px rgba(211, 75, 67, 0.18); }
.status--busy .status__dot { background: var(--accent); animation: pulse 1.2s ease-in-out infinite; }
@keyframes pulse { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }

/* ---- The model's progress bar ---- */

.bar {
  height: 10px;
  border-radius: var(--radius-pill);
  background: rgba(47, 111, 232, 0.14);
  overflow: hidden;
}
.bar__fill { height: 100%; width: 0; border-radius: inherit; background: var(--accent-gradient); transition: width 300ms ease; }
.bar--busy .bar__fill { width: 35%; animation: sweep 1.4s ease-in-out infinite; }
@keyframes sweep { 0% { transform: translateX(-100%); } 100% { transform: translateX(300%); } }

.kv { display: flex; justify-content: space-between; gap: 12px; font-size: 14px; color: var(--text-2); }
.kv strong { color: var(--text); font-weight: 600; }

.hub-card__cat { position: absolute; right: 14px; bottom: 6px; line-height: 0; pointer-events: none; }

.footer { margin: 18px 4px 0; font-size: 13px; color: var(--text-2); text-align: center; }
`;
//#endregion
//#region src/agenthub/decor.ts
var SVG_NS = "http://www.w3.org/2000/svg";
function node(tag, attrs) {
	const element = document.createElementNS(SVG_NS, tag);
	for (const [key, value] of Object.entries(attrs)) element.setAttribute(key, value);
	return element;
}
/**
* The cat, peeking over the title bar — ears, a happy closed-eyed face, two
* paws on the edge. Black on the navy bar, with a thin gold rim the way the
* theme's stickers have.
*/
function peekingCat(width = 120) {
	const svg = node("svg", {
		viewBox: "0 0 120 70",
		width: String(width),
		height: String(Math.round(width * 70 / 120)),
		"aria-hidden": "true",
		focusable: "false"
	});
	const g = node("g", {
		fill: "var(--cat)",
		stroke: "var(--cat-rim)",
		"stroke-width": "1.5",
		"stroke-linejoin": "round"
	});
	g.append(node("path", { d: "M22 34 L14 6 L40 22 Z" }));
	g.append(node("path", { d: "M98 34 L106 6 L80 22 Z" }));
	g.append(node("path", { d: "M18 40 C18 22 30 16 60 16 C90 16 102 22 102 40 C102 56 90 64 60 64 C30 64 18 56 18 40 Z" }));
	g.append(node("ellipse", {
		cx: "34",
		cy: "66",
		rx: "12",
		ry: "5"
	}));
	g.append(node("ellipse", {
		cx: "86",
		cy: "66",
		rx: "12",
		ry: "5"
	}));
	svg.append(g);
	const face = node("g", {
		fill: "none",
		stroke: "#ffffff",
		"stroke-width": "2.2",
		"stroke-linecap": "round"
	});
	face.append(node("path", { d: "M40 40 C43 36 49 36 52 40" }));
	face.append(node("path", { d: "M68 40 C71 36 77 36 80 40" }));
	face.append(node("path", { d: "M56 47 C58 50 62 50 64 47" }));
	face.append(node("path", {
		d: "M22 44 L34 46 M22 50 L34 49",
		"stroke-width": "1.6"
	}));
	face.append(node("path", {
		d: "M98 44 L86 46 M98 50 L86 49",
		"stroke-width": "1.6"
	}));
	svg.append(face);
	return svg;
}
/** The cat sitting on a cloud, small, for a card's corner. */
function catOnCloud(width = 64) {
	const svg = node("svg", {
		viewBox: "0 0 100 110",
		width: String(width),
		height: String(Math.round(width * 1.1)),
		"aria-hidden": "true",
		focusable: "false"
	});
	const cloud = node("g", { fill: "var(--cloud)" });
	cloud.append(node("ellipse", {
		cx: "52",
		cy: "98",
		rx: "46",
		ry: "11"
	}));
	cloud.append(node("circle", {
		cx: "22",
		cy: "90",
		r: "14"
	}));
	cloud.append(node("circle", {
		cx: "46",
		cy: "84",
		r: "17"
	}));
	cloud.append(node("circle", {
		cx: "72",
		cy: "88",
		r: "14"
	}));
	svg.append(cloud);
	const cat = node("g", { fill: "var(--cat)" });
	cat.append(node("path", { d: "M66 88 C82 90 90 74 82 62 C78 56 70 58 70 64 C70 69 76 70 78 66 C82 72 78 82 66 82 Z" }));
	cat.append(node("path", { d: "M34 92 C26 78 28 58 40 46 L60 46 C72 58 74 78 66 92 Z" }));
	cat.append(node("path", { d: "M32 36 L30 12 L44 24 L56 22 L66 8 L64 34 C64 44 58 50 50 50 C42 50 34 44 32 36 Z" }));
	svg.append(cat);
	const eyes = node("g", { fill: "var(--cat-eye)" });
	eyes.append(node("ellipse", {
		cx: "45",
		cy: "36",
		rx: "2.2",
		ry: "2.8"
	}));
	eyes.append(node("ellipse", {
		cx: "57",
		cy: "34",
		rx: "2.2",
		ry: "2.8"
	}));
	svg.append(eyes);
	return svg;
}
//#endregion
//#region src/agenthub/agenthub.ts
/** The Hub is an extension page, so it talks to the background like anyone else. */
var api = {
	db: (request) => send({
		type: "viso/hub-db",
		request
	}),
	embed: (request) => send({
		type: "viso/hub-embed",
		request
	})
};
async function send(message) {
	const r = await chrome.runtime.sendMessage(message);
	if (r?.ok !== true) throw new Error(r?.error ?? "request failed");
	return r.result;
}
function main() {
	document.head.appendChild(styleTag());
	const root = document.getElementById("root");
	if (root === null) return;
	const wrap = el("div", "wrap");
	const window_ = el("div", "window");
	const grid = el("div", "grid");
	grid.append(section("Cần chú ý", "now", "bell", "Việc và lời nhắc chưa xong"), section("Vừa nhớ", "recent", "note", "Ghi chú mới nhất, mọi trang"), searchSection(), groupsSection(), modelsSection(), desktopSection(), dataSection());
	window_.append(heading(), grid);
	const footer = el("p", "footer");
	footer.textContent = "ViSO giữ mọi thứ trên máy này. Không có gì rời khỏi trình duyệt trừ khi bạn tải xuống bản sao lưu.";
	wrap.append(window_, footer);
	root.append(wrap);
	loadNow();
	loadRecent();
	loadModels();
}
function styleTag() {
	const style = document.createElement("style");
	style.textContent = HUB_STYLES;
	return style;
}
/** The title bar: the name, a comet, the cat peeking over the edge. */
function heading() {
	const bar = el("header", "titlebar");
	const name = el("h1", "titlebar__name");
	name.textContent = "ViSO";
	const sub = el("p", "titlebar__sub");
	sub.textContent = "ghi chú của mọi trang, trên máy này";
	const actions = el("div", "titlebar__actions");
	const open = el("a", "btn btn--ghost");
	open.href = "https://github.com/nhanho133/Viso/releases/latest";
	open.target = "_blank";
	open.rel = "noopener noreferrer";
	open.append(icon("external", 15), textNode("App desktop"));
	actions.append(open);
	const cat = el("span", "titlebar__cat");
	cat.append(peekingCat(110));
	bar.append(name, comet(110, "up-right", "titlebar__comet"), sub, star(16, "titlebar__spark titlebar__spark--a"), star(12, "titlebar__spark titlebar__spark--b"), actions, cat);
	return bar;
}
/** A section card: an icon tile, a title, a count, and whatever goes in it. */
function card(title, iconName, sub, wide = false) {
	const node = el("section", wide ? "hub-card hub-card--wide" : "hub-card");
	const head = el("div", "hub-card__head");
	const tile = el("span", "hub-card__tile");
	tile.append(icon(iconName, 20));
	const titleEl = el("h2", "hub-card__title");
	titleEl.textContent = title;
	const count = el("span", "hub-card__count");
	if (sub !== null) count.textContent = sub;
	head.append(tile, titleEl, count);
	const body = el("div", "hub-card__body");
	node.append(head, star(16, "hub-card__spark"), body);
	return {
		card: node,
		body,
		count
	};
}
function modelsSection() {
	const { card: node, body } = card("Mô hình", "sparkle", "tự tải khi cài, không cần mở trang");
	body.id = "models";
	return node;
}
/**
* The only place a declined download can be started again.
*
* Without it, pressing "Để sau" once on the in-page card disabled semantic
* memory or voice with no control anywhere to bring it back.
*/
async function loadModels() {
	const container = document.getElementById("models");
	if (container === null) return;
	try {
		const models = await send({ type: "viso/hub-models" });
		container.replaceChildren(modelRow("embedding", "Trí nhớ ngữ nghĩa", models.embedding));
		if (!models.embedding.downloaded) setTimeout(() => void loadModels(), models.embedding.downloading ? 1500 : 4e3);
	} catch (error) {
		container.replaceChildren(message(`Không đọc được trạng thái: ${String(error)}`));
	}
}
function modelRow(kind, title, state) {
	const node = el("div", "memory");
	const row = el("div", "memory__row");
	const tile = el("span", "memory__kind");
	tile.append(icon("sparkle", 16));
	const text = el("p", "memory__text");
	text.textContent = title;
	row.append(tile, text);
	const total = state.bytesTotal ?? 0;
	const loaded = state.bytesLoaded ?? 0;
	const known = state.downloading && total > 0;
	const bar = el("div", state.downloaded || known ? "bar" : state.downloading ? "bar bar--busy" : "bar");
	const fill = el("div", "bar__fill");
	if (state.downloaded) fill.style.width = "100%";
	else if (known) fill.style.width = `${Math.max(2, Math.min(100, Math.round(loaded / total * 100)))}%`;
	bar.append(fill);
	const kv = el("p", "kv");
	const left = el("span", "");
	left.textContent = state.label;
	const right = el("strong", "");
	right.textContent = state.downloaded ? `Đã tải · ${formatBytes(state.totalBytes)}` : known ? `Đang tải · ${formatBytes(loaded)} / ${formatBytes(total)}` : state.downloading ? `Đang tải · ${formatBytes(state.totalBytes)}` : `Chưa tải · ${formatBytes(state.totalBytes)}`;
	kv.append(left, right);
	const status = statusLine(state.downloaded ? "ok" : state.downloading ? "busy" : "warn", state.downloaded ? "Tìm theo ý nghĩa đang bật. Tải một lần, dùng mãi trên máy này." : state.downloading ? "Đang tải về nền — không cần giữ trang này mở. Tự thử lại nếu mất mạng." : "Chưa có trên máy. ViSO tự tải khi cài và thử lại mỗi vài phút; bấm để tải ngay.");
	node.append(row, bar, kv, status);
	if (!state.downloaded && !state.downloading) {
		const button = el("button", "btn btn--primary");
		button.type = "button";
		button.append(textNode("Tải ngay"), star(14));
		button.style.marginTop = "4px";
		button.addEventListener("click", () => {
			button.disabled = true;
			button.replaceChildren(textNode("Đang tải…"));
			send({
				type: "viso/hub-download",
				kind
			}).catch(() => {
				button.disabled = false;
				button.replaceChildren(textNode("Thử lại"));
			});
		});
		node.append(button);
	}
	return node;
}
/** A coloured dot and a sentence. */
function statusLine(kind, text) {
	const p = el("p", kind === "idle" ? "status" : `status status--${kind}`);
	const dot = el("span", "status__dot");
	const words = el("span", "");
	words.textContent = text;
	p.append(dot, words);
	return p;
}
function formatBytes(bytes) {
	const mb = bytes / 1048576;
	return mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${Math.round(mb)} MB`;
}
/**
* Export and import.
*
* Everything lives in one OPFS database owned by the extension, and removing
* the extension deletes it — silently, and permanently. Somewhere to put a copy
* is the difference between a scratchpad and something worth relying on.
*/
function dataSection() {
	const { card: node, body } = card("Dữ liệu", "folder", "sao lưu và độ bền");
	const backup = el("div", "memory");
	const text = el("p", "memory__text");
	text.textContent = "Sao lưu và khôi phục";
	const meta = el("p", "memory__meta");
	meta.append(textNode("Toàn bộ ghi chú, dạng JSON đọc được"));
	const row = el("div", "row");
	row.style.marginTop = "10px";
	const save = el("button", "btn btn--primary");
	save.type = "button";
	save.append(icon("external", 15), textNode("Tải xuống"));
	save.addEventListener("click", () => void downloadBackup(save, meta));
	const load = el("button", "btn");
	load.type = "button";
	load.append(icon("folder", 15), textNode("Khôi phục"));
	const picker = el("input", "");
	picker.type = "file";
	picker.accept = "application/json,.json";
	picker.hidden = true;
	picker.addEventListener("change", () => void restoreBackup(picker, load, meta));
	load.addEventListener("click", () => picker.click());
	row.append(save, load, picker);
	backup.append(text, meta, row);
	body.append(backup, durabilityCard());
	return node;
}
/**
* The desktop app: whether it is there, whether the Orb can reach this
* browser, and where to get it. Its own card, because "the widget has no web
* notes" is the question people open this page with.
*/
function desktopSection() {
	const { card: node, body } = card("App desktop", "mic", "Orb, Ctrl+Space trên mọi trang");
	const get = el("div", "memory");
	const text = el("p", "memory__text");
	text.textContent = "Nói là ghi — Orb của app desktop nghe, và ghi thẳng vào trang đang mở.";
	const meta = el("p", "memory__meta");
	meta.append(textNode("Windows và macOS · bản mới nhất trên GitHub"));
	const row = el("div", "row");
	row.style.marginTop = "10px";
	const link = el("a", "btn btn--primary");
	link.href = "https://github.com/nhanho133/Viso/releases/latest";
	link.target = "_blank";
	link.rel = "noopener noreferrer";
	link.append(icon("external", 15), textNode("Tải app desktop"));
	row.append(link);
	get.append(text, meta, row);
	const cat = el("span", "hub-card__cat");
	cat.append(catOnCloud(56));
	body.append(get, desktopCard());
	node.append(cat);
	return node;
}
/**
* Whether Chrome has actually promised to keep the database.
*
* Reported rather than assumed. `unlimitedStorage` plus `persist()` should get
* this every time, and "should" is exactly the word that makes a data-loss bug
* invisible for months. If the answer is no, the honest advice changes — a
* backup stops being good practice and becomes the only thing standing between
* the user and losing everything to a full disk.
*/
function durabilityCard() {
	const card = el("div", "memory");
	const text = el("p", "memory__text");
	text.textContent = "Độ bền dữ liệu";
	const meta = el("p", "memory__meta");
	meta.append(statusLine("busy", "Đang kiểm tra…"));
	card.append(text, meta);
	(async () => {
		const state = await readPersistState();
		if (state === null) {
			meta.replaceChildren(statusLine("idle", "Chưa kiểm tra — mở một trang bất kỳ rồi quay lại"));
			return;
		}
		const used = state.usage === null ? "" : ` · đang dùng ${formatSize(state.usage)}`;
		if (state.persisted) {
			meta.replaceChildren(statusLine("ok", `Chrome đã cam kết giữ dữ liệu, không tự xoá khi thiếu ổ đĩa${used}`));
			return;
		}
		if (isExempt(state)) {
			meta.replaceChildren(statusLine("ok", `Được miễn giới hạn lưu trữ (unlimitedStorage) — không bị xoá khi thiếu ổ đĩa${used}`));
			return;
		}
		const why = state.error === void 0 ? "" : ` (${state.error})`;
		meta.replaceChildren(statusLine("bad", `Chrome CHƯA cam kết giữ dữ liệu${why}. Có thể bị xoá khi máy hết ổ đĩa — hãy tải xuống bản sao lưu thường xuyên.`));
	})();
	return card;
}
/**
* Whether the ViSO desktop app is receiving this browser's notes.
*
* Shown with what to do about each state, because every failure here has a
* different fix and all of them look the same from inside the browser: the
* desktop widget simply has no web notes in it.
*/
function desktopCard() {
	const card = el("div", "memory");
	const text = el("p", "memory__text");
	text.textContent = "Kết nối";
	const meta = el("div", "hub-card__body");
	meta.append(statusLine("busy", "Đang kiểm tra…"));
	const row = el("div", "row");
	row.style.marginTop = "10px";
	const syncBtn = el("button", "btn");
	syncBtn.type = "button";
	syncBtn.append(icon("check", 15), textNode("Đồng bộ ngay"));
	row.append(syncBtn);
	const render = (status) => {
		const value = status;
		const linkKind = value.link?.state === "connected" ? "ok" : value.link?.state === "connecting" ? "busy" : "warn";
		const syncKind = value.state === "ok" ? "ok" : value.state === "never" ? "idle" : "bad";
		meta.replaceChildren(statusLine(linkKind, describeLink(value.link)), statusLine(syncKind, describeDesktop(value)));
	};
	syncBtn.addEventListener("click", () => {
		(async () => {
			syncBtn.disabled = true;
			meta.replaceChildren(statusLine("busy", "Đang gửi…"));
			try {
				render(await send({
					type: "viso/hub-desktop",
					sync: true
				}));
			} catch (error) {
				meta.replaceChildren(statusLine("bad", `Không đồng bộ được: ${String(error)}`));
			} finally {
				syncBtn.disabled = false;
			}
		})();
	});
	send({ type: "viso/hub-desktop" }).then(render, () => {
		meta.replaceChildren(statusLine("bad", "Không đọc được trạng thái kết nối"));
	});
	card.append(text, meta, row);
	return card;
}
/**
* Whether the Orb can reach this browser right now.
*
* Separate from the sync line below, and first, because it is the question
* behind every "I pressed Ctrl+Space and the note went to the desktop": the
* app only files on a page when this link is open.
*/
function describeLink(link) {
	switch (link?.state) {
		case "connected": return `Orb ghi được vào trang · app ${link.desktopVersion ?? "đang chạy"}`;
		case "connecting": return "Đang kết nối tới app desktop…";
		case "mismatch": return "App desktop khác phiên bản với extension — cập nhật cả hai.";
		default: return "Chưa kết nối app desktop: nói trên web sẽ lưu vào máy tính, không vào trang. Mở app desktop rồi tải lại tab.";
	}
}
function describeDesktop(status) {
	const when = status.at > 0 ? ` · ${new Date(status.at).toLocaleString("vi-VN")}` : "";
	switch (status.state) {
		case "never": return "Chưa đồng bộ lần nào";
		case "ok": return `Đã gửi ${status.count} ghi chú lên app desktop${when}`;
		case "not-installed": return "Chưa thấy app desktop ViSO. Cài và mở app desktop một lần để nó tự đăng ký với trình duyệt.";
		case "forbidden": return "App desktop đã đăng ký nhưng không nhận extension này. Mở lại app desktop bản mới nhất để nó đăng ký lại.";
		case "host-error": return `App desktop nhận nhưng báo lỗi: ${status.error ?? "không rõ"}${when}`;
		case "error": return `Lỗi đồng bộ: ${status.error ?? "không rõ"}${when}`;
	}
}
async function downloadBackup(button, meta) {
	button.disabled = true;
	try {
		const file = await send({ type: "viso/hub-export" });
		const url = URL.createObjectURL(new Blob([JSON.stringify(file, null, 2)], { type: "application/json" }));
		const a = document.createElement("a");
		a.href = url;
		a.download = `viso-memories-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
		a.click();
		URL.revokeObjectURL(url);
		meta.replaceChildren(textNode(`Đã tải xuống ${file.count} ghi chú`));
	} catch (error) {
		meta.replaceChildren(textNode(`Không tải xuống được: ${String(error)}`));
	} finally {
		button.disabled = false;
	}
}
async function restoreBackup(picker, button, meta) {
	const file = picker.files?.[0];
	if (file === void 0) return;
	button.disabled = true;
	try {
		const result = await send({
			type: "viso/hub-import",
			file: JSON.parse(await file.text())
		});
		meta.replaceChildren(textNode(`Thêm ${result.added}, bỏ qua ${result.skipped} (đã có)` + (result.errors > 0 ? `, lỗi ${result.errors}` : "")));
		loadRecent();
		loadNow();
	} catch (error) {
		meta.replaceChildren(textNode(`Không khôi phục được: ${error instanceof Error ? error.message : String(error)}`));
	} finally {
		button.disabled = false;
		picker.value = "";
	}
}
function section(title, id, iconName, sub) {
	const { card: node, body } = card(title, iconName, sub);
	body.id = id;
	const empty = el("p", "empty");
	empty.textContent = "Chưa có gì.";
	body.append(empty);
	return node;
}
async function loadNow() {
	render("now", (await api.db({
		op: "list",
		query: { limit: 100 }
	})).filter((r) => r.intent === "TASK" || r.intent === "REMINDER").slice(0, 20));
}
async function loadRecent() {
	render("recent", await api.db({
		op: "list",
		query: { limit: 20 }
	}));
}
/**
* Every group, and each one's notes from every site.
*
* The HUD shows a group's notes only where the user is standing. This is the
* one place to see "everything about Khách hàng A" at once — the Gmail thread,
* the proposal in Docs and the reminder from Slack, together.
*/
function groupsSection() {
	const { card: wrapper, body, count } = card("Nhóm", "folder", null);
	const chips = el("div", "chips");
	const results = el("div", "hub-card__body");
	body.append(chips, results);
	(async () => {
		let groups = [];
		try {
			groups = await api.db({ op: "listGroups" });
		} catch {
			groups = [];
		}
		count.textContent = groups.length === 0 ? "" : `${groups.length} nhóm`;
		if (groups.length === 0) {
			chips.replaceChildren(message("Chưa có nhóm nào. Tạo nhóm ngay trong HUD, ở ô soạn ghi chú."));
			return;
		}
		const open = async (group, button) => {
			for (const other of chips.querySelectorAll("button")) other.classList.remove("chip--on");
			button.classList.add("chip--on");
			results.replaceChildren(message("Đang tải…"));
			try {
				const rows = await api.db({
					op: "listByGroup",
					group_id: group.id,
					limit: 200
				});
				results.replaceChildren(...rows.length === 0 ? [message(`Nhóm “${group.name}” chưa có ghi chú nào.`)] : rows.map((row) => memoryCard(row, null)));
			} catch (error) {
				results.replaceChildren(message(`Không tải được: ${error instanceof Error ? error.message : String(error)}`));
			}
		};
		chips.replaceChildren(...groups.map((group) => {
			const button = el("button", "chip");
			button.setAttribute("type", "button");
			const n = el("span", "chip__count");
			n.textContent = String(group.count);
			button.append(icon("folder", 14), textNode(group.name), n);
			button.addEventListener("click", () => void open(group, button));
			return button;
		}));
	})();
	return wrapper;
}
function searchSection() {
	const { card: wrapper, body } = card("Tìm kiếm", "search", "theo ý nghĩa, mọi trang", true);
	const form = el("div", "search");
	const field = el("label", "search__field");
	const input = el("input", "");
	input.type = "search";
	input.placeholder = "Tìm theo ý nghĩa, không cần đúng từ…";
	field.append(icon("search", 18), input, star(18));
	const button = el("button", "btn btn--primary");
	button.type = "button";
	button.append(textNode("Tìm"), star(14));
	const results = el("div", "hub-card__body");
	results.id = "search";
	const run = () => void search(input.value, results, button);
	button.addEventListener("click", run);
	input.addEventListener("keydown", (event) => {
		if (event.key === "Enter") run();
	});
	form.append(field, button);
	body.append(form, results);
	return wrapper;
}
async function search(query, results, button) {
	const text = query.trim();
	if (text === "") return;
	button.disabled = true;
	results.replaceChildren(message("Đang tìm…"));
	try {
		const { hits, spec, semantic } = await runQuery(text, {
			context_hash: null,
			source_host: null
		}, {
			search: (q) => api.db({
				op: "search",
				query: q
			}),
			embedQuery: async (t) => {
				try {
					return (await api.embed({
						op: "embedQuery",
						text: t
					})).vector;
				} catch {
					return null;
				}
			}
		});
		const heading = message(semantic ? describeQuery(spec, hits.length) : `${describeQuery(spec, hits.length)} · chỉ khớp từ khoá`);
		results.replaceChildren(heading, ...hits.length === 0 ? [message("Không tìm thấy gì.")] : hits.map((hit) => memoryCard(hit.memory, hit.score)));
	} catch (error) {
		results.replaceChildren(message(`Không tìm được: ${error instanceof Error ? error.message : String(error)}`));
	} finally {
		button.disabled = false;
	}
}
function render(id, rows) {
	const container = document.getElementById(id);
	if (container === null) return;
	container.replaceChildren(...rows.length === 0 ? [message("Chưa có gì.")] : rows.map((row) => memoryCard(row, null)));
}
var KIND = {
	REMEMBER: {
		icon: "note",
		label: "Ghi chú",
		cls: ""
	},
	TASK: {
		icon: "task",
		label: "Việc",
		cls: " memory__kind--task"
	},
	REMINDER: {
		icon: "bell",
		label: "Lời nhắc",
		cls: " memory__kind--reminder"
	}
};
function memoryCard(row, score) {
	const card = el("div", "memory");
	const kind = KIND[row.intent] ?? KIND.REMEMBER;
	const head = el("div", "memory__row");
	const tile = el("span", `memory__kind${kind.cls}`);
	tile.append(icon(kind.icon, 15));
	const text = el("p", "memory__text");
	text.textContent = row.text;
	head.append(tile, text);
	const meta = el("p", "memory__meta");
	const tag = el("span", "tag");
	tag.textContent = kind.label;
	meta.append(tag);
	if (row.group_name !== null) {
		const group = el("span", "tag tag--group");
		group.textContent = row.group_name;
		meta.append(group);
	}
	meta.append(textNode(formatDate(row.created_at)));
	const href = row.deep_link ?? row.source_url;
	const label = row.source_title !== null && row.source_title !== "" ? row.source_title : hostnameOf(href);
	if (href !== null && href !== "") {
		const link = el("a", "");
		link.href = href;
		link.target = "_blank";
		link.rel = "noopener noreferrer";
		link.textContent = label ?? href;
		meta.append(link);
	} else if (label !== null) meta.append(textNode(label));
	if (score !== null) {
		const s = el("span", "score");
		s.textContent = `${Math.round(score * 100)}%`;
		meta.append(s);
	}
	if (!row.has_embedding) meta.append(textNode("chưa lập chỉ mục"));
	card.append(head, meta);
	return card;
}
/** "https://mail.google.com/mail/u/0/#inbox/abc" -> "mail.google.com" */
function hostnameOf(url) {
	if (url === null || url === "") return null;
	try {
		return new URL(url).hostname.replace(/^www\./, "");
	} catch {
		return url;
	}
}
function formatDate(timestamp) {
	return new Date(timestamp).toLocaleString("vi-VN", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function message(text) {
	const p = el("p", "empty");
	p.textContent = text;
	return p;
}
function textNode(text) {
	const span = document.createElement("span");
	span.textContent = text;
	return span;
}
function el(tag, className) {
	const node = document.createElement(tag);
	if (className !== "") node.className = className;
	return node;
}
main();
function formatSize(bytes) {
	const mb = bytes / 1048576;
	return mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${Math.max(1, Math.round(mb))} MB`;
}
//#endregion
