import { i as toEntity, n as parseWhen, r as extractPeople } from "./parse-fgDs-rmF.js";
function envelope(msg) {
	return {
		...msg,
		v: 3
	};
}
/**
* Typed wrapper over chrome.runtime.sendMessage.
*
* Resolves to `null` instead of throwing when the receiving end is gone — that
* happens routinely (service worker asleep mid-send, extension reloaded, tab
* being torn down) and must never surface as an unhandled rejection on a real
* user's page.
*/
async function sendToBackground(msg) {
	try {
		return await chrome.runtime.sendMessage(envelope(msg)) ?? null;
	} catch {
		return null;
	}
}
/** Narrowing guard for anything arriving over the message channel. */
function isBackgroundPush(msg) {
	if (typeof msg !== "object" || msg === null) return false;
	const m = msg;
	return m["v"] === 3 && typeof m["type"] === "string" && m["type"].startsWith("viso/");
}
function isContentRequest(msg) {
	if (typeof msg !== "object" || msg === null) return false;
	const m = msg;
	return m["v"] === 3 && typeof m["type"] === "string" && m["type"].startsWith("viso/");
}
//#endregion
//#region src/shared/hash.ts
/**
* FNV-1a, 32-bit, hex-encoded.
*
* Used for context de-duplication signatures — not for security. Chosen over
* crypto.subtle because it is synchronous: the observer's hot path must not
* await, and an async hash would reorder events under rapid SPA navigation.
*/
function fnv1a(input) {
	let hash = 2166136261;
	for (let i = 0; i < input.length; i++) {
		hash ^= input.charCodeAt(i);
		hash = Math.imul(hash, 16777619) >>> 0;
	}
	return hash.toString(16).padStart(8, "0");
}
//#endregion
//#region src/content/extract/adapters/urlAdapter.ts
/** Matches `example.com` and `sub.example.com`, never `notexample.com`. */
function hostMatches(hostname, hosts) {
	const host = hostname.toLowerCase().replace(/^www\./, "");
	return hosts.some((h) => host === h || host.endsWith(`.${h}`));
}
/** First non-empty path segment after an optional prefix. */
function segments(url) {
	return url.pathname.split("/").filter((s) => s !== "");
}
/** Segment following a marker, e.g. after "browse" or "channels". */
function after(url, marker) {
	const parts = segments(url);
	const at = parts.indexOf(marker);
	return at === -1 ? null : parts[at + 1] ?? null;
}
/**
* The platform table.
*
* Order matters only where hosts overlap; they do not here. Each entry is one
* fact — "this host, this part of the URL is the thing" — so adding a platform
* is a row, and getting one wrong cannot affect another.
*/
var URL_PLATFORMS = [
	{
		type: "jira",
		label: "Jira",
		hosts: ["atlassian.net"],
		pathGuard: (url) => !url.pathname.startsWith("/wiki"),
		entityId: (url) => after(url, "browse") ?? url.searchParams.get("selectedIssue"),
		describe: (id) => `Jira ${id}`,
		entities: (id) => [{
			type: "issue_key",
			value: id
		}]
	},
	{
		type: "confluence",
		label: "Confluence",
		hosts: ["atlassian.net"],
		pathGuard: (url) => url.pathname.startsWith("/wiki"),
		entityId: (url) => segments(url)[0] === "wiki" ? after(url, "pages") : null,
		describe: (id) => `Confluence ${id}`
	},
	{
		type: "slack",
		label: "Slack",
		hosts: ["slack.com"],
		entityId: (url) => {
			const channel = after(url, "archives");
			if (channel === null) return null;
			const parts = segments(url);
			const message = parts[parts.indexOf("archives") + 2];
			return message === void 0 ? channel : `${channel}/${message}`;
		},
		describe: (id) => `Slack ${id.split("/")[0] ?? id}`,
		entities: (id) => {
			const channel = id.split("/")[0];
			return channel === void 0 ? [] : [{
				type: "channel",
				value: channel
			}];
		}
	},
	{
		type: "discord",
		label: "Discord",
		hosts: ["discord.com"],
		entityId: (url) => {
			const parts = segments(url);
			if (parts[0] !== "channels") return null;
			const rest = parts.slice(1).filter((p) => p !== "");
			return rest.length >= 2 ? rest.join("/") : null;
		},
		describe: (id) => `Discord ${id.split("/")[1] ?? id}`
	},
	{
		type: "zalo",
		label: "Zalo",
		hosts: ["zalo.me"],
		entityId: () => null
	},
	{
		type: "messenger",
		label: "Messenger",
		hosts: ["messenger.com"],
		entityId: (url) => after(url, "t"),
		describe: (id) => `Messenger ${id}`
	},
	{
		type: "gdocs",
		label: "Google Docs",
		hosts: ["docs.google.com"],
		entityId: (url) => after(url, "d"),
		describe: (_id, url) => {
			const kind = segments(url)[0] ?? "document";
			return kind === "spreadsheets" ? "Google Sheets" : kind === "presentation" ? "Google Slides" : "Google Docs";
		}
	},
	{
		type: "gcalendar",
		label: "Google Calendar",
		hosts: ["calendar.google.com"],
		entityId: (url) => after(url, "eventedit") ?? url.searchParams.get("eid"),
		describe: () => "Google Calendar"
	},
	{
		type: "gdrive",
		label: "Google Drive",
		hosts: ["drive.google.com"],
		entityId: (url) => after(url, "folders") ?? after(url, "d"),
		describe: () => "Google Drive"
	},
	{
		type: "outlook",
		label: "Outlook",
		hosts: [
			"outlook.office.com",
			"outlook.office365.com",
			"outlook.live.com"
		],
		entityId: (url) => after(url, "id"),
		describe: () => "Outlook"
	},
	{
		type: "teams",
		label: "Microsoft Teams",
		hosts: ["teams.microsoft.com", "teams.live.com"],
		entityId: (url) => {
			const parts = url.hash.replace(/^#\/?/, "").split("/").filter((p) => p !== "");
			return parts[0] === "conversations" ? parts[1] ?? null : null;
		},
		describe: () => "Teams"
	},
	{
		type: "sharepoint",
		label: "SharePoint / OneDrive",
		hosts: ["sharepoint.com"],
		entityId: (url) => url.searchParams.get("id") ?? url.searchParams.get("sourcedoc"),
		describe: () => "SharePoint"
	},
	{
		type: "notion",
		label: "Notion",
		hosts: ["notion.so", "notion.site"],
		entityId: (url) => {
			const last = segments(url).at(-1) ?? "";
			return /([0-9a-f]{32})$/i.exec(last.replace(/-/g, ""))?.[1] ?? null;
		},
		describe: () => "Notion"
	},
	{
		type: "linear",
		label: "Linear",
		hosts: ["linear.app"],
		entityId: (url) => after(url, "issue"),
		describe: (id) => `Linear ${id}`,
		entities: (id) => [{
			type: "issue_key",
			value: id
		}]
	},
	{
		type: "github",
		label: "GitHub",
		hosts: ["github.com"],
		entityId: (url) => {
			const parts = segments(url);
			const kind = parts[2];
			if (kind !== "issues" && kind !== "pull") return null;
			const number = parts[3];
			return number === void 0 ? null : `${parts[0]}/${parts[1]}#${number}`;
		},
		describe: (id) => `GitHub ${id}`,
		entities: (id) => [{
			type: "issue_key",
			value: id
		}]
	},
	{
		type: "figma",
		label: "Figma",
		hosts: ["figma.com"],
		entityId: (url) => after(url, "file") ?? after(url, "design") ?? after(url, "board"),
		describe: () => "Figma"
	},
	{
		type: "trello",
		label: "Trello",
		hosts: ["trello.com"],
		entityId: (url) => after(url, "c"),
		describe: (id) => `Trello ${id}`
	},
	{
		type: "asana",
		label: "Asana",
		hosts: ["asana.com"],
		entityId: (url) => {
			const parts = segments(url);
			return parts.length >= 3 && parts[0] === "0" ? parts[2] ?? null : null;
		},
		describe: (id) => `Asana ${id}`
	},
	{
		type: "youtube",
		label: "YouTube",
		hosts: ["youtube.com", "youtu.be"],
		entityId: (url) => url.searchParams.get("v") ?? (url.hostname.endsWith("youtu.be") ? segments(url)[0] ?? null : null),
		describe: (id) => `YouTube ${id}`
	}
];
/** Builds an adapter from one row of the table. */
function urlAdapter(platform) {
	const id = `${platform.type}-url@1`;
	return {
		id,
		matches(url) {
			try {
				const parsed = new URL(url);
				if (!hostMatches(parsed.hostname, platform.hosts)) return false;
				return platform.pathGuard?.(parsed) ?? true;
			} catch {
				return false;
			}
		},
		buildDeepLink(entityId) {
			return entityId;
		},
		extractContext(doc, url, now) {
			let parsed;
			try {
				parsed = new URL(url);
			} catch {
				return {
					ok: false,
					reason: "no_content"
				};
			}
			let entityId;
			try {
				entityId = platform.entityId(parsed);
			} catch {
				entityId = null;
			}
			const host = parsed.hostname.replace(/^www\./, "");
			const title = doc.title.trim();
			const entities = [{
				type: "domain",
				value: host
			}];
			if (entityId !== null) entities.push(...platform.entities?.(entityId, parsed) ?? []);
			const isList = entityId === null;
			const label = entityId === null ? platform.label : platform.describe?.(entityId, parsed) ?? platform.label;
			return {
				ok: true,
				context: {
					title: title !== "" ? title : label,
					body: "",
					entities: entities.map((e) => e.value),
					entity_refs: entities,
					source_url: url,
					deep_link: url,
					platform_type: platform.type,
					timestamp: now,
					confidence: isList ? .2 : .55,
					context_hash: fnv1a(entityId === null ? `${platform.type}:list:${host}` : `${platform.type}:${entityId}`),
					extractor: isList ? `${platform.type}-list@1` : id
				}
			};
		}
	};
}
/** Every table-driven adapter, in registration order. */
function urlAdapters() {
	return URL_PLATFORMS.map(urlAdapter);
}
//#endregion
//#region src/shared/sourceLabel.ts
/**
* What a note's source is called, anywhere ViSO shows one.
*
* Shared by the in-page HUD and by the snapshot sent to the desktop app, so the
* same note says "Gmail" in both places. It lives here rather than in the
* content script because the service worker builds that snapshot, and the
* service worker must not pull in page code.
*/
/** Hostname without `www.`, the fallback when a platform has no name of its own. */
function hostLabel(pageUrl) {
	if (pageUrl === null || pageUrl === "") return null;
	try {
		const host = new URL(pageUrl).hostname.replace(/^www\./, "");
		return host === "" ? null : host;
	} catch {
		return null;
	}
}
var NAMES = new Map([["gmail", "Gmail"], ...URL_PLATFORMS.map((platform) => [platform.type, platform.label])]);
/**
* The product's name where ViSO knows it — "Gmail", "Jira", "Google Docs" —
* because that is how people think of where they were. The hostname otherwise.
*/
function sourceLabel(platformType, sourceUrl) {
	if (platformType !== null && platformType !== "generic") {
		const name = NAMES.get(platformType);
		if (name !== void 0) return name;
	}
	return hostLabel(sourceUrl);
}
//#endregion
//#region src/voice/repeat.ts
/**
* Repeating reminders.
*
* `parseWhen` has always detected that an utterance asked for a repeat and has
* always reported it as a bare boolean, with a note in its own source saying
* why that is not enough: "setting one occurrence of a daily reminder is a
* promise not kept, and it looks identical to success." This is the other half
* — which repeat was asked for, and when the next one falls.
*
* Rules rather than pre-generated rows. A daily reminder is not 365 reminders;
* editing the note has to change every future occurrence, and a user who
* deletes one should not find 364 siblings behind it.
*/
var PATTERNS = [
	{
		rule: "yearly",
		words: [
			"mỗi năm",
			"hàng năm",
			"hằng năm",
			"every year",
			"yearly",
			"annually"
		]
	},
	{
		rule: "monthly",
		words: [
			"mỗi tháng",
			"hàng tháng",
			"hằng tháng",
			"every month",
			"monthly"
		]
	},
	{
		rule: "weekly",
		words: [
			"mỗi tuần",
			"hàng tuần",
			"hằng tuần",
			"mỗi thứ",
			"thứ nào cũng",
			"every week",
			"weekly",
			"every monday",
			"every tuesday",
			"every wednesday",
			"every thursday",
			"every friday",
			"every saturday",
			"every sunday"
		]
	},
	{
		rule: "daily",
		words: [
			"mỗi ngày",
			"hàng ngày",
			"hằng ngày",
			"mỗi sáng",
			"mỗi trưa",
			"mỗi chiều",
			"mỗi tối",
			"mỗi đêm",
			"ngày nào cũng",
			"every day",
			"everyday",
			"daily",
			"each day"
		]
	}
];
/** The repeat an utterance asked for, or null when it asked for none. */
function repeatRule(text) {
	const haystack = text.toLowerCase();
	for (const entry of PATTERNS) if (entry.words.some((word) => haystack.includes(word))) return entry.rule;
	return null;
}
/**
* The first occurrence strictly after `now`, starting from `from`.
*
* Loops rather than adding one interval, and that is the whole point. Chrome
* has to be running for an alarm to fire, so a daily reminder whose owner was
* away for a week comes due with six missed occurrences behind it. Advancing
* once would leave it still in the past and fire again on the next tick, six
* notifications in a row for the same thing. This fires once — the caller has
* already done that — and moves to the next one that is genuinely ahead.
*
* `monthly` clamps: a reminder set for the 31st lands on the 28th in February
* rather than skipping the month or silently sliding into March.
*/
function nextOccurrence(from, rule, now) {
	let at = from;
	for (let guard = 0; guard < 4e3 && at <= now; guard++) at = advance(at, rule);
	return at;
}
function advance(at, rule) {
	const date = new Date(at);
	switch (rule) {
		case "daily":
			date.setDate(date.getDate() + 1);
			return date.getTime();
		case "weekly":
			date.setDate(date.getDate() + 7);
			return date.getTime();
		case "monthly": return sameDayNext(date, 1);
		case "yearly": return sameDayNext(date, 12);
	}
}
/**
* `months` ahead, keeping the day of the month where the target month has one.
*
* `setMonth` alone overflows — 31 January plus one month is 3 March — which
* moves a monthly reminder onto a different day and keeps moving it.
*/
function sameDayNext(date, months) {
	const day = date.getDate();
	const target = new Date(date);
	target.setDate(1);
	target.setMonth(target.getMonth() + months);
	const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
	target.setDate(Math.min(day, lastDay));
	return target.getTime();
}
/** How to say a rule back, for the panel and the notification. */
var REPEAT_LABELS = {
	daily: "mỗi ngày",
	weekly: "mỗi tuần",
	monthly: "mỗi tháng",
	yearly: "mỗi năm"
};
//#endregion
//#region src/voice/intent.ts
/**
* Phrasings that anchor a reminder to a place instead of a time.
*
* Matched loosely on purpose: the words around the intent vary far more than
* the intent does, and a false positive is cheap — the reminder still fires,
* on arrival rather than on the clock.
*/
var CONTEXT_CUES = [
	"lần sau",
	"lần tới",
	"khi nào mở",
	"khi mở",
	"lúc nào mở",
	"khi vào",
	"lúc vào",
	"khi quay lại",
	"quay lại",
	"next time",
	"when i open"
];
/**
* Leading cues. Order matters within a list — longer phrases first, so
* "nhắc tôi" wins over "nhắc" and the remaining text is clean.
*/
var CUES = [
	{
		intent: "REMINDER",
		phrases: [
			"nhắc nhở tôi",
			"nhắc nhở mình",
			"nhắc nhở em",
			"nhắc nhở anh",
			"nhắc nhở chị",
			"nhắc tôi",
			"nhắc mình",
			"nhắc em",
			"nhắc anh",
			"nhắc chị",
			"remind me",
			"nhắc nhở",
			"nhắc",
			"remind"
		]
	},
	{
		intent: "TASK",
		phrases: [
			"việc cần làm",
			"thêm task",
			"tạo task",
			"add task",
			"new task",
			"to-do",
			"todo",
			"cần làm",
			"phải làm",
			"việc cần",
			"giao việc",
			"task"
		]
	},
	{
		intent: "REMEMBER",
		phrases: [
			"ghi nhớ",
			"ghi lại",
			"ghi chú",
			"nhớ giúp",
			"nhớ là",
			"nhớ",
			"lưu lại",
			"lưu",
			"note lại",
			"note",
			"remember",
			"save"
		]
	},
	{
		intent: "QUERY",
		phrases: [
			"tìm lại",
			"tìm giúp",
			"tìm",
			"cho tôi xem",
			"xem lại",
			"có gì về",
			"hôm trước",
			"search",
			"find",
			"what did",
			"when did"
		]
	}
];
/** Time expressions. Their presence pushes an ambiguous utterance to REMINDER. */
var TIME_MARKERS = [
	"ngày mai",
	"hôm nay",
	"tối nay",
	"sáng mai",
	"chiều nay",
	"tuần sau",
	"tuần tới",
	"tháng sau",
	"lúc",
	"vào lúc",
	"trước ngày",
	"thứ hai",
	"thứ ba",
	"thứ tư",
	"thứ năm",
	"thứ sáu",
	"thứ bảy",
	"chủ nhật",
	"tomorrow",
	"tonight",
	"next week",
	"at "
];
/**
* Word boundaries that survive diacritics.
*
* `\b` is defined over ASCII word characters, so `\bgì\b` never matches: the
* final "ì" is not an ASCII word character, and the boundary it needs is
* therefore not there. Every pattern below that ends in a Vietnamese word
* silently failed until this replaced it.
*/
var L = String.raw`(?<![\p{L}\p{M}])`;
var R = String.raw`(?![\p{L}\p{M}])`;
/**
* Question shapes that a leading-cue list cannot see.
*
* "Tôi ghi gì về pricing" opens with a pronoun and carries its verb in the
* middle, so the phrase table below never matched it — and because `ghi` is
* also how a note begins, the utterance was classified REMEMBER and *saved*.
* Asking ViSO what it remembered created a new memory containing the question.
*
* These may override a REMEMBER verdict and nothing else: "nhắc tôi hỏi chị
* Hương xem có gì mới" is an instruction that happens to contain a question.
*/
var QUERY_PATTERNS = [
	new RegExp(`${L}(?:ghi|lưu|note|ghi chú|nhớ|saved?)\\s+(?:cái\\s+|những\\s+)?(?:gì|nào)${R}`, "iu"),
	new RegExp(`${L}có\\s+(?:note|ghi chú|gì)\\s+(?:nào\\s+)?(?:về|liên quan|ở|trên)${R}`, "iu"),
	new RegExp(`${L}what\\s+(?:did|do|have)\\s+i${R}`, "iu")
];
/**
* Shapes that are a listing request whatever verb they carry.
*
* Separated from the patterns above because these may override REMINDER and
* TASK too. "Liệt kê lời nhắc tuần này" leads with the word `nhắc` and was
* being classified as a request to CREATE a reminder — the one misreading that
* turns a question into a scheduled interruption.
*/
var LISTING_PATTERNS = [
	new RegExp(`${L}(?:liệt kê|list)${R}`, "iu"),
	new RegExp(`${L}(?:note|ghi chú|lời nhắc|nhắc nhở|task|việc)\\s+nào${R}`, "iu"),
	new RegExp(`${L}(?:xem|coi)\\s+(?:lại\\s+)?(?:hết|tất cả|toàn bộ|danh sách)${R}`, "iu")
];
var MIN_MEANINGFUL_WORDS = 2;
function classifyIntent(transcript) {
	const raw = transcript.trim();
	const normalized = normalize(raw);
	if (raw === "" || countWords(raw) < MIN_MEANINGFUL_WORDS) return {
		intent: "IGNORE",
		confidence: 1,
		entities: [],
		text: raw,
		needsFallback: false
	};
	const match = findLeadingCue(normalized);
	const entities = extractEntities(raw);
	if (LISTING_PATTERNS.some((pattern) => pattern.test(raw))) return {
		intent: "QUERY",
		confidence: .85,
		entities,
		text: raw,
		needsFallback: false
	};
	if (match !== null) {
		const remainder = stripCue(raw, match.index, match.length);
		if (countWords(remainder) < MIN_MEANINGFUL_WORDS) return {
			intent: match.intent,
			confidence: .45,
			entities,
			text: remainder,
			needsFallback: false
		};
		if (match.intent === "REMEMBER" && QUERY_PATTERNS.some((pattern) => pattern.test(raw))) return {
			intent: "QUERY",
			confidence: .85,
			entities,
			text: remainder,
			needsFallback: false
		};
		let confidence = match.leading ? .9 : .7;
		let intent = match.intent;
		if (intent === "REMEMBER" && isFutureTime(remainder)) {
			intent = "REMINDER";
			confidence = .7;
		}
		const repeat = repeatRule(raw);
		return {
			intent,
			confidence,
			entities,
			...withTime(intent, remainder),
			...repeat === null ? {} : { repeat },
			needsFallback: false
		};
	}
	if (QUERY_PATTERNS.some((pattern) => pattern.test(raw))) return {
		intent: "QUERY",
		confidence: .75,
		entities,
		text: raw,
		needsFallback: false
	};
	if (isFutureTime(raw)) {
		const repeat = repeatRule(raw);
		return {
			intent: "REMINDER",
			confidence: .5,
			entities,
			...withTime("REMINDER", raw),
			...repeat === null ? {} : { repeat },
			needsFallback: true
		};
	}
	return {
		intent: "REMEMBER",
		confidence: .3,
		entities,
		text: raw,
		needsFallback: true
	};
}
/**
* Splits a time expression off the text, for the intents that can act on one.
*
* REMEMBER is left alone deliberately: "nhớ họp lúc 3 giờ hôm qua" is a note
* about a past meeting, and stripping "lúc 3 giờ hôm qua" out of it would
* destroy the note to populate a field nothing reads.
*/
function withTime(intent, text) {
	if (intent !== "REMINDER" && intent !== "TASK") return { text };
	const normalized = normalize(text);
	if (CONTEXT_CUES.some((cue) => normalized.includes(cue))) return {
		text: stripContextCue(text),
		onContext: true
	};
	const when = parseWhen(text);
	if (when.date === void 0 && when.time === void 0) return { text };
	const rest = tidyRemainder(when.rest);
	if (rest === "") return {
		text,
		when
	};
	return {
		text: rest,
		when
	};
}
/**
* Removes the preposition a time phrase leaves behind.
*
* parseWhen cuts the span it recognised, which is the time itself — so "nhắc
* tôi nghỉ sau 30 phút nữa" came back as "nghỉ sau" and "review lúc 2 tiếng
* nữa" as "review lúc". The dangling word is not part of what to do.
*/
/** Removes the "lần sau mở trang này" wrapper, leaving what to be reminded of. */
function stripContextCue(text) {
	const cue = new RegExp(`^\\s*(?:${CONTEXT_CUES.map(escape).join("|")})\\s*(?:mở|vao|vào|quay\\s*lại|open|visit)?\\s*(?:trang\\s*này|cái\\s*này|đây|this\\s*page|here)?\\s*(?:thì|is|then)?\\s*(?:nhắc\\s*(?:nhở\\s*)?(?:tôi|mình|em)?)?\\s*`, "iu");
	const withoutLeading = text.replace(cue, "");
	const trailing = new RegExp(`\\s*(?:${CONTEXT_CUES.map(escape).join("|")})\\s*(?:mở|vào|quay\\s*lại)?\\s*(?:trang\\s*này|cái\\s*này|đây)?\\s*$`, "iu");
	const cleaned = withoutLeading.replace(trailing, "").trim();
	return cleaned === "" ? text.trim() : cleaned;
}
function escape(literal) {
	return literal.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
}
function tidyRemainder(text) {
	return text.replace(/[\s,]+(sau|lúc|luc|vào|vao|trước|truoc|từ|tu|đến|den|khoảng|khoang|tầm|tam|at|on|in|by)$/iu, "").replace(/[\s,.:;-]+$/u, "").trim();
}
function findLeadingCue(normalized) {
	let best = null;
	for (const { intent, phrases } of CUES) for (const phrase of phrases) {
		const index = indexOfWord(normalized, phrase);
		if (index === -1) continue;
		const candidate = {
			intent,
			index,
			length: phrase.length,
			leading: index === 0
		};
		if (best === null || candidate.leading && !best.leading) best = candidate;
		if (candidate.leading) return candidate;
	}
	return best;
}
/** Word-boundary search, so "task" does not match inside "multitasking". */
function indexOfWord(haystack, needle) {
	let from = 0;
	for (;;) {
		const index = haystack.indexOf(needle, from);
		if (index === -1) return -1;
		const before = index === 0 ? " " : haystack[index - 1];
		const afterIndex = index + needle.length;
		const after = afterIndex >= haystack.length ? " " : haystack[afterIndex];
		if (!isWordChar(before) && !isWordChar(after)) return index;
		from = index + 1;
	}
}
function isWordChar(char) {
	return char !== void 0 && /[\p{L}\p{N}]/u.test(char);
}
/**
* Removes the cue from where it is, not from the front.
*
* This used to slice `cueLength` characters off the start regardless of where
* the cue matched, which is right only for a leading one. "lần sau mở trang
* này thì nhắc tôi hỏi John" matched "nhắc tôi" mid-sentence and had its first
* eight characters removed instead — "lần sau " — leaving text that still
* contained the cue and had lost the words that mattered.
*/
function stripCue(raw, index, length) {
	return `${raw.slice(0, index)} ${raw.slice(index + length)}`.replace(/\s+/gu, " ").replace(/^[\s,:.-]+/u, "").trim();
}
/**
* Does this name a moment that has not happened yet?
*
* A time word is not enough. "hôm qua" is unmistakably a time and unmistakably
* not something to be reminded about; the parser resolves it to a date, and the
* date is what answers the question.
*
* The keyword list still runs first as a cheap gate — parseWhen does real work,
* and most utterances mention no time at all.
*/
function isFutureTime(text, now = /* @__PURE__ */ new Date()) {
	if (!TIME_MARKERS.some((marker) => normalize(text).includes(marker))) return false;
	const when = parseWhen(text, now);
	if (when.date === void 0 && when.time === void 0) return false;
	if (when.date === void 0) return true;
	return (/* @__PURE__ */ new Date(`${when.date}T${when.time ?? "23:59"}:00`)).getTime() >= now.getTime();
}
/**
* Capitalised runs are treated as people. Crude, and deliberately so: this only
* feeds §7.1's entity_boost, where a miss costs 0.1 and a wrong extraction that
* blocked saving would cost the whole utterance.
*/
function extractEntities(raw) {
	const entities = [];
	const seen = /* @__PURE__ */ new Set();
	for (const mention of extractPeople(raw)) {
		const key = mention.value.toLowerCase();
		if (seen.has(key)) continue;
		seen.add(key);
		entities.push(toEntity(mention));
	}
	for (const match of raw.matchAll(/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g)) {
		const value = match[0];
		if (seen.has(value.toLowerCase())) continue;
		seen.add(value.toLowerCase());
		entities.push({
			type: "email",
			value
		});
	}
	return entities;
}
/** Lowercase and collapse whitespace. Diacritics are KEPT — "nhắc" and "nhac" are different words. */
function normalize(text) {
	return text.toLowerCase().replace(/\s+/g, " ").trim();
}
function countWords(text) {
	return text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
}
//#endregion
//#region src/voice/typed.ts
var ADDRESS = /^\s*(?:nhắc (?:tôi|mình|tui|giúp tôi|giúp mình)(?: là| rằng)?|remind me(?: to)?|ghi chú(?: là|:)|note(?: that|:)|việc cần làm(?::)?|to-?do:?|task:?)\s+/iu;
/**
* @param chosen  A kind picked by hand (the composer's "@"), which wins over the words.
*/
function readTyped(raw, chosen = null, now = /* @__PURE__ */ new Date()) {
	const line = raw.trim();
	const read = classifyIntent(chosen === null ? line : `nhắc tôi ${line}`);
	const text = line.replace(ADDRESS, "").trim() || line;
	const when = parseWhen(text, now);
	const hasWhen = (when.dayStated === true || when.time !== void 0) && (when.date !== void 0 || when.time !== void 0);
	let intent = chosen ?? (read.intent === "IGNORE" || read.intent === "QUERY" ? "REMEMBER" : read.intent);
	if (chosen === null && intent === "REMEMBER" && hasWhen) {
		const at = whenToEpoch(when);
		if (at !== null && at >= now.getTime() - 6e4) intent = "REMINDER";
	}
	const remindAt = (intent === "REMINDER" || intent === "TASK") && hasWhen ? whenToEpoch(when) : null;
	return {
		intent,
		text,
		remindAt,
		when: remindAt === null ? {} : {
			...when.date === void 0 ? {} : { date: when.date },
			...when.time === void 0 ? {} : { time: when.time }
		}
	};
}
/** A date and a clock as a moment; a date alone means nine in the morning. */
function whenToEpoch(when) {
	if (when.date === void 0) return null;
	const [y, m, d] = when.date.split("-").map(Number);
	const [hh, mm] = (when.time ?? "09:00").split(":").map(Number);
	const at = new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1, hh ?? 9, mm ?? 0, 0, 0).getTime();
	return Number.isFinite(at) ? at : null;
}
//#endregion
//#region src/shared/noteScope.ts
/**
* Which notes belong to the page the user is on.
*
* A document is a place of its own: notes on one Google Doc have nothing to do
* with notes on the next, even though both live on docs.google.com. An app like
* Gmail is the other way round — the inbox, a thread and a search are one place
* to the person using it, and splitting notes by thread would scatter them.
*
* So platforms that open documents are scoped per file, by the context hash
* their URL adapter derives from the document's own id; everything else,
* including every site without an adapter, is scoped per site.
*/
/** Platforms whose pages are documents. The same set opens notes in a new tab. */
var PER_FILE_PLATFORMS = /* @__PURE__ */ new Set([
	"gdocs",
	"gdrive",
	"sharepoint",
	"notion",
	"figma",
	"youtube"
]);
function scopeFor(platformType, contextHash, sourceUrl) {
	if (platformType !== null && PER_FILE_PLATFORMS.has(platformType) && contextHash !== null && contextHash !== "") return {
		kind: "file",
		key: `file:${contextHash}`,
		contextHash
	};
	const host = hostLabel(sourceUrl);
	if (host === null) return null;
	return {
		kind: "site",
		key: `site:${host}`,
		host
	};
}
/**
* What the HUD header calls the scope.
*
* A file by its own title — "Báo cáo quý 3", not "Google Docs", which would
* say the same thing on every document and tell them apart on none. A site by
* its product name, or its hostname.
*/
function scopeLabel(scope, platformType, sourceUrl, title) {
	if (scope.kind === "file") return documentTitle(title) ?? sourceLabel(platformType, sourceUrl) ?? "Tài liệu này";
	return sourceLabel(platformType, sourceUrl) ?? scope.host;
}
/** Strips the product suffix apps add to document titles. */
function documentTitle(title) {
	if (title === null) return null;
	const cleaned = title.replace(/\s+[-–—|]\s+(Google (Docs|Sheets|Slides|Drive)|Google (Tài liệu|Trang tính|Trang trình bày)|Notion|Figma|YouTube|SharePoint|OneDrive)\s*$/iu, "").trim();
	return cleaned === "" ? null : cleaned;
}
//#endregion
//#region src/shared/samePage.ts
/**
* Whether two URLs are the same page.
*
* Query strings are ignored — Docs appends `?tab=`, Gmail and others append
* tracking — but the fragment is not, because a Gmail thread lives there.
*/
function samePage(a, b) {
	if (b === null) return false;
	try {
		const x = new URL(a);
		const y = new URL(b);
		const path = (u) => u.pathname.replace(/\/+$/, "");
		return x.origin === y.origin && path(x) === path(y) && x.hash === y.hash;
	} catch {
		return false;
	}
}
//#endregion
//#region src/content/extract/config.ts
/**
* Every tunable number for extraction, in one place.
*
* Provenance matters here: [spec] values come from §5.5, [confirmed] from an
* explicit decision, and [proposed] are numbers this implementation invented
* because the spec defines a gate but not the score feeding it. The [proposed]
* ones are the first thing to revisit once there is real data.
*/
var EXTRACT_CONFIG = {
	/** [spec §5.5] Below this, Readability output is treated as a failure. */
	MIN_TEXT_LENGTH: 200,
	/**
	* [confirmed] Element count above which the body is not cloned at all.
	* Cloning a Gmail or Slack DOM on every context change is the single most
	* expensive thing this extension could do on a user's machine.
	*/
	MAX_BODY_ELEMENTS: 5e3,
	/** [proposed] og:description shorter than this is too thin to trust alone. */
	MIN_STRUCTURED_DESCRIPTION: 80,
	/** [spec §5.2] `body` is a snippet, never the whole page. */
	BODY_SNIPPET_LENGTH: 1e3,
	CONFIDENCE: {
		/** [proposed] Publisher-authored og: tags — the most reliable generic source. */
		STRUCTURED: .9,
		/** [proposed] Readability succeeded and cleared the length gate. */
		READABILITY_BASE: .6,
		/** [proposed] Page has <article> or role="main". */
		SEMANTIC_BONUS: .1,
		/** [proposed] Readability found a byline or site name. */
		BYLINE_BONUS: .1,
		/** [proposed] Ceiling for the Readability path; only og: data scores higher. */
		READABILITY_MAX: .85,
		/**
		* [confirmed] Degraded success: title + URL only. Deliberately below the
		* §7.2 floor of 0.6, so the relevance gate discards it without a second
		* mechanism having to exist.
		*/
		DEGRADED: .2
	}
};
/**
* [spec §5.5] Path SEGMENTS that mark an app-like surface. Hitting one of these
* without a registered adapter means Readability would return menu noise, so
* extraction degrades instead.
*
* Matched as whole segments, never as substrings: `/dashboard-design-tips` is
* an article about dashboards, not a dashboard, and substring matching would
* silently degrade every such post.
*/
var APP_LIKE_PATH_SEGMENTS = /* @__PURE__ */ new Set([
	"inbox",
	"channel",
	"channels",
	"board",
	"boards",
	"dashboard",
	"mail",
	"messages",
	"archives"
]);
//#endregion
export { isContentRequest as _, scopeFor as a, classifyIntent as c, hostLabel as d, sourceLabel as f, isBackgroundPush as g, envelope as h, PER_FILE_PLATFORMS as i, REPEAT_LABELS as l, fnv1a as m, EXTRACT_CONFIG as n, scopeLabel as o, urlAdapters as p, samePage as r, readTyped as s, APP_LIKE_PATH_SEGMENTS as t, nextOccurrence as u, sendToBackground as v };
