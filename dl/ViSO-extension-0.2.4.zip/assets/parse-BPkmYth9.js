//#region src/voice/person.ts
/**
* Vietnamese person-name recognition.
*
* Replaces the rule this file was extracted from, which treated every
* capitalised word that was not sentence-initial as a person. On a single real
* utterance — "gửi báo giá cho chị Hương ở Viettel vào Thứ Hai" — that produced
* three people: `Hương`, `Viettel` and `Thứ Hai`. Two of them are wrong, and
* the damage is not cosmetic: §7.2's gate lets a `person` match bypass the card
* threshold, so `Thứ Hai` had standing to interrupt the user.
*
* The signal here is grammatical rather than orthographic. Vietnamese almost
* never says a name bare — it says "chị Hương", "anh Minh", "gửi cho Mai",
* "họp với John". A kinship term or a preposition that only takes a person is
* far better evidence than a capital letter, which in Vietnamese also lands on
* weekdays, months and brand names.
*
* Anything capitalised that carries no such evidence is still kept, as `other`.
* It stays searchable and still earns the weak entity boost; it just cannot
* bypass the threshold on its own.
*/
/**
* Kinship terms and honorifics that precede a name.
*
* Longest-first within the list is unnecessary here — each is matched as a
* whole word — but "thầy"/"cô" are included even though they are teacher
* address, because a saved note about a teacher is still a note about a person.
*/
var TITLES = [
	"anh",
	"chị",
	"em",
	"cô",
	"chú",
	"bác",
	"ông",
	"bà",
	"thầy",
	"cụ",
	"dì",
	"cậu",
	"mợ",
	"thím",
	"dượng",
	"bạn",
	"sếp",
	"chị em",
	"mr",
	"mrs",
	"ms",
	"miss",
	"dr",
	"prof"
];
/**
* Prepositions and verbs whose object is a person.
*
* "của" is deliberately absent. It reads as possessive for people and
* organisations alike — "báo giá của Viettel" — and the person case it would
* have caught ("số điện thoại của anh Minh") already carries a title.
*/
var PERSON_CUES = [
	"cho",
	"với",
	"cùng",
	"gặp",
	"nhờ",
	"hỏi",
	"gửi",
	"with",
	"for",
	"from"
];
/**
* Capitalised words that are never names, however they are introduced.
*
* Weekdays are the ones that actually caused trouble: Vietnamese writes them
* "thứ Hai", capitalising only the numeral, so the name-shaped token is `Hai`.
* That is why `REJECT_AFTER` exists alongside this list — the offending word is
* lowercase and sits outside the match.
*/
var NEVER_NAMES = /* @__PURE__ */ new Set([
	"thứ hai",
	"thứ ba",
	"thứ tư",
	"thứ năm",
	"thứ sáu",
	"thứ bảy",
	"chủ nhật",
	"monday",
	"tuesday",
	"wednesday",
	"thursday",
	"friday",
	"saturday",
	"sunday",
	"january",
	"february",
	"march",
	"april",
	"may",
	"june",
	"july",
	"august",
	"september",
	"october",
	"november",
	"december",
	"hôm nay",
	"hôm qua",
	"ngày mai",
	"tuần sau",
	"tuần tới"
]);
/** A capital after one of these is a date part, not a name: "thứ Hai". */
var REJECT_AFTER = /* @__PURE__ */ new Set([
	"thứ",
	"tháng",
	"ngày",
	"tuần",
	"quý",
	"giờ",
	"mùng",
	"mồng"
]);
/** One capitalised token, allowing combining marks for decomposed Vietnamese. */
var TOKEN = String.raw`\p{Lu}[\p{Ll}\p{M}]+`;
/** Up to three of them — "Nguyễn Thị Hương" is a full name, four is a sentence. */
var NAME = `${TOKEN}(?:\\s+${TOKEN}){0,2}`;
var NAME_RE = new RegExp(`(?<!\\p{L})${NAME}`, "gu");
/**
* Every name-shaped span in the text, each marked strong or weak.
*
* Order follows the text so the caller's output is stable across runs; the
* caller dedupes.
*/
function extractPeople(raw) {
	const mentions = [];
	for (const match of raw.matchAll(NAME_RE)) {
		const span = match[0];
		if (NEVER_NAMES.has(span.toLowerCase())) continue;
		const titled = splitTitle(span);
		const value = titled.name;
		if (value === "") continue;
		const index = (match.index ?? 0) + titled.offset;
		const preceding = titled.title === null ? wordBefore(raw, index) : titled.title;
		if (preceding !== null && REJECT_AFTER.has(preceding)) continue;
		if (index === 0) continue;
		const strong = preceding !== null && (TITLES.includes(preceding) || PERSON_CUES.includes(preceding));
		mentions.push({
			value,
			strong
		});
	}
	return mentions;
}
/**
* Splits a leading title off a capitalised span.
*
* Returns the span unchanged when it does not start with one, and never
* returns an empty name for a span that was only a title — the caller drops
* those, because "Chị." on its own names nobody.
*/
function splitTitle(span) {
	const parts = span.split(/\s+/);
	const head = parts[0];
	if (parts.length > 1 && head !== void 0 && TITLES.includes(head.toLowerCase())) return {
		title: head.toLowerCase(),
		name: parts.slice(1).join(" "),
		offset: head.length + 1
	};
	return {
		title: null,
		name: span,
		offset: 0
	};
}
/** The lowercase word immediately before `index`, or null at a boundary. */
function wordBefore(raw, index) {
	const head = raw.slice(0, index).trimEnd();
	if (head === "") return null;
	const match = /(\p{L}+)$/u.exec(head);
	return match?.[1] === void 0 ? null : match[1].toLowerCase();
}
/** Convenience for callers building `Entity[]`: strong become `person`. */
function toEntity(mention) {
	return {
		type: mention.strong ? "person" : "other",
		value: mention.value
	};
}
//#endregion
//#region src/voice/shared/timeParse.ts
/**
* Pulls a date and time out of spoken text — the DEADLINES half of Todo, and
* everything Reminder will need.
*
* Rule-based, like the command catalog, and for the same reason §4.1 gives:
* prove the loop before reaching for a model. Unlike the catalog this is an
* *open* problem — people say time in unbounded ways — so the honest posture is
* to recognise the common forms confidently and return null for the rest rather
* than guess. A task with no deadline is a valid task.
*
* No Electron import, and `now` is a parameter rather than `Date.now()`, so
* every relative expression ("mai", "tomorrow") is testable without freezing
* the clock.
*
* ## What it deliberately does not do
*
* Durations ("trong 2 tiếng nữa", "in two hours") and ranges are out. Both are
* common enough to want and neither has an unambiguous single answer — "nhắc
* tôi 2 tiếng nữa" from a task list read three days later means something
* different than it did when spoken. That needs a decision about what the
* anchor is, which belongs with the Reminder handler, not here.
*/
/** Local calendar date as YYYY-MM-DD. Never UTC: a deadline is local by nature. */
function isoDate(d) {
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function addDays(from, days) {
	const d = new Date(from);
	d.setDate(d.getDate() + days);
	return d;
}
/**
* Weekday words. Vietnamese counts from thứ hai = Monday, so the numbers are
* offset from `getDay()` rather than equal to it.
*/
var WEEKDAYS = [
	{
		words: [
			"chủ nhật",
			"chu nhat",
			"sunday"
		],
		day: 0
	},
	{
		words: [
			"thứ hai",
			"thứ 2",
			"thu hai",
			"monday"
		],
		day: 1
	},
	{
		words: [
			"thứ ba",
			"thứ 3",
			"thu ba",
			"tuesday"
		],
		day: 2
	},
	{
		words: [
			"thứ tư",
			"thứ 4",
			"thu tu",
			"wednesday"
		],
		day: 3
	},
	{
		words: [
			"thứ năm",
			"thứ 5",
			"thu nam",
			"thursday"
		],
		day: 4
	},
	{
		words: [
			"thứ sáu",
			"thứ 6",
			"thu sau",
			"friday"
		],
		day: 5
	},
	{
		words: [
			"thứ bảy",
			"thứ 7",
			"thu bay",
			"saturday"
		],
		day: 6
	}
];
/**
* The three-letter English abbreviations are deliberately absent above.
*
* `thu`, `sat`, `sun`, `mon` are substrings of ordinary Vietnamese words, and
* a plain `indexOf` found them there: "uống thuốc 9 giờ sáng" came back as
* "uống ốc" scheduled for next Thursday, because `thu` matched inside `thuốc`
* and the span was cut out of the middle of the word. Nobody says "thu" to a
* voice assistant meaning Thursday, so the fix is to drop them as well as to
* require boundaries below — one guard would have been enough, but neither was
* there.
*/
/**
* Finds `word` as a whole word, or -1.
*
* `\b` is not usable: it is defined on ASCII word characters, so it fires in
* the middle of every accented Vietnamese word. Unicode letter/number
* lookarounds are the equivalent that actually holds here.
*/
function findWord$1(haystack, word) {
	const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	const match = new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, "iu").exec(haystack);
	return match ? match.index : -1;
}
/**
* Meridiem words, and the hour window each implies.
*
* Vietnamese splits the day more finely than am/pm: sáng, trưa, chiều, tối,
* đêm. `add12` says whether an hour spoken with this word moves to the
* afternoon — "3 giờ chiều" is 15:00, "3 giờ sáng" stays 03:00.
*/
/**
* Second syllables that make a part-of-day word the head of an ordinary word.
*
* tối ưu, sáng tạo, sáng kiến, chiều lòng. Vietnamese has no spaces inside
* words, so a list of what may follow is the only thing separating "sáng mai"
* from "sáng tạo" — the same construction, and the same fix, as "thành công"
* in the edit splitter.
*
* Shared by both passes that look at these words. The part-of-day pass needed
* it first; the clock pass turned out to need it too, because a meridiem is
* read the same way: "lúc 5 giờ tối ưu lại quy trình" took "tối" as five in
* the evening and left a task called "ưu lại quy trình".
*/
var COMPOUND_TAILS = [
	"ưu",
	"thiểu",
	"đa",
	"tăm",
	"mật",
	"kỵ",
	"hù",
	"tạo",
	"kiến",
	"suốt",
	"sủa",
	"chói",
	"láng",
	"ngời",
	"tỏ",
	"lập",
	"lòng",
	"chuộng",
	"cao",
	"dài",
	"rộng",
	"hướng",
	"chỉ",
	"khuya",
	"hôm",
	"trường",
	"nắng"
];
/** True when `word` at `at` is followed by a syllable that makes it a compound. */
function headsACompound(text, at, word) {
	const after = text.slice(at + word.length).trimStart().split(/[\s,.!?]+/u)[0] ?? "";
	return COMPOUND_TAILS.includes(after.toLowerCase());
}
/** `notBefore`: do not add twelve at or past this hour. Midday only. */
var MERIDIEMS = [
	{
		words: [
			"sáng",
			"sang",
			"am",
			"a.m."
		],
		add12: false
	},
	(
	/**
	* Midday reaches backwards to eleven, so eleven stays eleven.
	*
	* "mười một giờ trưa" was booked at 23:00 — eleven at night, for a sentence
	* about lunch. Every other meridiem here names a half of the clock; this one
	* names an hour or two around noon, and eleven is inside it. One and two are
	* the ones that need moving; eleven and twelve already say what they mean.
	*/
	{
		words: ["trưa", "trua"],
		add12: true,
		notBefore: 11
	}),
	{
		words: [
			"chiều",
			"chieu",
			"pm",
			"p.m."
		],
		add12: true
	},
	(
	/**
	* Twelve at night is midnight, not midday.
	*
	* The plus-twelve rule is right for every other hour these words take — "8
	* giờ tối" is 20:00 — and exactly wrong at twelve, where it left the hour
	* alone and produced noon. "12 giờ đêm" is the middle of the night, and a
	* reminder set for it twelve hours early is one that fires in front of
	* whoever is in the room.
	*
	* "trưa" is the one that keeps twelve, because that is what it means.
	*/
	{
		words: ["tối", "toi"],
		add12: true,
		midnightAtTwelve: true
	}),
	{
		words: [
			"đêm",
			"dem",
			"night"
		],
		add12: true,
		midnightAtTwelve: true
	}
];
/**
* Hour words, because people say the number rather than write it.
*
* "nhắc tôi lúc ba giờ chiều" is what a Vietnamese speaker says and what
* PhoWhisper writes; the digit form is the exception. Without this the command
* was recognised, the clock was not, and the reminder was refused for having no
* time — for a sentence that named its time out loud.
*
* `tư` is listed for 4 alongside `bốn`: "bốn giờ" and "tư giờ" are both said.
*/
var NUMBER_WORDS = {
	một: 1,
	mot: 1,
	hai: 2,
	ba: 3,
	bốn: 4,
	bon: 4,
	tư: 4,
	tu: 4,
	năm: 5,
	nam: 5,
	sáu: 6,
	sau: 6,
	bảy: 7,
	bay: 7,
	tám: 8,
	tam: 8,
	chín: 9,
	chin: 9,
	mười: 10,
	muoi: 10,
	"mười một": 11,
	"muoi mot": 11,
	"mười hai": 12,
	"muoi hai": 12,
	one: 1,
	two: 2,
	three: 3,
	four: 4,
	five: 5,
	six: 6,
	seven: 7,
	eight: 8,
	nine: 9,
	ten: 10,
	eleven: 11,
	twelve: 12
};
/**
* Compound spelled numbers, which the single-word table cannot reach.
*
* "nhắc tôi mười giờ hai mươi phút đi họp" booked ten o'clock exactly and left
* "hai mươi phút" in the title — the minutes were said, understood by nobody,
* and silently dropped. `NUMBER_WORDS` maps one word to one value, and twenty
* is two of them.
*
* Vietnamese builds these regularly: `mười` is ten, `<n> mươi` is n tens, and
* the ones digit follows with three irregular forms — `mốt` for one, `tư` for
* four, `lăm` for five, which only appear in that position.
*
* The guard is the one the single-word converter uses and for the same reason:
* a time unit has to follow. "hai mươi" on its own is an ordinary number in an
* ordinary sentence, and this runs over every utterance.
*/
function digitiseTens(text) {
	const ONES = {
		mốt: 1,
		một: 1,
		mot: 1,
		hai: 2,
		ba: 3,
		tư: 4,
		bốn: 4,
		bon: 4,
		lăm: 5,
		nhăm: 5,
		năm: 5,
		nam: 5,
		sáu: 6,
		sau: 6,
		bảy: 7,
		bay: 7,
		tám: 8,
		tam: 8,
		chín: 9,
		chin: 9
	};
	const TENS = {
		hai: 2,
		ba: 3,
		bốn: 4,
		bon: 4,
		tư: 4,
		năm: 5,
		nam: 5,
		sáu: 6,
		sau: 6,
		bảy: 7,
		bay: 7,
		tám: 8,
		tam: 8,
		chín: 9,
		chin: 9
	};
	const ones = Object.keys(ONES).join("|");
	const tens = Object.keys(TENS).join("|");
	const unit = "(?=\\s*(?:phút|phut|giờ|gio|tiếng|minutes?|hours?)(?![\\p{L}\\p{N}]))";
	const tensOf = (word) => TENS[word.toLowerCase()] ?? 0;
	const onesOf = (word) => ONES[word.toLowerCase()] ?? 0;
	let out = text;
	out = out.replace(new RegExp(`(?<![\\p{L}\\p{N}])(${tens})\\s+mươi(?:\\s+(${ones}))?${unit}`, "giu"), (_m, t, o) => String(tensOf(t) * 10 + (o === void 0 ? 0 : onesOf(o))));
	/**
	* Minutes said straight after the hour, with no "phút" behind them.
	*
	* "chín giờ bốn mươi lăm tối nay" booked nine o'clock and left "bốn mươi
	* lăm" in the title. The unit guard cannot see this one — what follows the
	* number is "tối", not "phút" — so the evidence has to come from the other
	* side: a compound sitting immediately after an hour is its minutes.
	*/
	out = out.replace(new RegExp(`((?:giờ|gio|h|:)\\s*)(${tens})\\s+mươi(?:\\s+(${ones}))?(?![\\p{L}\\p{N}])`, "giu"), (_m, head, t, o) => `${head}${tensOf(t) * 10 + (o === void 0 ? 0 : onesOf(o))}`);
	out = out.replace(new RegExp(`(?<![\\p{L}\\p{N}])mười(?:\\s+(${ones}))?${unit}`, "giu"), (_m, o) => String(10 + (o === void 0 ? 0 : onesOf(o))));
	return out;
}
/**
* Rewrites a spelled hour as a digit, but only directly before a time unit.
*
* The guard is not fussiness. `ba` is also "dad" — "nhắc tôi gọi cho ba" is an
* ordinary sentence, and a blind substitution turns it into "gọi cho 3". `năm`
* is "year", `tư` is "fourth". Every one of these words has a common non-numeric
* meaning, so the only safe signal is the unit that follows it.
*/
function digitiseHours(text) {
	const words = Object.keys(NUMBER_WORDS).sort((a, b) => b.length - a.length);
	let out = text;
	for (const word of words) {
		const pattern = new RegExp(
			/**
			* `h(?![\\p{L}\\p{N}])` and not `h\\b`.
			*
			* Under /u, \\b still counts only ASCII word characters, so there is a
			* boundary between the "h" and the "ọ" of "họp" — and `h\\b` matched it.
			* "thứ sáu tuần sau họp nhóm" therefore became "thứ 6 tuần 6 họp nhóm":
			* the *conjunction* "sau" was read as the numeral six because a word
			* starting with h followed it. The title came out "tuần ọp nhóm" and the
			* date was a week wrong.
			*
			* Third time this project has paid for that escape. "thu" matched inside
			* "thuốc" and scheduled a reminder for Thursday; "cái thứ" needed the
			* same fix in the manage layer; this is the same mistake in the oldest
			* pattern of the three.
			*
			* Duration units count as well as clock ones.
			*
			* The guard is that a *unit* must follow, which is what stops "gọi cho
			* ba" becoming "gọi cho 3". "mười phút nữa" satisfies it just as "mười
			* giờ" does — and without "phút" and the rest here, a spelled relative
			* duration was left as words and never parsed at all.
			*/
			/**
			* Three tiers, because the units are not equally safe.
			*
			* A clock unit or a short duration unit identifies a number on its own:
			* "ba giờ" and "ba phút" can only be quantities. "ngày", "tuần" and
			* "tháng" cannot — "gọi cho ba ngày mai" is *call dad tomorrow*, and
			* listing them flatly turned it into "gọi cho 3". That is the exact guard
			* this function was written for, broken by widening it, and caught by the
			* property check rather than by anyone thinking of the sentence.
			*
			* So the ambiguous ones convert only with a duration marker behind them:
			* "ba ngày nữa" is three days, "ba ngày mai" is not three of anything.
			*/
			`(?<![\\p{L}\\p{N}])${word}(?=\\s*(?:giờ|gio|h(?![\\p{L}\\p{N}])|o'clock|am|pm|phút|giây|tiếng|minutes?|seconds?|hours?|(?:ngày|tuần|days?|weeks?)\\s+nữa))`,
			"giu"
		);
		out = out.replace(pattern, String(NUMBER_WORDS[word]));
	}
	return out;
}
/**
* Words that ask for something to repeat.
*
* ViSO schedules single moments. A recurring request parsed as a one-off is
* the worst answer available: "mỗi ngày 7 giờ sáng" set a single alarm for
* tomorrow morning, reported success, and left "mỗi ngày" in the title — so
* the user believed they had a daily reminder and had one day of it.
*
* Recognised so it can be *refused*, which is the difference between a
* capability that does not exist and a promise that is not kept.
*/
var REPEATS = [
	"mỗi ngày",
	"hàng ngày",
	"mỗi sáng",
	"mỗi tối",
	"mỗi tuần",
	"hàng tuần",
	"mỗi tháng",
	"hàng tháng",
	"mỗi năm",
	"hàng năm",
	"mỗi thứ",
	"hằng ngày",
	"hằng tuần",
	"every day",
	"daily",
	"every week",
	"weekly",
	"every month",
	"monthly",
	"each day"
];
/** Removes one matched span and tidies the whitespace it leaves behind. */
function cut$2(text, start, end) {
	return `${text.slice(0, start)} ${text.slice(end)}`.replace(/\s+/gu, " ").trim();
}
/**
* Reads a day, a clock time, or both.
*
* Returns `rest` always, so a caller can use it as the title whether or not
* anything was found — `date`/`time` are the parts that may be absent.
*/
/**
* Shapes people type or say that the passes below do not read on their own,
* rewritten into the shape they do read. Every rewrite here was a measured
* miss: typed reminders from testers, each one refused or booked wrong.
*/
function normaliseShapes(text) {
	let t = text;
	t = t.replace(/(?<![\p{L}\p{N}])t([2-7])(?![\p{L}\p{N}])/giu, "thứ $1");
	t = t.replace(/(?<![\p{L}\p{N}])cn(?![\p{L}\p{N}])/giu, "chủ nhật");
	t = t.replace(/(?<![\p{L}\p{N}])(?<!(?:ngày|tháng|thứ|lúc)\s)(\d{1,2})\s+(\d{1,2})(?=\s*(?:giờ|gio|h)(?![\p{L}\p{N}]))/giu, "$1");
	t = t.replace(/(?<![\p{L}\p{N}])(\d{1,2})\s*(?:giờ|gio)(\s+rưỡi)?\s+nữa(?![\p{L}\p{N}])/giu, "$1 tiếng$2 nữa");
	t = t.replace(/((?:thứ\s+\S+|thu\s+\S+|chủ\s+nhật|chu\s+nhat|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\s+)(?:sắp\s+tới|tới|toi|này|nay)(?=\s|$|[,.!?])/giu, "$1");
	t = t.replace(/(?<![\p{L}\p{N}])this\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)(?![\p{L}\p{N}])/giu, "$1");
	t = t.replace(/(?<![\p{L}\p{N}])tonight(?![\p{L}\p{N}])/giu, "tối nay");
	t = t.replace(/(?<![\p{L}\p{N}])this (evening|afternoon|morning)(?![\p{L}\p{N}])/giu, (_m, w) => ({
		evening: "tối nay",
		afternoon: "chiều nay",
		morning: "sáng nay"
	})[w.toLowerCase()] ?? _m);
	t = t.replace(/(?<![\p{L}\p{N}])(?:at\s+)?(?:noon|midday)(?![\p{L}\p{N}])/giu, "12 giờ trưa");
	t = t.replace(/(?<![\p{L}\p{N}])(?:at\s+)?midnight(?![\p{L}\p{N}])/giu, "12 giờ đêm");
	t = t.replace(/(?<![\p{L}\p{N}])half an hour(?![\p{L}\p{N}])/giu, "30 minutes");
	t = t.replace(/(?<![\p{L}\p{N}])(in|after)\s+an?\s+(hour|minute|day|week)(?![\p{L}\p{N}])/giu, "$1 1 $2");
	t = t.replace(/(?<![\p{L}\p{N}])next\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)(?![\p{L}\p{N}])/giu, "$1");
	t = t.replace(/(?<![\p{L}\p{N}])(at|lúc|luc)\s+(\d{1,2})(?![\p{L}\p{N}:]|\s*(?:giờ|gio|h|g|am|pm|a\.m|p\.m|phút|phut|tháng|thang|\/|tiếng|tieng|minutes?|mins?|hours?|days?|weeks?|ngày|ngay|tuần|tuan))/giu, "$1 $2 giờ");
	t = t.replace(/(?<![\p{L}\p{N}])(?<!(?:mỗi|hàng|hằng|every|each)\s)(sáng|sang|trưa|trua|chiều|chieu|tối|toi|đêm|dem)(\s+(?:nay|mai|mốt|mot|kia|thứ\s+\S+|thu\s+\S+|chủ\s+nhật|chu\s+nhat))?\s+(?:lúc\s+|luc\s+|at\s+)?(\d{1,2}\s*(?:giờ|gio|h|g|:)\s*\d{0,2}(?:\s*(?:phút|phut))?(?:\s*(?:rưỡi|ruoi))?)(?![\p{L}\p{N}])/giu, "$3 $1$2");
	return t;
}
function parseWhen(text, now = /* @__PURE__ */ new Date()) {
	let rest = normaliseShapes(digitiseHours(digitiseTens(text)));
	/**
	* Detected before anything is cut, because the words are what identify it
	* and the passes below would consume "ngày" or "tuần" out from under this.
	*/
	const repeats = REPEATS.some((word) => findWord$1(rest.toLowerCase(), word) >= 0);
	let date;
	/**
	* Whether the *user* named a day, as opposed to one being worked out.
	*
	* The difference matters only to callers that already have a day. "dời lời
	* nhắc sang 4 giờ chiều" names an hour and nothing else, and the day below is
	* inferred as the soonest one that makes that hour future — which is right
	* when creating a reminder and wrong when moving one: a reminder set for the
	* 25th was silently pulled back to the 24th because the inferred day was
	* written over the real one.
	*/
	let dayStated = false;
	let time;
	/** Whether the speaker said sáng/chiều/tối/am/pm — see the bare-hour rule. */
	let hasMeridiem = false;
	const lower = () => rest.toLowerCase();
	for (const { words, ms } of [
		{
			words: [
				"giây",
				"seconds",
				"second"
			],
			ms: 1e3
		},
		{
			words: [
				"phút",
				"minutes",
				"minute",
				"mins",
				"min"
			],
			ms: 6e4
		},
		(
		/**
		* "giờ" is not here, and "tiếng" is.
		*
		* They are the same unit in the abstract and nothing like it in practice:
		* "5 tiếng" can only be a span, while "5 giờ" is overwhelmingly a clock
		* time. Listing it read "sau 5 giờ chiều" as *five hours from now* — 19:30
		* for a sentence that means after five in the afternoon. The word survives
		* only in the "nửa giờ" form below, where a half of it cannot be a clock.
		*/
		{
			words: [
				"tiếng",
				"hours",
				"hour"
			],
			ms: 36e5
		}),
		{
			words: [
				"ngày",
				"days",
				"day"
			],
			ms: 864e5
		},
		{
			words: [
				"tuần",
				"weeks",
				"week"
			],
			ms: 6048e5
		}
	]) {
		const unit = words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|");
		/**
		* Both orders, and the marker is not optional.
		*
		* "5 phút nữa" and "sau 5 phút" are both said. What must never match is a
		* bare "5 giờ" — that is a clock time, and reading it as five hours from
		* now would move every "nhắc tôi 5 giờ" by half a day. So one of "nữa",
		* "sau", "in" has to be present, on one side or the other.
		*
		* "rưỡi" after the unit adds half of it: "2 tiếng rưỡi" is two and a half
		* hours, and "nửa tiếng" is the same construction with the half in front.
		*/
		/**
		* `(?<!thứ\s)` is the guard, and it was put here by a regression.
		*
		* "thứ hai tuần sau" is Monday of next week. Spelled numbers become digits
		* before this runs, so it arrived as "thứ 2 tuần sau" and the first pattern
		* read "2 tuần sau" — two weeks from now, on the wrong weekday, with the
		* current clock time attached. A number after "thứ" names a weekday and
		* never a quantity.
		*/
		const patterns = [
			new RegExp(`(?<!thứ\\s)(?<![\\p{L}\\p{N}])(\\d{1,3})\\s*(?:${unit})(\\s+rưỡi)?\\s*(?:nữa|sau|later)(?![\\p{L}\\p{N}])`, "iu"),
			new RegExp(`(?<![\\p{L}\\p{N}])(?:sau|trong|in)\\s+(\\d{1,3})\\s*(?:${unit})(\\s+rưỡi)?(?![\\p{L}\\p{N}])`, "iu"),
			new RegExp(`(?<![\\p{L}\\p{N}])(nửa)\\s*(?:${unit}${ms === 36e5 ? "|giờ|gio" : ""})\\s*(?:nữa|sau)?(?![\\p{L}\\p{N}])`, "iu")
		];
		let matched = null;
		for (const pattern of patterns) {
			matched = pattern.exec(rest);
			if (matched) break;
		}
		if (!matched) continue;
		const half = matched[2] !== void 0 || matched[1]?.toLowerCase() === "nửa";
		const count = matched[1]?.toLowerCase() === "nửa" ? 0 : Number(matched[1]);
		const at = new Date(now.getTime() + count * ms + (half ? ms / 2 : 0));
		if (at.getFullYear() === now.getFullYear() && at.getMonth() === now.getMonth() && at.getDate() === now.getDate() && at.getHours() === now.getHours() && at.getMinutes() === now.getMinutes() || at.getTime() <= now.getTime()) {
			at.setTime(now.getTime());
			at.setSeconds(0, 0);
			at.setMinutes(at.getMinutes() + 1);
		}
		date = isoDate(at);
		dayStated = true;
		time = `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}`;
		rest = cut$2(rest, matched.index, matched.index + matched[0].length);
		return {
			date,
			time,
			dayStated,
			...repeats ? { repeats } : {},
			rest: rest.replace(/^[\s:,.\-–—]+|[\s:,.\-–—]+$/gu, "").trim()
		};
	}
	for (const [index, pattern] of [
		/(?:ngày|mùng|mồng)?\s*(\d{1,2})\s*(?:tháng|thang)\s*(\d{1,2})(?:\s*(?:năm|nam)\s*(\d{4}))?/iu,
		/(?:ngày|mùng|mồng)?\s*(?<![\d/])(\d{1,2})\/(\d{1,2})(?:\/(\d{4}))?(?![\d/])/iu,
		/(?<![\d-])(\d{4})-(\d{2})-(\d{2})(?![\d-])/u
	].entries()) {
		const hit = pattern.exec(rest);
		if (!hit) continue;
		const iso = index === 2;
		const day = Number(iso ? hit[3] : hit[1]);
		const month = Number(iso ? hit[2] : hit[2]);
		const year = iso ? Number(hit[1]) : hit[3] === void 0 ? void 0 : Number(hit[3]);
		if (day < 1 || day > 31 || month < 1 || month > 12) continue;
		const at = new Date(year ?? now.getFullYear(), month - 1, day, 0, 0, 0, 0);
		if (at.getMonth() !== month - 1 || at.getDate() !== day) continue;
		if (year === void 0 && at.getTime() < new Date(now).setHours(0, 0, 0, 0)) at.setFullYear(at.getFullYear() + 1);
		date = isoDate(at);
		dayStated = true;
		rest = cut$2(rest, hit.index, hit.index + hit[0].length);
		break;
	}
	/**
	* "ngày 20" with no month: the coming 20th.
	*
	* This month if it has not passed, next month if it has — the way "ngày 20"
	* is meant in conversation. Only the bare shape: a month or a slash after
	* the number belongs to the pass above, and "ngày mai" has letters, not
	* digits.
	*/
	if (date === void 0) {
		const bareDay = /(?<![\p{L}\p{N}])(?:ngày|mùng|mồng|the)\s+(\d{1,2})(?:st|nd|rd|th)?(?!\s*(?:tháng|thang|\/|-|\d|giờ|gio|h\b|:))(?![\p{L}\p{N}])/iu.exec(rest);
		if (bareDay) {
			const day = Number(bareDay[1]);
			if (day >= 1 && day <= 31) {
				const at = new Date(now.getFullYear(), now.getMonth(), day, 0, 0, 0, 0);
				if (at.getDate() === day) {
					if (at.getTime() < new Date(now).setHours(0, 0, 0, 0)) at.setMonth(at.getMonth() + 1, day);
					if (at.getDate() === day) {
						date = isoDate(at);
						dayStated = true;
						rest = cut$2(rest, bareDay.index, bareDay.index + bareDay[0].length);
					}
				}
			}
		}
	}
	for (const { words, offset } of [
		{
			words: [
				"ngày kia",
				"ngay kia",
				"ngày mốt",
				"ngay mot"
			],
			offset: 2
		},
		{
			words: [
				"ngày mai",
				"ngay mai",
				"tomorrow"
			],
			offset: 1
		},
		{
			words: [
				"hôm nay",
				"hom nay",
				"today"
			],
			offset: 0
		},
		{
			words: ["mai"],
			offset: 1
		},
		{
			words: ["mốt", "mot"],
			offset: 2
		},
		(
		/**
		* Days already past.
		*
		* A reminder cannot be set for them and the handler will refuse — which is
		* the right answer and a far better one than the alternative, which was
		* leaving "hôm qua" in the title and scheduling for whenever the clock
		* happened to resolve to. Notes keep their words either way; only tasks and
		* reminders lift a date out at all.
		*/
		{
			words: [
				"hôm qua",
				"hom qua",
				"yesterday"
			],
			offset: -1
		}),
		{
			words: ["hôm kia", "hom kia"],
			offset: -2
		}
	]) {
		const hit = words.map((w) => ({
			w,
			i: findWord$1(lower(), w)
		})).filter((x) => x.i >= 0).sort((a, b) => b.w.length - a.w.length)[0];
		if (hit) {
			date = isoDate(addDays(now, offset));
			dayStated = true;
			rest = cut$2(rest, hit.i, hit.i + hit.w.length);
			break;
		}
	}
	if (date === void 0) for (const { words, day } of WEEKDAYS) {
		const hit = words.map((w) => ({
			w,
			i: findWord$1(lower(), w)
		})).filter((x) => x.i >= 0).sort((a, b) => b.w.length - a.w.length)[0];
		if (!hit) continue;
		const weekHit = [
			"tuần sau",
			"tuần tới",
			"next week",
			"tuần này",
			"this week"
		].map((w) => ({
			w,
			i: findWord$1(lower(), w)
		})).filter((x) => x.i >= 0).sort((a, b) => b.w.length - a.w.length)[0];
		if (weekHit) {
			date = isoDate(addDays(addDays(now, now.getDay() === 0 ? -6 : 1 - now.getDay()), (weekHit.w === "tuần này" || weekHit.w === "this week" ? 0 : 7) + (day === 0 ? 6 : day - 1)));
			rest = cut$2(rest, weekHit.i, weekHit.i + weekHit.w.length);
		} else date = isoDate(addDays(now, (day - now.getDay() + 7) % 7 || 7));
		dayStated = true;
		rest = cut$2(rest, findWord$1(lower(), hit.w), findWord$1(lower(), hit.w) + hit.w.length);
		break;
	}
	/**
	* Whole weeks and months, when no day inside them was named.
	*
	* "tuần sau" and "tháng sau" are ordinary ways to put something off. Checked
	* after the weekday pass on purpose: "thứ hai tuần sau" names a day *within*
	* the week, and the weekday is the more specific answer — this only runs when
	* nothing has claimed a date yet.
	*/
	if (date === void 0) for (const { words, days, months } of [
		{
			words: [
				"tuần sau",
				"tuần tới",
				"tuần này",
				"next week"
			],
			days: 7
		},
		{
			words: ["tuần trước", "last week"],
			days: -7
		},
		{
			words: [
				"tháng sau",
				"tháng tới",
				"next month"
			],
			days: 0,
			months: 1
		},
		{
			words: ["tháng trước", "last month"],
			days: 0,
			months: -1
		},
		{
			words: [
				"sang năm",
				"năm sau",
				"next year"
			],
			days: 0,
			months: 12
		}
	]) {
		const hit = words.map((w) => ({
			w,
			i: findWord$1(lower(), w)
		})).filter((x) => x.i >= 0).sort((a, b) => b.w.length - a.w.length)[0];
		if (!hit) continue;
		if (months !== void 0) {
			const at = new Date(now);
			at.setMonth(at.getMonth() + months);
			date = isoDate(at);
		} else date = isoDate(addDays(now, hit.w === "tuần này" ? 0 : days));
		dayStated = true;
		rest = cut$2(rest, hit.i, hit.i + hit.w.length);
		break;
	}
	/**
	* "cuối tuần" is the coming Saturday, not a seven-day offset.
	*
	* Separate from the spans above because it names a *day*, and reaching for
	* "the weekend" seven days out would land on the wrong one whenever it is
	* said midweek.
	*/
	if (date === void 0) {
		const weekend = [
			"cuối tuần",
			"cuoi tuan",
			"this weekend",
			"the weekend"
		].map((w) => ({
			w,
			i: findWord$1(lower(), w)
		})).filter((x) => x.i >= 0).sort((a, b) => b.w.length - a.w.length)[0];
		if (weekend) {
			date = isoDate(addDays(now, (6 - now.getDay() + 7) % 7 || 7));
			dayStated = true;
			rest = cut$2(rest, weekend.i, weekend.i + weekend.w.length);
		}
	}
	/**
	* "8 rưỡi" is half past eight, with the word for "hour" left out.
	*
	* Rewritten into the ordinary shape for the same reason "kém" is: everything
	* that follows — the meridiem, the next-occurrence rule, the small-hours
	* guard — applies unchanged once it looks like a clock time. Left alone it
	* was worse than unparsed: "8 rưỡi tối" read the meridiem as a part of day
	* and set 19:00, an hour and a half out, with "8 rưỡi" stranded in the title.
	*
	* Only when no unit stands between the number and "rưỡi": "5 giờ rưỡi" and
	* "2 tiếng rưỡi" are already handled where they belong.
	*/
	rest = rest.replace(/(?<![\p{L}\p{N}])(\d{1,2})\s+rưỡi(?![\p{L}\p{N}])/giu, "$1 giờ 30");
	/**
	* "5 giờ kém 15" is a quarter to five, rewritten before the clock reads it.
	*
	* A rewrite rather than a branch inside the clock pass, because the clock
	* pass is where the meridiem, the next-occurrence rule and the bare-hour
	* guard all live — every one of which applies here unchanged once the
	* expression is in the ordinary shape. Left alone it parsed as five o'clock
	* with "kém 15" stranded in the title: fifteen minutes wrong *and* two words
	* of rubbish in the reminder.
	*/
	rest = rest.replace(/(\d{1,2})\s*(?:giờ|gio|h)\s*kém\s*(\d{1,2})(?:\s*phút|\s*phut)?/giu, (whole, hourText, minuteText) => {
		const hour = Number(hourText);
		const minute = Number(minuteText);
		if (minute < 1 || minute > 59) return whole;
		return `${(hour + 23) % 24} giờ ${60 - minute}`;
	});
	/**
	* Two shapes, tried longest-first.
	*
	* `WITH_SEPARATOR` covers "3 giờ", "14h30", "15:30" — a number joined to the
	* rest by a separator. `BARE_MERIDIEM` covers "3pm" and "9am", where English
	* writes no separator at all; requiring one silently dropped every English
	* clock time while the Vietnamese ones worked, which is the kind of gap that
	* looks like "the parser is fine" until someone speaks the other language.
	*/
	/**
	* The word "phút" after the minutes is part of the time, not of the title.
	*
	* Measured: "nhắc tôi 5 giờ 24 phút đi họp" booked 17:24 correctly and left
	* a reminder called "phút đi họp". Worse, the leftover hid the qualifier
	* behind it — the meridiem search looks at the words immediately after the
	* match, found "phút" where "sáng" should have been, and "lúc 5 giờ 24 phút
	* sáng" was booked for five in the *evening*. One unconsumed word, two
	* failures, and only the second one changes the hour by twelve.
	*/
	const WITH_SEPARATOR = /(?:lúc|luc|vào lúc|vao luc|at)?\s*(\d{1,2})\s*(?::|giờ|gio|h|g)\s*(\d{1,2})?\s*(?:phút|phut|minutes?)?\s*(rưỡi|ruoi)?/iu;
	const bare = /(?:at\s*)?(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)/iu.exec(rest);
	const separated = WITH_SEPARATOR.exec(rest);
	const clock = bare ?? separated;
	if (clock && clock.index >= 0) {
		let hour = Number(clock[1]);
		let minute = clock[2] !== void 0 ? Number(clock[2]) : 0;
		if (clock === separated && clock[3] !== void 0) minute = 30;
		if (hour <= 24 && minute < 60) {
			const clockEnd = clock.index + clock[0].length;
			const inMatch = clock === bare ? (clock[3] ?? "").toLowerCase() : "";
			const before = rest.slice(Math.max(0, clock.index - 12), clock.index).toLowerCase();
			const after = rest.slice(clockEnd, clockEnd + 12).toLowerCase();
			let trailing;
			let sawMeridiem = false;
			for (const { words, add12, midnightAtTwelve, notBefore } of MERIDIEMS) {
				const word = inMatch ? words.find((w) => inMatch.startsWith(w)) : words.find((w) => after.trimStart().startsWith(w) || before.trimEnd().endsWith(w));
				if (!word) continue;
				/**
				* Not when the word is the head of an ordinary one.
				*
				* "lúc 5 giờ tối ưu lại quy trình" read "tối" as five in the evening
				* and left a task called "ưu lại quy trình". The hour is still five;
				* what it is not is evening.
				*/
				if (!inMatch && after.trimStart().startsWith(word)) {
					const offset = clockEnd + (after.length - after.trimStart().length);
					if (headsACompound(rest, offset, word)) continue;
				}
				sawMeridiem = true;
				if (!inMatch && after.trimStart().startsWith(word)) trailing = word;
				if (add12 && hour < 12 && (notBefore === void 0 || hour < notBefore)) hour += 12;
				if (!add12 && hour === 12) hour = 0;
				if (midnightAtTwelve === true && hour === 12) hour = 0;
				break;
			}
			if (hour < 24) {
				hasMeridiem = sawMeridiem;
				time = `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
				rest = cut$2(rest, clock.index, clockEnd);
				if (trailing !== void 0) {
					const i = findWord$1(rest.slice(clock.index).toLowerCase(), trailing);
					if (i >= 0) {
						/**
						* "nay" goes with the part of day it follows.
						*
						* "nhắc tôi 9 giờ tối nay xem phim" left a reminder called "nay
						* xem phim". The meridiem takes "tối" and the day pass will not
						* take "nay" — it was removed from the day words on purpose,
						* because "năm nay bận quá" is not a sentence about today — so the
						* word had nobody to belong to and ended up in the title.
						*
						* Only here, immediately behind a part of day that was just
						* consumed, where it can only mean the one thing. "mai" is left
						* alone: it names a different day and the pass after this needs it.
						*/
						const from = clock.index + i;
						const afterWord = rest.slice(from + trailing.length);
						const bare = /^\s*(nay)(?![\p{L}\p{N}])/iu.exec(afterWord);
						if (bare !== null) {
							/**
							* Removing the word must not remove what it said.
							*
							* The first version only deleted it, and that was worse than the
							* leftover it fixed: with no "nay" left, the day became an
							* inference, and the rule for an inferred day is "the soonest
							* time that clock still reads". Said at nine in the morning,
							* "8 giờ sáng nay" then meant *tomorrow* — a reminder moved a
							* day by a tidy-up. The day was stated; it is today.
							*/
							date = isoDate(now);
							dayStated = true;
						}
						rest = cut$2(rest, from, from + trailing.length + (bare === null ? 0 : bare[0].length));
					}
				}
			}
		}
	}
	/**
	* A clock time with no day means the next time that clock reads — today if
	* it has not passed, tomorrow if it has.
	*
	* This is an assumption, and it is the one people actually hold: "nhắc tôi 9
	* giờ sáng" said at 10am means tomorrow. Recorded here rather than left for a
	* caller to rediscover, because a reminder that fires immediately for a time
	* already past is the failure this prevents.
	*/
	if (time !== void 0 && date === void 0) {
		const [h, m] = time.split(":").map(Number);
		const candidates = !hasMeridiem && h >= 1 && h <= 11 ? h < 6 ? [h + 12] : [h, h + 12] : [h];
		let best = null;
		for (const hour of candidates) for (const dayOffset of [0, 1]) {
			const at = addDays(now, dayOffset);
			at.setHours(hour, m, 0, 0);
			if (at.getTime() <= now.getTime()) continue;
			if (best === null || at.getTime() < best.getTime()) best = at;
		}
		const chosen = best ?? addDays(now, 1);
		if (best === null) chosen.setHours(h, m, 0, 0);
		date = isoDate(chosen);
		time = `${String(chosen.getHours()).padStart(2, "0")}:${String(chosen.getMinutes()).padStart(2, "0")}`;
	}
	/**
	* A part of day with no clock is a time of its own.
	*
	* "nhắc tôi tối nay gọi mẹ" names a moment as plainly as "7 giờ tối" does,
	* and until now it named nothing: the day was taken, the clock pass found no
	* digits, and "tối" was left at the front of the title. The reminder was then
	* refused for having no time, and a saved one read "sáng đi học".
	*
	* Runs last, and only when nothing set a clock, because an explicit time
	* always wins — in "7 giờ tối" the word is a meridiem, which the clock pass
	* has already consumed, and this never sees it.
	*
	* The hours are conventions, not measurements. They are the middle of what
	* each word ordinarily covers, chosen so that being wrong is wrong by an hour
	* rather than by half a day.
	*/
	if (time === void 0) {
		const partsOfDay = [
			(
			/**
			* "... nay" pins the day and does not roll forward.
			*
			* "sáng nay" is *this* morning even at half past two in the afternoon,
			* when it has already gone — a note about it is still about today. The
			* bare forms below roll to the next occurrence instead, because "sáng"
			* with no day named is the next morning there is.
			*/
			{
				words: [
					"sáng nay",
					"sang nay",
					"this morning"
				],
				hour: 8,
				today: true
			}),
			{
				words: ["trưa nay", "trua nay"],
				hour: 12,
				today: true
			},
			{
				words: [
					"chiều nay",
					"chieu nay",
					"this afternoon"
				],
				hour: 15,
				today: true
			},
			{
				words: [
					"tối nay",
					"toi nay",
					"tonight",
					"this evening"
				],
				hour: 19,
				today: true
			},
			{
				words: ["đêm nay", "dem nay"],
				hour: 21,
				today: true
			},
			{
				words: [
					"nửa đêm",
					"nua dem",
					"midnight"
				],
				hour: 0
			},
			{
				words: [
					"sáng sớm",
					"sang som",
					"early morning"
				],
				hour: 6
			},
			{
				words: ["đầu giờ chiều", "dau gio chieu"],
				hour: 13
			},
			{
				words: ["cuối giờ chiều", "cuoi gio chieu"],
				hour: 17
			},
			{
				words: ["đầu giờ sáng", "dau gio sang"],
				hour: 8
			},
			{
				words: [
					"buổi sáng",
					"buoi sang",
					"sáng",
					"sang",
					"morning"
				],
				hour: 8
			},
			{
				words: [
					"buổi trưa",
					"buoi trua",
					"trưa",
					"trua",
					"noon",
					"midday"
				],
				hour: 12
			},
			{
				words: [
					"buổi chiều",
					"buoi chieu",
					"chiều",
					"chieu",
					"afternoon"
				],
				hour: 15
			},
			{
				words: [
					"buổi tối",
					"buoi toi",
					"tối",
					"toi",
					"evening"
				],
				hour: 19
			},
			{
				words: [
					"đêm",
					"dem",
					"night"
				],
				hour: 21
			}
		];
		/**
		* Every *occurrence*, not every word.
		*
		* `findWord` reports the first position only, so a sentence with the word
		* twice offered one candidate pointing at the wrong one. "sáng tạo nội
		* dung sáng mai" has two "sáng": the first heads a compound and the second
		* is the time. Refusing the compound then ended the search, and the real
		* one stayed in the title.
		*/
		const occurrences = (word) => {
			const found = [];
			let from = 0;
			for (;;) {
				const i = findWord$1(lower().slice(from), word);
				if (i < 0) break;
				found.push(from + i);
				from = from + i + word.length;
			}
			return found;
		};
		const part = partsOfDay.flatMap(({ words, hour, today }) => words.map((w) => ({
			w,
			hour,
			today
		}))).flatMap((c) => occurrences(c.w).map((i) => ({
			...c,
			i
		}))).sort((a, b) => b.w.length - a.w.length || b.i - a.i).find((c) => {
			if (c.w.includes(" ")) return true;
			if (!(rest.trim().toLowerCase() === c.w) && date === void 0) return false;
			return !headsACompound(rest, c.i, c.w);
		});
		if (part) {
			const at = new Date(date === void 0 ? now : /* @__PURE__ */ new Date(`${date}T00:00:00`));
			at.setHours(part.hour, 0, 0, 0);
			/**
			* With no day named, the part of day still has to pick one.
			*
			* Said at four in the afternoon, "sáng" means tomorrow morning — the same
			* next-occurrence reading the clock pass uses, for the same reason: a
			* moment already gone is never what was meant.
			*/
			if (date === void 0 && part.today !== true && at.getTime() <= now.getTime()) at.setDate(at.getDate() + 1);
			if (part.today === true) dayStated = true;
			date = isoDate(at);
			time = `${String(at.getHours()).padStart(2, "0")}:00`;
			rest = cut$2(rest, part.i, part.i + part.w.length);
		}
	}
	/**
	* Words that qualified the time and are not part of the title.
	*
	* "khoảng 5 giờ" left a bare "khoảng" at the front of the reminder, and
	* "đầu tháng sau" left "đầu". They only mean anything attached to the
	* expression that has just been cut out, so once it is gone so are they.
	*
	* Stripped only where the expression was actually found — with no time in
	* the sentence these are ordinary words, and "ghi chú khoảng cách hai bên"
	* must keep every one of them.
	*/
	if (date !== void 0 || time !== void 0) {
		/**
		* At the edges only, and never in the middle.
		*
		* Scanning the whole remainder took "hàng" out of "chiều lòng khách hàng"
		* and left "lòng khách". These words are qualifiers *of the expression that
		* was just removed*, so they are only stranded where it used to be — and
		* once it is gone that position is the start or the end of what is left.
		* Anywhere else they are ordinary words doing ordinary work.
		*/
		const QUALIFIERS = [
			"vào khoảng",
			"khoảng",
			"tầm",
			"trước",
			"sau",
			"đầu",
			"giữa",
			"cuối",
			"trong",
			"mỗi",
			"hàng",
			"lúc",
			"vào",
			"at",
			"on",
			"around",
			"about"
		];
		for (;;) {
			const before = rest;
			const lowered = rest.toLowerCase().trim();
			const head = QUALIFIERS.find((w) => lowered === w || lowered.startsWith(`${w} `));
			if (head !== void 0) rest = rest.trim().slice(head.length).trim();
			const tail = QUALIFIERS.find((w) => rest.toLowerCase().trim().endsWith(` ${w}`));
			if (tail !== void 0) rest = rest.trim().slice(0, rest.trim().length - tail.length).trim();
			if (rest === before) break;
		}
	}
	return {
		...date === void 0 ? {} : { date },
		...time === void 0 ? {} : { time },
		dayStated,
		...repeats ? { repeats } : {},
		rest: rest.replace(/^[\s:,.\-–—]+|[\s:,.\-–—]+$/gu, "").trim()
	};
}
//#endregion
//#region src/voice/shared/timeRange.ts
/**
* The window of time a phrase names, for narrowing a listing.
*
* ## Why this is not `parseWhen`
*
* `parseWhen` answers "when is this one thing", and returns a point: one day,
* one clock time. A listing asks a different question — "which of these fall
* inside what I said" — and the answer to that is a range. "thứ sáu" is a
* point when you are setting a reminder and a whole day when you are asking to
* see them; "tuần sau" is not a point at all.
*
* The point parser is still used underneath for everything it already knows —
* weekdays, "mai", parts of the day — so the two cannot drift on what "thứ
* sáu" means. What is added here is only the vocabulary that has no single
* moment in it: weeks, months, spans, and yesterday.
*
* ## Measured
*
* Before this, the listing filter was four strings: done, open, today,
* tomorrow. Everything else fell through to "Nothing matches that — here are
* your reminders", which looks like an answer and is not one:
*
*   liệt kê lời nhắc tuần này    → every reminder
*   liệt kê lời nhắc thứ sáu     → every reminder
*   liệt kê lời nhắc tối nay     → every reminder
*   liệt kê lời nhắc tháng này   → every reminder
*
* Pure, and takes `now`, so every case below is testable without waiting for
* a Friday.
*/
function pad(n) {
	return String(n).padStart(2, "0");
}
function iso(d) {
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function shift(now, days) {
	const d = new Date(now);
	d.setDate(d.getDate() + days);
	return d;
}
/**
* Monday as day 0.
*
* Vietnamese weeks start on Monday — thứ hai is literally "the second" — and a
* "tuần này" measured from Sunday would put Monday's reminders in last week
* for anyone asking on a Tuesday.
*/
function mondayIndex(d) {
	return (d.getDay() + 6) % 7;
}
/** Parts of the day, as hour bounds. Matches how `timeParse` reads them. */
var PARTS = [
	{
		words: ["sáng"],
		from: "05:00",
		to: "11:59",
		name: "morning"
	},
	{
		words: ["trưa"],
		from: "11:00",
		to: "13:59",
		name: "midday"
	},
	{
		words: ["chiều"],
		from: "12:00",
		to: "17:59",
		name: "afternoon"
	},
	{
		words: ["tối"],
		from: "17:00",
		to: "22:59",
		name: "evening"
	},
	{
		words: ["đêm"],
		from: "21:00",
		to: "23:59",
		name: "night"
	}
];
/** Day words that name a whole day on their own, as an offset from today. */
var WHOLE_DAYS = [
	{
		words: [
			"hôm nay",
			"trong hôm nay",
			"today"
		],
		offset: 0,
		label: "today"
	},
	{
		words: [
			"ngày mai",
			"hôm sau",
			"tomorrow"
		],
		offset: 1,
		label: "tomorrow"
	},
	{
		words: [
			"ngày kia",
			"ngày mốt",
			"hôm kia"
		],
		offset: 2,
		label: "the day after tomorrow"
	},
	{
		words: ["hôm qua", "yesterday"],
		offset: -1,
		label: "yesterday"
	}
];
/** Units for a span measured from now, in minutes. */
var UNITS = [
	{
		words: [
			"phút",
			"minute",
			"minutes"
		],
		minutes: 1,
		name: "minute"
	},
	{
		words: [
			"tiếng",
			"giờ",
			"hour",
			"hours"
		],
		minutes: 60,
		name: "hour"
	},
	{
		words: [
			"ngày",
			"day",
			"days"
		],
		minutes: 1440,
		name: "day"
	},
	{
		words: [
			"tuần",
			"week",
			"weeks"
		],
		minutes: 10080,
		name: "week"
	}
];
/**
* Prepositions that introduce a time phrase and belong to it.
*
* "liệt kê các lời nhắc **trong** tuần này" left "trong" standing as the
* reference once the window was lifted out, so the listing went looking for a
* reminder *called* "trong", found none, and answered "Nothing matches that"
* under a correctly filtered list. The word is part of saying when, not part
* of naming anything.
*/
var LEAD_INS = [
	"trong",
	"vào",
	"của",
	"in",
	"on",
	"for"
];
function cut$1(text, at, length) {
	let start = at;
	const before = text.slice(0, at).trimEnd();
	const lead = LEAD_INS.find((word) => {
		const lower = before.toLowerCase();
		return lower === word || lower.endsWith(` ${word}`);
	});
	if (lead !== void 0) start = before.length - lead.length;
	return `${text.slice(0, start)} ${text.slice(at + length)}`.replace(/\s+/gu, " ").trim();
}
/** Finds `phrase` at word boundaries, or -1. Case-insensitive. */
function findWord(text, phrase) {
	const at = ` ${text.toLowerCase()} `.indexOf(` ${phrase} `);
	return at === -1 ? -1 : at;
}
/**
* "trong ba ngày tới" — a spelled number the point parser refuses to convert.
*
* `digitiseHours` is right to refuse it. Its rule is that "nữa" and nothing
* else may follow an ambiguous number over a day or week unit, because "gọi
* cho ba tuần sau" is *call dad next week* and converting there scheduled a
* reminder three weeks out with "gọi cho" as its title. "tới" carries exactly
* the same ambiguity as "sau".
*
* What removes it is the "trong" in front. "gọi cho ba tuần tới" has no
* preposition introducing a span; "trong ba tuần tới" cannot be anything else.
* So the conversion happens here, in that frame only, and the shared converter
* keeps its narrower rule for every other sentence.
*/
function spelledSpan(text) {
	const words = Object.keys(NUMBER_WORDS).sort((a, b) => b.length - a.length);
	const units = "phút|tiếng|giờ|ngày|tuần|minutes?|hours?|days?|weeks?";
	for (const word of words) {
		const pattern = new RegExp(`(trong\\s+)${word}(?=\\s*(?:${units})\\s+(?:tới|nữa))`, "giu");
		const next = text.replace(pattern, `$1${NUMBER_WORDS[word]}`);
		if (next !== text) return next;
	}
	return text;
}
/**
* A weekday inside a named week: "thứ ba tuần trước", "thứ năm tuần này".
*
* The point parser resolves a bare weekday to its next occurrence, which is
* the only sensible reading when booking something. It has no idea what to do
* with a week qualifier behind it, so "thứ ba tuần trước" came back as *next*
* Tuesday — a question about last week answered with a day that has not
* happened.
*
* Monday is index zero here for the same reason it is everywhere else in this
* file: thứ hai is literally "the second", and Vietnamese weeks start there.
*/
var WEEKDAY_WORDS = [
	{
		words: [
			"thứ hai",
			"thứ 2",
			"monday"
		],
		index: 0
	},
	{
		words: [
			"thứ ba",
			"thứ 3",
			"tuesday"
		],
		index: 1
	},
	{
		words: [
			"thứ tư",
			"thứ 4",
			"wednesday"
		],
		index: 2
	},
	{
		words: [
			"thứ năm",
			"thứ 5",
			"thursday"
		],
		index: 3
	},
	{
		words: [
			"thứ sáu",
			"thứ 6",
			"friday"
		],
		index: 4
	},
	{
		words: [
			"thứ bảy",
			"thứ 7",
			"saturday"
		],
		index: 5
	},
	{
		words: ["chủ nhật", "sunday"],
		index: 6
	}
];
var WEEK_OF = [
	{
		words: ["tuần trước", "last week"],
		offset: -1,
		name: "last"
	},
	{
		words: ["tuần này", "this week"],
		offset: 0,
		name: "this"
	},
	{
		words: [
			"tuần sau",
			"tuần tới",
			"next week"
		],
		offset: 1,
		name: "next"
	}
];
function weekdayInWeek(text, now) {
	for (const day of WEEKDAY_WORDS) for (const word of day.words) {
		const at = findWord(text, word);
		if (at === -1) continue;
		const after = text.slice(at + word.length);
		for (const week of WEEK_OF) for (const qualifier of week.words) {
			const q = /^[\s,]*/u.exec(after)?.[0].length ?? 0;
			if (!after.slice(q).toLowerCase().startsWith(qualifier)) continue;
			const date = iso(shift(shift(now, -mondayIndex(now) + week.offset * 7), day.index));
			const named = new Date(date).toLocaleDateString("en-US", { weekday: "long" });
			return {
				from: date,
				to: date,
				label: week.offset === 0 ? `on ${named}` : `${named} ${week.name} week`,
				rest: cut$1(text, at, word.length + q + qualifier.length)
			};
		}
	}
	return null;
}
/**
* "từ thứ ba tuần trước cho tới thứ năm tuần này" — a range with two ends.
*
* Measured, from the user's screen: it answered "33 reminders on Tuesday". The
* parser found the first weekday it recognised, took that as the whole answer,
* and threw the rest of the sentence away — so a question about nine days came
* back as a question about one, with no sign that anything had been dropped.
*
* Each end is parsed as a window in its own right, which is what makes the
* shapes compose: "từ hôm nay đến cuối tuần", "từ 3 giờ chiều đến 6 giờ", "từ
* thứ hai tuần trước đến hôm nay" all work without a rule of their own.
*/
function parseRange(text, now) {
	const split = /(?:^|[\s,])từ\s+(.+?)\s+(?:đến|tới|cho\s+đến|cho\s+tới|->|to)\s+(.+)$/iu.exec(text);
	if (split === null) return null;
	const start = windowOf(split[1] ?? "", now);
	let end = windowOf(split[2] ?? "", now);
	if (start === null || end === null) return null;
	/**
	* An end before the start is a weekday that resolved the wrong side of it.
	*
	* "từ thứ hai đến thứ sáu", said on a Tuesday: a bare weekday resolves to
	* its next occurrence, so Monday landed six days out and Friday three — the
	* range came out backwards and was refused. Each end is right on its own;
	* what is missing is that the second is relative to the first.
	*
	* Pushed forward in whole weeks rather than pulling the start back, because
	* the start is the end the speaker anchored on and the rest of this codebase
	* reads an unqualified day as the soonest one still ahead.
	*/
	for (let guard = 0; end.to < start.from && guard < 5; guard++) {
		const [y, m, d] = end.to.split("-").map(Number);
		const later = iso(shift(new Date(y ?? 0, (m ?? 1) - 1, d ?? 1), 7));
		end = {
			...end,
			from: later,
			to: later
		};
	}
	if (end.to < start.from) return null;
	return {
		from: start.from,
		to: end.to,
		...start.fromTime === void 0 ? {} : { fromTime: start.fromTime },
		...end.toTime === void 0 ? {} : { toTime: end.toTime },
		label: `${start.label.replace(/^on /u, "")} to ${end.label.replace(/^on /u, "")}`,
		rest: `${text.slice(0, split.index)} ${end.rest}`.replace(/\s+/gu, " ").trim()
	};
}
/**
* The window a phrase names, or null when it names none.
*
* Order matters and is the whole design. The longest and most specific shapes
* are tried first: "sáng mai" must not be read as "mai" with a stray word, and
* "tuần sau" must not be read as the weekday parser's idea of "sau".
*/
function parseWindow(raw, now = /* @__PURE__ */ new Date()) {
	/**
	* A two-ended range is read before anything else, because every rung below
	* would happily answer with just one of its ends.
	*/
	const ranged = parseRange(raw, now);
	if (ranged !== null) return ranged;
	return windowOf(raw, now);
}
function windowOf(raw, now = /* @__PURE__ */ new Date()) {
	/**
	* Spelled numbers become digits before anything looks for a span.
	*
	* "liệt kê các lời nhắc trong mười phút nữa" found no window at all and the
	* listing fell back to showing all eight reminders under the words "nothing
	* matches that". People say "mười phút", not "10 phút".
	*
	* The same converter the point parser uses, with the same guard: a unit has
	* to follow the word, because every one of these has an ordinary meaning —
	* `ba` is "dad", `năm` is "year", `tư` is "fourth" — and a blind
	* substitution turns "gọi cho ba" into "gọi cho 3".
	*
	* `rest` is therefore cut from the converted text, so a number that survives
	* in it comes back as a digit. That is the honest trade: it is the reference
	* used to match an item's words, and a listing's reference is almost always
	* empty by the time it gets here.
	*/
	const text = spelledSpan(digitiseHours(raw));
	const today = iso(now);
	/**
	* A span measured from this moment: "trong 2 tiếng nữa", "4 phút nữa".
	*
	* First, because the number and unit would otherwise be read as a clock
	* time — "2 tiếng" has an hour in it as far as the point parser is
	* concerned, and it would answer with 02:00.
	*/
	const span = /(?:trong\s+)?(\d{1,3})\s*(phút|tiếng|giờ|ngày|tuần|minutes?|hours?|days?|weeks?)(?:\s+nữa|\s+tới)?/iu.exec(text);
	if (span !== null && /nữa|tới|trong/iu.test(text)) {
		const unit = UNITS.find((u) => u.words.includes((span[2] ?? "").toLowerCase()));
		if (unit !== void 0) {
			const end = new Date(now.getTime() + Number(span[1] ?? 0) * unit.minutes * 6e4);
			return {
				from: today,
				to: iso(end),
				fromTime: `${pad(now.getHours())}:${pad(now.getMinutes())}`,
				toTime: `${pad(end.getHours())}:${pad(end.getMinutes())}`,
				label: `in the next ${span[1]} ${unit.name}${Number(span[1]) === 1 ? "" : "s"}`,
				rest: cut$1(text, span.index, span[0].length)
			};
		}
	}
	/**
	* A part of a named day: "sáng mai", "tối nay", "chiều thứ sáu".
	*
	* Before the whole-day words, because "mai" is inside "sáng mai" and taking
	* it first would widen the answer from a morning to a day.
	*/
	for (const part of PARTS) for (const word of part.words) {
		const at = findWord(text, word);
		if (at === -1) continue;
		const day = dayOf(cut$1(text, at, word.length), now);
		if (day === null) continue;
		return {
			from: day.date,
			to: day.date,
			fromTime: part.from,
			toTime: part.to,
			/**
			* "tomorrow morning", not "sáng on tomorrow". A day whose label is a
			* weekday keeps its preposition — "on Friday afternoon" — while today
			* and tomorrow read as bare adjectives.
			*/
			label: day.label === "today" ? `this ${part.name}` : `${day.label} ${part.name}`,
			rest: day.rest
		};
	}
	/**
	* A weekday carrying a week qualifier, before the bare week phrases.
	*
	* "thứ ba tuần trước" contains "tuần trước", and letting that rung go first
	* would answer with the whole of last week for a sentence naming one day of
	* it — and quietly drop the weekday, which is the wrong-answer shape this
	* file keeps having to guard against.
	*/
	const qualified = weekdayInWeek(text, now);
	if (qualified !== null) return qualified;
	const spans = [
		{
			words: ["tuần này", "this week"],
			make: () => weekFrom(now, 0)
		},
		{
			words: [
				"tuần sau",
				"tuần tới",
				"next week"
			],
			make: () => weekFrom(now, 1)
		},
		{
			words: ["tuần trước", "last week"],
			make: () => weekFrom(now, -1)
		},
		{
			words: ["cuối tuần", "this weekend"],
			make: () => {
				const monday = shift(now, -mondayIndex(now));
				return {
					from: iso(shift(monday, 5)),
					to: iso(shift(monday, 6)),
					label: "this weekend",
					rest: ""
				};
			}
		},
		{
			words: ["tháng này", "this month"],
			make: () => monthFrom(now, 0)
		},
		{
			words: [
				"tháng sau",
				"tháng tới",
				"next month"
			],
			make: () => monthFrom(now, 1)
		},
		{
			words: ["tháng trước", "last month"],
			make: () => monthFrom(now, -1)
		}
	];
	for (const { words, make } of spans) for (const phrase of words) {
		const at = findWord(text, phrase);
		if (at === -1) continue;
		/**
		* A number in front means this is a span, not "next week".
		*
		* "trong hai tuần tới" answered *next week* — the phrase matched, the
		* number was dropped without a word, and two weeks silently became one.
		* A wrong answer is worse than none here, so when a count leads the
		* phrase this rung declines and the sentence goes on to be read as a
		* span, or to be honestly not understood.
		*/
		const before = text.slice(0, Math.max(0, at - 1)).trimEnd().split(/\s+/u).pop() ?? "";
		if (/^\d+$/u.test(before) || Object.hasOwn(NUMBER_WORDS, before.toLowerCase())) continue;
		const window = make();
		if (window === null) continue;
		return {
			...window,
			rest: cut$1(text, at, phrase.length)
		};
	}
	const day = dayOf(text, now);
	if (day !== null) return {
		from: day.date,
		to: day.date,
		label: day.label,
		rest: day.rest
	};
	return null;
}
function weekFrom(now, offset) {
	const monday = shift(now, -mondayIndex(now) + offset * 7);
	return {
		from: iso(monday),
		to: iso(shift(monday, 6)),
		label: offset === 0 ? "this week" : offset === 1 ? "next week" : "last week",
		rest: ""
	};
}
function monthFrom(now, offset) {
	const first = new Date(now.getFullYear(), now.getMonth() + offset, 1);
	const last = new Date(now.getFullYear(), now.getMonth() + offset + 1, 0);
	return {
		from: iso(first),
		to: iso(last),
		label: offset === 0 ? "this month" : offset === 1 ? "next month" : "last month",
		rest: ""
	};
}
/**
* The single day a phrase names, through the same rules a reminder uses.
*
* `parseWhen` is asked rather than a second weekday table, so "thứ sáu" cannot
* mean one day when setting a reminder and another when listing them. Its
* inferred day is refused: given a bare clock time it supplies the soonest day
* that hour is still future, which is right for booking something and wrong
* here — "liệt kê lời nhắc lúc 4 giờ" is not a request about tomorrow.
*/
function dayOf(text, now) {
	for (const { words, offset, label } of WHOLE_DAYS) for (const phrase of words) {
		const at = findWord(text, phrase);
		if (at === -1) continue;
		return {
			date: iso(shift(now, offset)),
			label,
			rest: cut$1(text, at, phrase.length)
		};
	}
	for (const [word, offset, label] of [[
		"mai",
		1,
		"tomorrow"
	], [
		"nay",
		0,
		"today"
	]]) {
		const at = findWord(text, word);
		if (at === -1) continue;
		return {
			date: iso(shift(now, offset)),
			label,
			rest: cut$1(text, at, word.length)
		};
	}
	const when = parseWhen(text, now);
	if (!when.dayStated || when.date === void 0) return null;
	/**
	* Named, not printed as an ISO date. "1 reminder 2026-09-04" is a machine
	* reporting its internals at a person who said "thứ sáu".
	*/
	const [y, m, d] = when.date.split("-").map(Number);
	const weekday = new Date(y ?? 0, (m ?? 1) - 1, d ?? 1).toLocaleDateString("en-US", { weekday: "long" });
	return {
		date: when.date,
		label: `on ${weekday}`,
		rest: when.rest
	};
}
//#endregion
//#region src/query/parse.ts
/**
* Phrases that scope a query to where the user is standing.
*
* Longest first: "trang web này" must not be consumed by "trang này".
*/
var SCOPE_CUES = [{
	scope: "host",
	phrases: [
		"trang web này",
		"trên web này",
		"web này",
		"site này",
		"this site"
	]
}, {
	scope: "page",
	phrases: [
		"trên trang này",
		"ở trang này",
		"trang này",
		"ở đây",
		"this page"
	]
}];
var INTENT_CUES = [{
	intent: "REMINDER",
	phrases: [
		"lời nhắc",
		"nhắc nhở",
		"reminder"
	]
}, {
	intent: "TASK",
	phrases: [
		"việc cần làm",
		"task",
		"todo"
	]
}];
/**
* Past-tense vocabulary `parseWindow` does not carry.
*
* It is ported verbatim from the desktop app, which is the copy with the
* harness behind it, so it is extended here rather than edited. These are the
* phrasings that only appear when asking about the past — the desktop's
* listing filter never needed "3 ngày qua" because it lists what is ahead.
*/
var RECENT_DAYS = [
	{
		pattern: /\b(\d+)\s*(?:ngày|hôm)\s*(?:qua|trước|vừa rồi)\b/iu,
		days: "match",
		label: "N ngày qua"
	},
	{
		pattern: /\btuần (?:rồi|vừa rồi|vừa qua)\b/iu,
		days: 7,
		label: "tuần rồi"
	},
	{
		pattern: /\b(?:hôm trước|mấy hôm trước|dạo trước|vừa rồi|gần đây|lúc nãy|hồi nãy)\b/iu,
		days: 7,
		label: "gần đây"
	},
	{
		pattern: /\btháng (?:rồi|vừa rồi|vừa qua)\b/iu,
		days: 30,
		label: "tháng rồi"
	}
];
/**
* Words that carry no meaning to match on.
*
* The verbs of note-taking are in here on purpose. "Tôi ghi gì về pricing"
* would otherwise search for notes containing the word "ghi", which is every
* note the user ever dictated with a cue.
*/
var STOPWORDS = /* @__PURE__ */ new Set([
	"tôi",
	"mình",
	"em",
	"anh",
	"chị",
	"gì",
	"nào",
	"đâu",
	"ai",
	"sao",
	"về",
	"của",
	"cho",
	"với",
	"và",
	"là",
	"có",
	"các",
	"những",
	"cái",
	"một",
	"đã",
	"đang",
	"sẽ",
	"rồi",
	"thì",
	"mà",
	"ở",
	"trên",
	"trong",
	"hay",
	"ghi",
	"lưu",
	"note",
	"notes",
	"chú",
	"nhớ",
	"ghi chú",
	"i",
	"my",
	"me",
	"the",
	"a",
	"an",
	"about",
	"on",
	"what",
	"did",
	"do",
	"note",
	"notes",
	"saved",
	"save",
	"any",
	"is",
	"was",
	"of",
	"for",
	"tìm",
	"kiếm",
	"xem",
	"lại",
	"giúp",
	"coi",
	"search",
	"find",
	"show"
]);
var MIN_TERM_LENGTH = 2;
function parseQuery(raw, now = /* @__PURE__ */ new Date()) {
	let rest = raw.trim();
	const scope = takeScope(rest);
	rest = scope.rest;
	const intent = takeIntent(rest);
	rest = intent.rest;
	const window = parseWindow(rest, now);
	let from = null;
	let to = null;
	let windowLabel = null;
	if (window !== null) {
		rest = window.rest;
		from = atLocal(window.from, window.fromTime ?? "00:00");
		to = atLocal(window.to, window.toTime ?? "23:59") + 59999;
	} else {
		const recent = takeRecent(rest, now);
		if (recent !== null) {
			rest = recent.rest;
			from = recent.from;
			to = recent.to;
		}
	}
	if (from !== null && to !== null) windowLabel = describeWindow(from, to, now);
	const people = extractPeople(rest).filter((m) => m.strong).map((m) => m.value);
	const text = collapse(rest);
	const terms = tokenize(text);
	return {
		text,
		terms,
		people,
		from,
		to,
		windowLabel,
		scope: scope.scope,
		intent: intent.intent,
		empty: terms.length === 0 && people.length === 0
	};
}
/**
* Says a resolved window back in Vietnamese.
*
* Times are shown only when the window is not a whole number of days: "sáng
* nay" narrows to 05:00-11:59 and the user should see that it did.
*/
function describeWindow(from, to, now = /* @__PURE__ */ new Date()) {
	const start = new Date(from);
	const end = new Date(to);
	const wholeDays = start.getHours() === 0 && start.getMinutes() === 0 && end.getHours() === 23 && end.getMinutes() === 59;
	const day = ymd(start) === ymd(end) ? relativeDay(start, now) : `${dm(start)} – ${dm(end)}`;
	if (wholeDays) return day;
	return `${day}, ${hm(start)}–${hm(end)}`;
}
function relativeDay(date, now) {
	const days = Math.round((midnight(date) - midnight(now)) / 864e5);
	if (days === 0) return "hôm nay";
	if (days === -1) return "hôm qua";
	if (days === 1) return "ngày mai";
	if (days === -2) return "hôm kia";
	return dm(date);
}
function midnight(date) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
}
var two = (n) => String(n).padStart(2, "0");
var ymd = (d) => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
var dm = (d) => `${two(d.getDate())}/${two(d.getMonth() + 1)}`;
var hm = (d) => `${two(d.getHours())}:${two(d.getMinutes())}`;
function takeScope(raw) {
	const lower = raw.toLowerCase();
	for (const entry of SCOPE_CUES) for (const phrase of entry.phrases) {
		const index = lower.indexOf(phrase);
		if (index >= 0) return {
			scope: entry.scope,
			rest: cut(raw, index, phrase.length)
		};
	}
	return {
		scope: "all",
		rest: raw
	};
}
function takeIntent(raw) {
	const lower = raw.toLowerCase();
	for (const entry of INTENT_CUES) for (const phrase of entry.phrases) {
		const index = lower.indexOf(phrase);
		if (index >= 0) return {
			intent: entry.intent,
			rest: cut(raw, index, phrase.length)
		};
	}
	return {
		intent: null,
		rest: raw
	};
}
function takeRecent(raw, now) {
	for (const entry of RECENT_DAYS) {
		const match = entry.pattern.exec(raw);
		if (match === null) continue;
		const captured = match[1];
		const days = entry.days === "match" ? Number(captured) : entry.days;
		if (!Number.isFinite(days) || days <= 0) continue;
		const start = new Date(now);
		start.setDate(start.getDate() - Math.floor(days));
		start.setHours(0, 0, 0, 0);
		const end = new Date(now);
		end.setHours(23, 59, 59, 999);
		return {
			from: start.getTime(),
			to: end.getTime(),
			label: entry.days === "match" ? `${days} ngày qua` : entry.label,
			rest: cut(raw, match.index, match[0].length)
		};
	}
	return null;
}
/** `YYYY-MM-DD` + `HH:MM`, read in the user's own timezone. */
function atLocal(date, time) {
	const [y, m, d] = date.split("-").map(Number);
	const [hh, mm] = time.split(":").map(Number);
	return new Date(y ?? 1970, (m ?? 1) - 1, d ?? 1, hh ?? 0, mm ?? 0, 0, 0).getTime();
}
function cut(raw, index, length) {
	return collapse(raw.slice(0, index) + " " + raw.slice(index + length));
}
function collapse(raw) {
	return raw.replace(/\s+/g, " ").replace(/^[\s,.?!:;-]+|[\s,.?!:;-]+$/gu, "").trim();
}
function tokenize(text) {
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	for (const word of text.toLowerCase().split(/[^\p{L}\p{N}@._-]+/u)) {
		if (word.length < MIN_TERM_LENGTH) continue;
		if (STOPWORDS.has(word)) continue;
		if (seen.has(word)) continue;
		seen.add(word);
		out.push(word);
	}
	return out;
}
//#endregion
export { toEntity as i, parseWhen as n, extractPeople as r, parseQuery as t };
