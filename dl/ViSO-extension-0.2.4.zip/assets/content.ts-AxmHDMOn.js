import { t as log } from "./log-BabVsn0h.js";
import { n as icon, r as star, t as comet } from "./icons-DhBKST9O.js";
import { t as parseQuery } from "./parse-fgDs-rmF.js";
import { a as scopeFor, c as classifyIntent, f as sourceLabel, g as isBackgroundPush, l as REPEAT_LABELS, m as fnv1a, n as EXTRACT_CONFIG, o as scopeLabel, p as urlAdapters, r as samePage, s as readTyped, t as APP_LIKE_PATH_SEGMENTS, v as sendToBackground } from "./config-B2gP0ogj.js";
//#region \0rolldown/runtime.js
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
//#endregion
//#region src/content/ui/styles.ts
/**
* All ViSO CSS lives here as a string and is adopted into the closed shadow
* root (spec §3.2). Nothing is ever appended to the page's own stylesheets.
*
* Two-way isolation notes:
*  - Shadow DOM already blocks *selector* matching in both directions.
*  - It does NOT block *inherited* properties (font, color, line-height,
*    direction, visibility, text-transform...) from crossing into the root.
*    `:host { all: initial }` cuts that inheritance, and everything we need is
*    re-declared below.
*  - The host element itself still lives in the page tree, so a page rule like
*    `* { display: none }` can reach it. That is defended separately with
*    inline !important properties in ShadowHost.ts.
*/
var SHADOW_STYLES = `
:host {
  all: initial;

  /*
   * The Notes HUD — "Light Blue Minimal UI" (Figma, 2026-09-14), the same
   * skin the desktop's panel wears, so the two look like one product.
   *
   * The panel fill is opaque, deliberately: the design asks for translucent
   * glass over a blur, and a blur over somebody else's page is exactly what a
   * content script must not be seen to do — and a translucent fill without one
   * reads as grime, sharp page text showing through a veil. The glass inside
   * the panel is genuinely translucent, because the panel is behind it.
   */
  --viso-panel-fill: linear-gradient(165deg, #d6e8fd 0%, #c9def9 50%, #c2d8f6 100%);
  --viso-panel-border: rgba(255, 255, 255, 0.85);

  --viso-glass: rgba(255, 255, 255, 0.46);
  --viso-glass-hover: rgba(255, 255, 255, 0.62);
  --viso-glass-edge: rgba(255, 255, 255, 0.9);
  --viso-field: rgba(255, 255, 255, 0.3);
  --viso-tile: rgba(196, 218, 250, 0.75);
  --viso-menu: rgba(255, 255, 255, 0.97);
  --viso-menu-shadow: 0 12px 30px rgba(60, 100, 170, 0.22);

  --viso-radius-panel: 24px;
  --viso-radius-card: 18px;
  --viso-radius-control: 12px;
  --viso-radius-pill: 999px;

  --viso-accent: #2f6fe8;
  --viso-accent-soft: rgba(47, 111, 232, 0.16);
  --viso-accent-gradient: linear-gradient(180deg, #3d84ff 0%, #2560e0 100%);
  --viso-accent-glow: rgba(47, 111, 232, 0.35);
  --viso-accent-to: #2560e0;

  /* The orb keeps the product's own palette in both themes. */
  --viso-orb-core: #ffffff;
  --viso-orb-edge: #2f6fe8;

  --viso-success: #22c55e;
  --viso-danger: #d34b43;

  --viso-text: #1b2b4b;
  --viso-text-2: #5f7396;
  --viso-text-3: #8ea0bd;

  --viso-font: 'Inter', 'SF Pro Display', -apple-system, BlinkMacSystemFont,
               'Segoe UI', sans-serif;
  --viso-weight: 600;

  /* Deeper than the app's, because this panel floats over other people's pages
     rather than a desktop. */
  --viso-shadow: 0 18px 50px rgba(30, 60, 120, 0.22), 0 2px 8px rgba(30, 60, 120, 0.1);
}

.layer {
  font-family: var(--viso-font);
  /* Which way the panel unfolds. Set from the dot's position, because a panel
     anchored to the right edge runs off the screen once the dot is dragged to
     the left of it — and off the bottom once it is dragged low. */
  --viso-open-x: flex-end;
  --viso-open-y: column;
  /* 1.25x the original scale. At 12px the secondary text was legible only if
     you leaned in, which is the wrong posture for something meant to be glanced
     at over whatever else is on screen. */
  font-size: 15px;
  line-height: 1.45;
  color: var(--viso-text);
  -webkit-font-smoothing: antialiased;
  /* The layer spans the corner but must not eat clicks meant for the page. */
  pointer-events: none;
  display: flex;
  flex-direction: var(--viso-open-y);
  align-items: var(--viso-open-x);
  gap: 8px;
}

.layer[data-side="left"]  { --viso-open-x: flex-start; }
.layer[data-side="right"] { --viso-open-x: flex-end; }
/* Reversed so the dot stays put and the panel grows upward instead. */
.layer[data-vside="bottom"] { --viso-open-y: column-reverse; }

/* --------------------------------------------------------------- card ---- */
/* Hard background, never inherited from the site: the panel has to stay
   readable on light and dark pages alike (spec §3.2). */

.card {
  pointer-events: auto;
  box-sizing: border-box;
  /* At 0.8 of the design's size, like the desktop panel: the sizes below are
     the design's, and this is the one number that scales them all. */
  zoom: calc(0.8 / var(--viso-page-zoom, 1));
  /*
   * Typography declared on the card itself, not only inherited from the layer.
   * Cards once lived outside the layer and rendered in the browser's default
   * serif, because :host resets everything with \`all: initial\`. Stating it
   * here means no future placement can bring Times back.
   */
  font-family: var(--viso-font);
  font-size: 15px;
  line-height: 1.45;
  text-align: left;
  -webkit-font-smoothing: antialiased;
  /*
   * Wide enough for two columns of cards, which is how the design lays notes
   * out; the desktop panel does the same at 840.
   */
  width: 560px;
  padding: 16px;
  border-radius: var(--viso-radius-panel);
  border: 1.5px solid var(--viso-panel-border);
  background: var(--viso-panel-fill);
  color: var(--viso-text);
  box-shadow: var(--viso-shadow);
}

.card[hidden] { display: none; }

.card__title {
  margin: 0 0 5px;
  font-size: 16px;
  font-weight: 600;
}

.card__body {
  margin: 0 0 14px;
  font-size: 15px;
  color: var(--viso-text-2);
}

.card__actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

.btn {
  font: inherit;
  font-size: 14px;
  font-weight: var(--viso-weight);
  padding: 6px 14px;
  border-radius: var(--viso-radius-pill);
  border: 1.5px solid var(--viso-glass-edge);
  background: var(--viso-glass);
  color: var(--viso-text);
  cursor: pointer;
}

.btn:hover { background: var(--viso-glass-hover); }
.btn:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }

.btn--primary {
  background: var(--viso-accent-gradient);
  border-color: transparent;
  color: #ffffff;
  font-weight: var(--viso-weight);
  box-shadow: 0 8px 20px var(--viso-accent-glow);
}

.btn--primary:hover { filter: brightness(1.1); }

/* ----------------------------------------------------------- progress ---- */

.progress {
  height: 4px;
  border-radius: 2px;
  background: color-mix(in srgb, var(--viso-text) 12%, transparent);
  overflow: hidden;
}

.progress__fill {
  height: 100%;
  width: 0%;
  background: var(--viso-accent);
  transition: width 200ms linear;
}

/* Unknown total: sweep instead of pretending to know a percentage. */
.progress--indeterminate .progress__fill {
  width: 35%;
  animation: viso-sweep 1.2s ease-in-out infinite;
}

@keyframes viso-sweep {
  0%   { transform: translateX(-100%); }
  100% { transform: translateX(340%); }
}

@media (prefers-reduced-motion: reduce) {
  .progress--indeterminate .progress__fill { animation: none; width: 100%; opacity: 0.5; }
}

.card__header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px;
}

.card__memory {
  margin: 7px 0 5px;
  font-size: 16px;
  line-height: 1.5;
}

.card__source {
  margin: 0 0 14px;
  font-size: 14px;
  color: var(--viso-text-3);
}

.card__rating {
  display: flex;
  gap: 2px;
  margin-right: auto;
}

.btn-icon {
  font: inherit;
  font-size: 16px;
  line-height: 1;
  padding: 5px 7px;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: var(--viso-text);
  opacity: 0.6;
  cursor: pointer;
}

.btn-icon:hover { opacity: 1; background: color-mix(in srgb, var(--viso-text) 10%, transparent); }
.btn-icon:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }

.card__actions { align-items: center; }

/* -------------------------------------------------------------- panel ---- */

/*
 * The HUD, laid out like a clipboard history: header, search, filters, a list
 * whose every row says what it is and where it came from, and the composer
 * last, where a chat input sits.
 */
.hud {
  padding: 16px 16px 16px 20px;
  /* Never taller than the window. Where it sits is the user's, but an open
     panel that would run off the bottom is lifted to fit (content.ts fit()),
     so this only clips on a window shorter than the HUD itself. */
  max-height: calc(100vh - 16px);
  overflow-y: auto;
}
/*
 * Open, the HUD is a column whose list gives way: when the composer grows
 * (a long reminder under a kind chip) it is the list that shrinks and
 * scrolls, never the composer that slides out of the panel. Measured: with
 * the panel at its full height, three typed lines pushed the mic and "Lưu"
 * below the rounded edge, reachable only by scrolling the panel itself.
 */
/*
 * hidden must win. The flex rule below is an author display, and an author
 * display beats the browser's own [hidden] { display: none } —
 * so a HUD built hidden and not yet collapsed was on screen, open and empty,
 * from the moment it was appended until the page's notes arrived and it was
 * told to be the button. Half a second of a full panel that then snapped to
 * a tab: the "flash" that Button mode was chosen to be rid of.
 */
.hud[hidden], .hud__settings[hidden], .hud__view-menu[hidden] { display: none !important; }
.hud:not(.hud--collapsed) { display: flex; flex-direction: column; }
.hud:not(.hud--collapsed) .hud__notes { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0; }
.hud:not(.hud--collapsed) .hud__list { flex: 1 1 auto; min-height: 96px; }
.hud:not(.hud--collapsed) .hud__composer { flex: none; }

.hud__header { display: flex; align-items: center; gap: 10px; margin: 0 0 12px; }

/* The header is the handle for moving the HUD up and down the right edge. */
.hud__header {
  cursor: grab;
  user-select: none;
  -webkit-user-select: none;
  touch-action: none;
}
.hud__header:active { cursor: grabbing; }
.hud__header button { cursor: pointer; }

/*
 * Collapsed: a tab on the right edge — the logo and how many notes are here.
 * The whole tab is the target, 44px tall, so bringing the HUD back never takes
 * aim. It is still the drag handle, so it moves up and down the edge.
 */
.hud__tab { display: none; }
.hud--collapsed {
  width: auto;
  min-width: 0;
  padding: 0;
  border-radius: 22px;
  overflow: visible;
}
.hud--collapsed .hud__header { margin: 0; display: flex; align-items: center; position: relative; }
.hud--collapsed .hud__heading,
.hud--collapsed .hud__place,
.hud--collapsed .hud__comet-title,
.hud--collapsed .hud__icon-btn,
.hud--collapsed .hud__search,
.hud--collapsed .hud__chips,
.hud--collapsed .hud__notes,
.hud--collapsed .hud__composer { display: none; }
/* The peek: under the button, a column of the newest notes here, one per
   line, and "+N" — the way a phone stacks a site's notifications. */
.hud__peek { display: none; }
.hud--collapsed .hud__peek {
  position: absolute; top: calc(100% + 10px); right: 0;
  display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
  width: 325px;
}
.hud--collapsed .hud__peek[hidden] { display: none; }
/* The cards, as a phone draws its notifications: dark, soft-cornered, the
   icon in a rounded square, the words in white with the time at the right. */
.hud__peek-card {
  display: flex; align-items: center; gap: 12px;
  width: 100%; box-sizing: border-box; padding: 11px 14px 11px 12px;
  border: 1px solid rgba(255, 255, 255, .08); border-radius: 20px;
  background: rgba(30, 30, 32, .96); color: #fff;
  box-shadow: 0 12px 32px rgba(0, 0, 0, .35);
  font: inherit; font-size: 15px; text-align: left; cursor: pointer;
}
.hud__peek-card:hover { background: rgba(44, 44, 47, .97); }
.hud__peek-icon { flex: none; display: grid; place-items: center; width: 40px; height: 40px; border-radius: 11px; background: #fff; color: #1f6fe8; overflow: hidden; }
.hud__peek-card--reminder .hud__peek-icon { color: #b86e00; }
.hud__peek-card--task .hud__peek-icon { color: #1f8a3a; }
.hud__peek-favicon { width: 100%; height: 100%; object-fit: cover; }
.hud__peek-words { display: flex; flex-direction: column; min-width: 0; flex: 1; gap: 2px; line-height: 1.25; }
.hud__peek-line { display: flex; align-items: baseline; gap: 10px; min-width: 0; }
.hud__peek-text { flex: 1; min-width: 0; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.hud__peek-ago { flex: none; font-size: 12.5px; color: rgba(255, 255, 255, .55); }
.hud__peek-kind { font-size: 13.5px; color: rgba(255, 255, 255, .8); }
.hud__peek-more {
  height: 34px; padding: 0 14px; border: 1px solid rgba(255, 255, 255, .08); border-radius: 999px;
  background: rgba(30, 30, 32, .96); color: #fff; font: inherit; font-size: 14px; font-weight: 700; cursor: pointer;
  box-shadow: 0 8px 22px rgba(0, 0, 0, .3);
}
.hud__peek-more:hover { background: rgba(44, 44, 47, .97); }

.hud--collapsed .hud__tab {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 44px;
  min-width: 44px;
  box-sizing: border-box;
  padding: 0 14px 0 12px;
  border-radius: 22px;
  color: var(--viso-accent);
  cursor: pointer;
}
.hud__tab:hover { background: var(--viso-glass-hover); }
.hud__tab:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 2px; }
.hud__tab-logo {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  object-fit: cover;
  flex: none;
  pointer-events: none;
}
/* Something half-written waits in the composer: a small pen-coloured dot on the tab. */
.hud__tab--draft::after { content: ''; position: absolute; top: 6px; right: 6px; width: 7px; height: 7px; border-radius: 50%; background: var(--viso-accent); box-shadow: 0 0 0 2px #fff; }
.hud__tab-count {
  font-size: 15px;
  font-weight: 700;
  color: var(--viso-text);
  font-variant-numeric: tabular-nums;
}

/* The product's mark and name, big, the way the design writes "Notes". */
.hud__heading {
  flex: none;
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  margin: 0 0 0 -8px;
  padding: 4px 10px 4px 8px;
  border: none;
  border-radius: 14px;
  background: transparent;
  font: inherit;
  font-size: 28px;
  line-height: 1.1;
  letter-spacing: -0.02em;
  white-space: nowrap;
  cursor: pointer;
  transition: background 140ms ease;
}
.hud__heading:hover { background: var(--viso-glass-hover); }
.hud__heading:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }
.hud__logo { width: 34px; height: 34px; border-radius: 10px; object-fit: cover; flex: none; pointer-events: none; }
.hud__brand { font-weight: 700; color: var(--viso-text); }

/* Where the user is: the page's icon, its name, how many notes are here —
   above the composer, so what is typed is visibly filed under it. */
.hud__place {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  max-width: 100%;
  margin: 0 0 10px;
  padding: 6px 12px 6px 6px;
  border-radius: 14px;
  border: 1.5px solid var(--viso-glass-edge);
  background: var(--viso-glass);
}
.hud__place-icon { width: 30px; height: 30px; border-radius: 8px; object-fit: contain; background: #fff; padding: 4px; box-sizing: border-box; flex: none; }
.hud__place-icon[hidden] { display: none; }
.hud__place-text { display: flex; flex-direction: column; min-width: 0; line-height: 1.2; }
.hud__place-name { font-size: 14px; font-weight: 600; color: var(--viso-text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.hud__place-count { font-size: 12.5px; color: var(--viso-text-2); }
.hud__name { font-weight: 600; }
.hud__count { font-weight: 500; }

.hud__comet-title { flex: none; margin: -12px 0 0 -4px; }

.hud__icon-btn,
.hud__gear,
.hud__view-btn {
  flex: none;
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 1.5px solid var(--viso-glass-edge);
  border-radius: 50%;
  background: var(--viso-glass);
  color: var(--viso-text-2);
  cursor: pointer;
}
/* The view, the gear and the minus sit at the header's right end. */
.hud__header .hud__view-btn { margin-left: auto; }
.hud__header .hud__view-btn + .hud__gear { margin-left: 0; }
.hud--collapsed .hud__gear { display: none; }

.hud__icon-btn:hover, .hud__gear:hover, .hud__view-btn:hover { background: var(--viso-glass-hover); color: var(--viso-text); }
.hud__icon-btn:focus-visible, .hud__gear:focus-visible, .hud__view-btn:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }
.hud__gear[aria-expanded="true"], .hud__view-btn[aria-expanded="true"], .hud__view-btn--on { background: var(--viso-accent-gradient); border-color: transparent; color: #fff; }

.hud__search {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 42px;
  box-sizing: border-box;
  padding: 0 16px;
  border: 1.5px solid var(--viso-glass-edge);
  border-radius: var(--viso-radius-pill);
  background: var(--viso-glass);
  color: var(--viso-text-2);
  cursor: text;
}

.hud__search:focus-within { border-color: var(--viso-accent); }
.hud__search-star { flex: none; }

.hud__search-input {
  flex: 1;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: none;
  outline: none;
  background: transparent;
  font: inherit;
  font-size: 15px;
  color: var(--viso-text);
  -webkit-appearance: none;
  appearance: none;
}

.hud__search-input::placeholder { color: var(--viso-text-2); }
.hud__search-input::-webkit-search-cancel-button { -webkit-appearance: none; }

.hud__chips {
  display: flex;
  gap: 8px;
  margin: 12px 0 2px;
  /* One row that scrolls sideways once the groups outgrow it, not a stack. */
  flex-wrap: nowrap;
  overflow-x: auto;
  scrollbar-width: none;
  padding-bottom: 2px;
}
.hud__chips::-webkit-scrollbar { display: none; }
.hud__chip { flex: none; }
.hud__chips[hidden] { display: none; }

.hud__chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 32px;
  padding: 0 14px;
  border: 1.5px solid var(--viso-glass-edge);
  border-radius: var(--viso-radius-pill);
  background: var(--viso-glass);
  font: inherit;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--viso-text);
  cursor: pointer;
}

.hud__chip:hover { background: var(--viso-glass-hover); }
.hud__chip:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }
.hud__chip-count { font-weight: 500; color: var(--viso-text-2); font-variant-numeric: tabular-nums; }

.hud__chip--active,
.hud__chip--active:hover {
  background: var(--viso-accent-gradient);
  border-color: transparent;
  color: #fff;
  box-shadow: 0 6px 16px var(--viso-accent-glow);
}
.hud__chip--active .hud__chip-count { color: rgba(255, 255, 255, 0.8); }

/* ------------------------------------------------------------ composer ---- */

.hud__composer { position: relative; margin-top: 14px; }

/* The group menu, as a small popover over the folder button rather than a
   full-width block: the list is short, and the words below it stay in view. */
.hud__composer-menu {
  position: absolute;
  left: 60px;
  /* Just above the pill the folder sits in. */
  bottom: 72px;
  z-index: 5;
  width: 220px;
}
.hud__composer-menu:empty { display: none; }
.hud__composer-menu .hud__menu { margin: 0; }
.hud__composer-menu .hud__menu-item { min-height: 30px; padding: 3px 9px; font-size: 13.5px; }
.hud__composer-menu .hud__menu-list { max-height: 160px; }

/* One pill: the microphone, the field, Lưu. */
.hud__composer-actions {
  display: flex;
  align-items: flex-end;
  gap: 10px;
  padding: 8px;
  border: 1.5px solid var(--viso-glass-edge);
  border-radius: var(--viso-radius-pill);
  background: var(--viso-glass);
}

.hud__mic,
.hud__composer-actions .hud__icon-btn.hud__mic {
  width: 46px;
  height: 46px;
  margin: 0;
  border: none;
  background: var(--viso-tile);
  color: var(--viso-accent);
}
.hud__mic:hover { background: var(--viso-accent-soft); }

.hud__field {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 10px;
  min-height: 46px;
  box-sizing: border-box;
  padding: 4px 12px 4px 5px;
  border: 1.5px solid var(--viso-glass-edge);
  border-radius: 23px;
  background: var(--viso-field);
}
/* A kind was chosen: the chip and the @ keep the first line, the words get a full line of their own to grow on. */
.hud__field--kind .panel__input { flex-basis: 100%; order: 1; padding: 2px 6px 6px; }
.hud__field--kind .hud__at-btn { margin-left: auto; }
.hud__field:focus-within { border-color: var(--viso-accent); }

/* The calendar beside the folder, and the chip it leaves behind. */
.hud__when-btn { flex: none; display: grid; place-items: center; width: 36px; height: 36px; padding: 0; border: 1.5px solid var(--viso-glass-edge); border-radius: var(--viso-radius-pill); background: var(--viso-glass); color: var(--viso-accent); cursor: pointer; }
.hud__when-btn:hover { background: var(--viso-glass-hover); }
.hud__when-btn--set { background: var(--viso-accent-gradient); border-color: transparent; color: #fff; }
.hud__when-btn[hidden] { display: none; }
.hud__when-chip { display: inline-flex; align-items: center; gap: 5px; flex: none; height: 30px; padding: 0 8px 0 9px; border: 1.5px solid var(--viso-glass-edge); border-radius: var(--viso-radius-pill); background: #fff; font: inherit; font-size: 12.5px; font-weight: 600; color: var(--viso-text); cursor: pointer; white-space: nowrap; }
.hud__when-chip[hidden] { display: none; }
.hud__when-chip svg:last-child { color: var(--viso-text-2); }

/* The calendar itself: quick picks, a month, a clock. */
.hud__cal { width: 250px; padding: 10px; border: 1px solid var(--viso-glass-edge); border-radius: 16px; background: var(--viso-menu); box-shadow: var(--viso-menu-shadow); font-size: 13px; color: var(--viso-text); }
.hud__cal-quick { display: flex; gap: 6px; margin-bottom: 8px; }
.hud__cal-q { flex: 1; height: 28px; border: 1px solid var(--viso-glass-edge); border-radius: 999px; background: transparent; font: inherit; font-size: 12px; font-weight: 600; color: var(--viso-text); cursor: pointer; }
.hud__cal-q:hover { background: var(--viso-tile); }
.hud__cal-head { display: flex; align-items: center; justify-content: space-between; margin: 2px 0 6px; }
.hud__cal-title { font-weight: 700; }
.hud__cal-nav { display: grid; place-items: center; width: 26px; height: 26px; border: none; border-radius: 50%; background: transparent; color: var(--viso-text); cursor: pointer; }
.hud__cal-nav:hover { background: var(--viso-tile); }
.hud__cal-dows, .hud__cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; }
.hud__cal-dows span { text-align: center; font-size: 10.5px; font-weight: 700; letter-spacing: .04em; color: var(--viso-text-2); padding: 2px 0; }
.hud__cal-day { height: 28px; border: none; border-radius: 8px; background: transparent; font: inherit; font-size: 12.5px; color: var(--viso-text); cursor: pointer; }
.hud__cal-day:hover { background: var(--viso-tile); }
.hud__cal-day--past { color: var(--viso-text-3); }
.hud__cal-day--today { font-weight: 800; color: var(--viso-accent); }
.hud__cal-day--on { background: var(--viso-accent-gradient); color: #fff; font-weight: 700; }
.hud__cal-foot { display: flex; align-items: center; gap: 6px; margin-top: 8px; }
.hud__cal-clock { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; color: var(--viso-text-2); }
.hud__cal-time { height: 28px; padding: 0 4px; width: 92px; border: 1px solid var(--viso-glass-edge); border-radius: 8px; background: #fff; font: inherit; font-size: 12.5px; color: var(--viso-text); }
.hud__cal-clear { margin-left: auto; height: 28px; padding: 0 8px; border: none; border-radius: 999px; background: transparent; font: inherit; font-size: 12px; color: var(--viso-text-2); cursor: pointer; white-space: nowrap; }
.hud__cal-clear:hover { color: var(--viso-text); }
.hud__cal-done { height: 28px; padding: 0 12px; font-size: 12.5px; }

/* "@" as a button, at the end of the field: the picker without typing it. */
.hud__at-btn {
  flex: none;
  width: 30px;
  height: 30px;
  padding: 0;
  border: none;
  border-radius: 50%;
  background: transparent;
  font: inherit;
  font-size: 17px;
  font-weight: 600;
  line-height: 1;
  color: var(--viso-accent);
  cursor: pointer;
}
.hud__at-btn:hover { background: var(--viso-tile); }
.hud__at-btn:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }

/* The kind "@" chose, beside the group. */
.hud__kind-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex: none;
  white-space: nowrap;
  height: 36px;
  padding: 0 10px 0 11px;
  border: none;
  border-radius: var(--viso-radius-pill);
  background: var(--viso-accent-gradient);
  color: #fff;
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 6px 14px var(--viso-accent-glow);
}
.hud__kind-chip[hidden] { display: none; }
.hud__kind-chip:hover { filter: brightness(1.06); }

/* "@": the three kinds, as a menu above the field. */
.hud__at-menu {
  margin: 0 0 8px;
  padding: 5px;
  border: 1px solid var(--viso-glass-edge);
  border-radius: 14px;
  background: var(--viso-menu);
  box-shadow: var(--viso-menu-shadow);
}
.hud__at-menu[hidden] { display: none; }
.hud__at-item {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 7px 10px;
  border: none;
  border-radius: 10px;
  background: transparent;
  font: inherit;
  color: var(--viso-text);
  text-align: left;
  cursor: pointer;
}
.hud__at-item:hover, .hud__at-item--on { background: var(--viso-tile); }
.hud__at-tile { flex: none; display: grid; place-items: center; width: 30px; height: 30px; border-radius: 9px; background: var(--viso-tile); color: var(--viso-accent); }
.hud__at-words { display: flex; flex-direction: column; line-height: 1.25; }
.hud__at-label { font-size: 14px; font-weight: 600; }
.hud__at-hint { font-size: 12.5px; color: var(--viso-text-2); }

/* Where new notes go. */
.hud__group-picker {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 36px;
  height: 36px;
  box-sizing: border-box;
  padding: 0;
  border: 1.5px solid var(--viso-glass-edge);
  border-radius: var(--viso-radius-pill);
  background: var(--viso-glass);
  font: inherit;
  font-size: 14px;
  font-weight: 500;
  color: var(--viso-text);
  cursor: pointer;
}
.hud__group-picker:hover { background: var(--viso-glass-hover); }
.hud__group-picker:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }
.hud__group-picker svg { flex: none; color: var(--viso-accent); }
.hud__group-picker--set { background: var(--viso-accent-gradient); border-color: transparent; color: #fff; box-shadow: 0 6px 14px var(--viso-accent-glow); }
.hud__group-picker--set svg { color: #fff; }
/* The name, for screen readers and tests; the button shows the folder alone. */
.hud__group-picker-label { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }

.hud__save {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 46px;
  padding: 0 20px 0 22px;
  font-size: 17px;
}
.hud__save svg { flex: none; }

.hud__menu {
  margin: 6px 0 8px;
  padding: 5px;
  border: 1px solid var(--viso-glass-edge);
  border-radius: 14px;
  background: var(--viso-menu);
  box-shadow: var(--viso-menu-shadow);
  cursor: default;
  white-space: normal;
}
.hud__menu-list { max-height: 180px; overflow-y: auto; }
/* The language, two flags side by side; the chosen one filled. */
.hud__lang { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; padding: 0 5px 6px; }
.hud__lang-btn { display: inline-flex; align-items: center; justify-content: center; gap: 7px; height: 36px; border: 1.5px solid var(--viso-glass-edge); border-radius: 12px; background: transparent; font: inherit; font-size: 13px; font-weight: 600; color: var(--viso-text); cursor: pointer; }
.hud__lang-btn:hover { background: var(--viso-tile); }
.hud__lang-btn[aria-checked="true"] { background: var(--viso-accent-gradient); border-color: transparent; color: #fff; box-shadow: 0 6px 14px var(--viso-accent-glow); }
.hud__lang-flag { display: inline-flex; line-height: 0; border-radius: 2px; box-shadow: 0 1px 1px rgba(0,0,0,.2); }

/* The gear's menu: how the HUD shows up on a page. Same cloth as the group menu. */
.hud__settings,
.hud__view-menu {
  margin: -4px 0 12px;
  padding: 5px;
  border: 1px solid var(--viso-glass-edge);
  border-radius: 14px;
  background: var(--viso-menu);
  box-shadow: var(--viso-menu-shadow);
}
.hud__settings[hidden], .hud__view-menu[hidden], .hud--collapsed .hud__settings { display: none; }
.hud__menu-title { margin: 4px 10px 6px; font-size: 12.5px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; color: var(--viso-text-2); }
.hud__setting {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  min-height: 32px;
  box-sizing: border-box;
  padding: 4px 10px;
  border: none;
  border-radius: 9px;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--viso-text);
  text-align: left;
  cursor: pointer;
}
.hud__setting:hover, .hud__setting:focus-visible { background: var(--viso-tile); outline: none; }
.hud__setting--mode { gap: 10px; padding: 5px 10px; }
.hud__setting--mode .hud__setting-name { flex: 1; min-width: 0; }
.hud__setting--mode[aria-checked="true"] .hud__at-tile { background: var(--viso-accent-gradient); color: #fff; }
.hud__setting[aria-checked="true"] { color: var(--viso-accent); font-weight: 600; }
.hud__setting-check { flex: none; display: grid; place-items: center; width: 16px; height: 16px; }
.hud__setting-hint { margin: 6px 10px 12px; font-size: 12.5px; line-height: 1.4; color: var(--viso-text-3); }
.hud--collapsed .hud__view-btn, .hud--collapsed .hud__view-menu { display: none; }

/* A section's heading, across both columns of the grid. */
.hud__section {
  grid-column: 1 / -1;
  margin: 6px 0 -4px 4px;
  font-size: 12.5px;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--viso-text-2);
}
.hud__menu-item {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  min-height: 32px;
  box-sizing: border-box;
  padding: 4px 10px;
  border: none;
  border-radius: 9px;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--viso-text);
  text-align: left;
  cursor: pointer;
}
.hud__menu-item:hover, .hud__menu-item:focus-visible { background: var(--viso-tile); outline: none; }
.hud__menu-item[aria-checked="true"] { color: var(--viso-accent); font-weight: 600; }
.hud__menu-check { flex: none; display: grid; place-items: center; width: 16px; height: 16px; }
.hud__menu-name { flex: 1; min-width: 0; overflow-wrap: anywhere; }
.hud__menu-count { flex: none; color: var(--viso-text-3); font-variant-numeric: tabular-nums; }
.hud__menu-empty { margin: 4px 8px; font-size: 13px; color: var(--viso-text-3); }
.hud__menu-add {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  min-height: 32px;
  margin-top: 4px;
  padding: 4px 10px;
  border: none;
  border-top: 1px solid rgba(47, 111, 232, 0.15);
  border-radius: 0 0 9px 9px;
  background: transparent;
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  color: var(--viso-accent);
  text-align: left;
  cursor: pointer;
}
.hud__menu-add:hover { background: var(--viso-tile); }
.hud__menu-add[hidden] { display: none; }
.hud__menu-create { display: flex; gap: 4px; margin-top: 4px; padding: 6px 4px 2px; border-top: 1px solid rgba(47, 111, 232, 0.15); }
.hud__menu-create[hidden] { display: none; }
.hud__action--group { color: var(--viso-accent); }
.hud__menu-input {
  flex: 1;
  min-width: 0;
  height: 32px;
  box-sizing: border-box;
  padding: 0 10px;
  border: 1px dashed rgba(47, 111, 232, 0.4);
  border-radius: 9px;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--viso-text);
}
.hud__menu-input:focus-visible { outline: none; border-style: solid; border-color: var(--viso-accent); }
.hud__menu-submit { flex: none; height: 32px; padding: 0 12px; font-size: 13px; }
.hud__menu-error { margin: 4px 8px 2px; font-size: 12px; color: var(--viso-danger); }
.hud__menu-error[hidden] { display: none; }

/* The words, inside the field: one line that grows a little when it has to. */
.panel__input {
  flex: 1 1 110px;
  min-width: 110px;
  box-sizing: border-box;
  width: 100%;
  max-height: 7em;
  overflow-y: auto;
  font: inherit;
  font-size: 15px;
  font-weight: 400;
  line-height: 1.4;
  padding: 0;
  margin: 0;
  border: none;
  background: transparent;
  color: var(--viso-text);
  resize: none;
  outline: none;
  field-sizing: content;
}
.panel__input::placeholder { color: var(--viso-text-2); }

.btn:disabled { opacity: 0.55; cursor: default; box-shadow: none; }

/* --------------------------------------------------------- coaching ---- */

/* Tinted, so a one-off explanation is not mistaken for a memory that surfaced. */
.coach {
  border-color: rgba(10, 132, 255, 0.3);
  background: linear-gradient(180deg, rgba(10, 132, 255, 0.07) 0%, var(--viso-panel-fill) 60%);
}

/* --------------------------------------------------------------- notes ---- */

.hud__notes[hidden] { display: none; }

.hud__summary { margin: 10px 2px 2px; font-size: 12px; color: var(--viso-text-3); }
.hud__summary[hidden] { display: none; }

/* Two columns of cards. Capped so a long history cannot push the composer off
   the screen; max-content rows, because auto rows collapse once the list is
   long enough to scroll. */
.hud__list {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  grid-auto-rows: max-content;
  gap: 12px;
  max-height: 380px;
  overflow-y: auto;
  overscroll-behavior: contain;
  margin: 12px 0 0;
  padding: 2px 4px 4px 0;
  scrollbar-width: thin;
  scrollbar-color: var(--viso-glass-edge) transparent;
}

.hud__row {
  position: relative;
  z-index: 0;
  box-sizing: border-box;
  padding: 14px 16px 16px;
  border-radius: var(--viso-radius-card);
  border: 1.5px solid var(--viso-glass-edge);
  background: var(--viso-glass);
  /* Not clipped: the ··· menu hangs below the card's edge. */
  transition: background 140ms ease, transform 140ms ease;
}

.hud__row:hover,
.hud__row:focus-within { background: var(--viso-glass-hover); }
.hud__row--elsewhere:hover { transform: translateY(-1px); }

/* The note the user followed a link to reach — held while the panel is open,
   with a ring as well as a tint so it does not rely on colour alone. */
.hud__row--highlight,
.hud__row--highlight:hover {
  border-color: var(--viso-accent);
  box-shadow: 0 0 0 3px var(--viso-accent-soft);
}

.hud__head {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  margin-bottom: 10px;
}

/* What kind of note, before a word is read. */
.hud__tile {
  flex: none;
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border-radius: 11px;
  background: var(--viso-tile);
  color: var(--viso-accent);
}

.hud__tile-wrap { position: relative; flex: none; display: inline-grid; }
.hud__tile-badge { position: absolute; right: -5px; bottom: -5px; width: 16px; height: 16px; border-radius: 5px; background: #fff; box-shadow: 0 0 0 2px #fff, 0 1px 3px rgba(20, 40, 80, .25); object-fit: cover; }

.hud__tile--reminder { color: #b86e00; }
.hud__tile--task { color: #1f8a3a; }

/* Clicking a note opens it to read here, or goes to where it was written. */
.hud__body { min-width: 0; cursor: pointer; }
.hud__row--editing .hud__body { cursor: default; }

/*
 * Two lines, then faded — never cut with an ellipsis. Line breaks the user
 * typed are kept, and a long URL wraps instead of widening the HUD.
 */
/* A task's tile is a checkbox: black when ticked, the card struck through and faded. */
.hud__check { cursor: pointer; width: 26px; height: 26px; margin: 5px; border-radius: 50%; border: 2px solid var(--viso-text-2); background: transparent; color: transparent; transition: background 120ms, color 120ms, border-color 120ms; }
.hud__check:hover { border-color: var(--viso-text); }
.hud__row--done .hud__check { background: #16181f; border-color: #16181f; color: #fff; }
.hud__row--done .hud__meta, .hud__row--done .hud__due { opacity: .6; }
.hud__row--done .hud__due--past .hud__due-btn { color: var(--viso-text-2); }

/* The time under a reminder or to-do: white ahead of time, red once it is behind. */
.hud__due { margin: 6px 0 0; font-size: 12.5px; }
.hud__due-btn { display: inline-flex; align-items: center; gap: 5px; padding: 3px 8px 3px 6px; border: none; border-radius: 999px; background: rgba(255,255,255,.55); font: inherit; font-size: 12.5px; font-weight: 600; color: var(--viso-text); cursor: pointer; }
.hud__due-btn:hover { background: #fff; }
.hud__due-btn--unset { color: var(--viso-text-2); font-weight: 500; background: transparent; border: 1px dashed var(--viso-glass-edge); }
.hud__due--past .hud__due-btn { color: #d93025; }
.hud__due { position: relative; }
.hud__cal--due { position: absolute; left: 0; top: calc(100% + 6px); z-index: 3; }
.hud__cal--due-right { left: auto; right: 0; }
.hud__list--cal-room { padding-bottom: 340px; }
.hud__due-err { display: block; margin-top: 4px; font-size: 11.5px; color: #d93025; }

.hud__title {
  margin: 0;
  padding-right: 34px;
  font-size: 17px;
  font-weight: 500;
  line-height: 1.35;
  letter-spacing: -0.01em;
  color: var(--viso-text);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  max-height: calc(1.35em * 2);
  overflow: hidden;
}
.hud__row--overflow:not(.hud__row--expanded) .hud__title {
  -webkit-mask-image: linear-gradient(to bottom, #000 55%, transparent);
  mask-image: linear-gradient(to bottom, #000 55%, transparent);
}
.hud__row--expanded .hud__title { max-height: none; }
.hud__row--done .hud__body .hud__title { text-decoration: line-through; opacity: .55; }

/* The card's first line: what kind, then when; the group on a line under it. */
.hud__meta {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  min-width: 0;
  margin: 0;
  font-size: 13.5px;
  line-height: 1.2;
  color: var(--viso-text-2);
  white-space: nowrap;
  overflow: hidden;
}
.hud__meta-line { display: inline-flex; align-items: baseline; gap: 5px; max-width: 100%; overflow: hidden; }

.hud__kind { flex: none; font-weight: 600; color: var(--viso-text); }
.hud__sep, .hud__time { flex: none; }
.hud__time { overflow: hidden; text-overflow: ellipsis; }

.hud__group-slot { display: inline-flex; align-items: center; gap: 5px; min-width: 0; max-width: 100%; }
.hud__group-slot .hud__sep { display: none; }
.hud__group-slot--empty { opacity: 0; transition: opacity 120ms ease; }
.hud__row:hover .hud__group-slot--empty,
.hud__row:focus-within .hud__group-slot--empty { opacity: 1; }
.hud__group {
  min-width: 0;
  padding: 0 2px;
  border: none;
  border-radius: 4px;
  background: transparent;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
  line-height: 1.2;
  color: var(--viso-accent);
  text-align: left;
  white-space: normal;
  overflow-wrap: anywhere;
}
button.hud__group { cursor: pointer; }
button.hud__group:hover { text-decoration: underline; }
button.hud__group:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 1px; }
.hud__group:not(.hud__group--empty)::before { content: '# '; opacity: 0.6; }
.hud__group--empty { font-weight: 500; color: var(--viso-text-3); }
.hud__chip svg { flex: none; }

.hud__comet { position: absolute; right: 14px; bottom: 10px; pointer-events: none; }

.hud__more-toggle {
  display: inline-block;
  position: relative;
  margin: 6px 0 0;
  padding: 2px 0;
  border: none;
  background: transparent;
  font: inherit;
  font-size: 13px;
  font-weight: 600;
  color: var(--viso-accent);
  cursor: pointer;
}
.hud__more-toggle[hidden] { display: none; }
.hud__more-toggle:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: 2px; border-radius: 4px; }

/* What an opened note adds: the quoted passage in full, and the page it is about. */
.hud__details { margin: 8px 0 0; }
.hud__details[hidden] { display: none; }
.hud__quote {
  margin: 0 0 6px;
  padding: 2px 0 2px 9px;
  border-left: 2px solid var(--viso-accent);
  font-size: 13.5px;
  line-height: 1.45;
  font-style: italic;
  color: var(--viso-text-2);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.hud__stamp { margin: 0; font-size: 12.5px; color: var(--viso-text-2); }

/* The ··· and what it opens. */
.hud__actions { position: relative; flex: none; }
.hud__row--editing .hud__actions { visibility: hidden; }

.hud__menu-btn {
  display: grid;
  place-items: center;
  width: 32px;
  height: 28px;
  padding: 0;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: var(--viso-text);
  cursor: pointer;
}
.hud__menu-btn svg { stroke-width: 3; }
.hud__menu-btn:hover, .hud__menu-btn[aria-expanded="true"] { background: var(--viso-tile); }
.hud__menu-btn:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: -1px; }

.hud__row-menu {
  position: absolute;
  top: calc(100% + 4px);
  right: 0;
  z-index: 3;
  display: flex;
  flex-direction: column;
  min-width: 120px;
  padding: 5px;
  border: 1px solid var(--viso-glass-edge);
  border-radius: 14px;
  background: var(--viso-menu);
  box-shadow: var(--viso-menu-shadow);
}
.hud__row-menu[hidden] { display: none; }
/* The card whose menu is open sits above its neighbours, whichever way the menu hangs. */
.hud__row--menu-open { z-index: 20; }
/* Opens upward when the card sits near the bottom of the list, which clips. */
.hud__row-menu--up { top: auto; bottom: calc(100% + 4px); }
/* And when the list is too short for either way: room is made below. */
.hud__list--menu-room { padding-bottom: 100px; }

.hud__action {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 11px;
  border: none;
  border-radius: 9px;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--viso-text);
  text-align: left;
  white-space: nowrap;
  cursor: pointer;
}

.hud__action:hover { background: var(--viso-tile); }
.hud__action--danger { color: var(--viso-danger); }
.hud__action:focus-visible { outline: 2px solid var(--viso-accent); outline-offset: -1px; }

.hud__editor {
  display: block;
  width: 100%;
  box-sizing: border-box;
  font: inherit;
  font-size: 15px;
  line-height: 1.4;
  color: var(--viso-text);
  background: var(--viso-menu);
  border: 1.5px solid var(--viso-accent);
  border-radius: var(--viso-radius-control);
  padding: 7px 9px;
  resize: vertical;
  outline: none;
}

.hud__empty { grid-column: 1 / -1; margin: 0; padding: 20px 8px; text-align: center; font-size: 14.5px; line-height: 1.4; color: var(--viso-text-2); }

.hud__more {
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  padding: 0;
  margin: 6px 0 0;
  border: none;
  background: transparent;
  color: var(--viso-accent);
  cursor: pointer;
  text-align: left;
}

.hud__more[hidden] { display: none; }
.hud__more:hover { text-decoration: underline; }

.panel__hint { margin: 0 0 8px; font-size: 14px; line-height: 1.4; color: var(--viso-accent-to); }
.panel__hint[hidden] { display: none; }

.card__status {
  margin-top: 9px;
  font-size: 14px;
  color: var(--viso-text-3);
  font-variant-numeric: tabular-nums;
}
`;
//#endregion
//#region src/content/ui/ShadowHost.ts
/** Custom tag name — never a <div>, so page rules for `div` cannot reach it. */
var HOST_TAG = "viso-root";
/**
* Host element properties that must survive hostile page CSS. Applied as
* INLINE !important: in the cascade, important-inline outranks important-author,
* so a page's `* { display: none !important }` cannot hide ViSO.
*/
var HOST_LOCKED_STYLES = [
	["position", "fixed"],
	["top", "72px"],
	["right", `12px`],
	["bottom", "auto"],
	["left", "auto"],
	["width", "auto"],
	["height", "auto"],
	["margin", "0"],
	["padding", "0"],
	["z-index", "2147483647"],
	["display", "block"],
	["visibility", "visible"],
	["opacity", "1"],
	["transform", "none"],
	["filter", "none"],
	["clip-path", "none"],
	["pointer-events", "none"],
	["contain", "layout style"]
];
/**
* Elements earlier versions of ViSO put into pages, cleared on mount.
*
* `viso-slot` is the placeholder the toolbar dock used to insert. The dock is
* gone, but an open tab can still hold one from before the update.
*/
var STALE_SELECTOR = `${HOST_TAG}, viso-slot`;
var ShadowHost = class ShadowHost {
	root;
	/**
	* The one container every piece of ViSO UI lives in.
	*
	* Cards appended straight to the shadow root, beside this layer instead of
	* inside it, once rendered in Times — the font is declared on the layer and
	* nothing else inherited it.
	*/
	layer;
	host;
	survivalObserver = null;
	disposed = false;
	constructor(host, root, layer) {
		this.host = host;
		this.root = root;
		this.layer = layer;
	}
	/**
	* Creates the host element and its CLOSED shadow root (spec §3.2).
	*
	* Any ViSO element already in the document is removed first. The content
	* script guards against running twice in one extension lifetime, so anything
	* still here was left by a previous version — an extension reload or update
	* leaves its DOM in every open tab with nothing alive behind it.
	*/
	static mount() {
		const documentRoot = document.documentElement;
		if (documentRoot === null) return null;
		for (const stale of document.querySelectorAll(STALE_SELECTOR)) {
			log.debug("removing a ViSO element left by a previous instance");
			stale.remove();
		}
		const host = document.createElement(HOST_TAG);
		for (const [prop, value] of HOST_LOCKED_STYLES) host.style.setProperty(prop, value, "important");
		host.setAttribute("translate", "no");
		host.setAttribute("aria-hidden", "false");
		const root = host.attachShadow({ mode: "closed" });
		applyStyles(root);
		const layer = document.createElement("div");
		layer.className = "layer";
		layer.dataset["side"] = "right";
		layer.dataset["vside"] = "top";
		root.appendChild(layer);
		documentRoot.appendChild(host);
		const instance = new ShadowHost(host, root, layer);
		instance.watchForRemoval();
		return instance;
	}
	/**
	* Some app frameworks reconcile <html>'s children and drop nodes they did not
	* create. Re-attach instead of silently disappearing mid-session.
	*/
	watchForRemoval() {
		this.survivalObserver = new MutationObserver(() => {
			if (this.disposed || this.host.isConnected) return;
			log.debug("host was detached by the page, re-attaching");
			document.documentElement.appendChild(this.host);
		});
		this.survivalObserver.observe(document.documentElement, { childList: true });
	}
	/** Moves the HUD along the right edge. The edge itself never changes. */
	setTop(top) {
		this.set("top", `${Math.round(top)}px`);
		this.set("bottom", "auto");
		this.set("right", `12px`);
		this.set("left", "auto");
	}
	get rect() {
		return this.host.getBoundingClientRect();
	}
	dispose() {
		this.disposed = true;
		this.survivalObserver?.disconnect();
		this.survivalObserver = null;
		this.host.remove();
	}
	set(prop, value) {
		this.host.style.setProperty(prop, value, "important");
	}
};
/**
* Prefers constructable stylesheets (parsed once, shared) and falls back to a
* <style> node on engines that lack them.
*/
function applyStyles(root) {
	try {
		const sheet = new CSSStyleSheet();
		sheet.replaceSync(SHADOW_STYLES);
		root.adoptedStyleSheets = [sheet];
	} catch {
		const style = document.createElement("style");
		style.textContent = SHADOW_STYLES;
		root.appendChild(style);
	}
}
//#endregion
//#region src/content/observer/ContextObserver.ts
var DEFAULTS = {
	debounceMs: 500,
	minSameUrlIntervalMs: 5e3,
	domMutationThreshold: 120
};
/**
* Watches for meaningful context changes (spec §2 "Context Observer", §7.3).
*
* Event-driven only — there is no polling timer anywhere in this class, per the
* spec's explicit "KHÔNG chạy liên tục / continuous polling".
*
* SPA route changes are the awkward case: a content script runs in an isolated
* world, so patching `history.pushState` here would never see the page's own
* calls. What actually works everywhere is watching the DOM churn that a route
* change inevitably causes and re-reading `location.href` — plus `popstate` and
* `hashchange` for the cases the browser does announce.
*
* The MutationObserver callback is deliberately O(1): two string reads and a
* counter bump. Anything heavier would tax every keystroke on Gmail or Slack.
*/
var ContextObserver = class {
	options;
	mutationObserver = null;
	debounceTimer = null;
	pendingReason = null;
	lastUrl = "";
	lastTitle = "";
	lastEmittedSignature = "";
	lastEmittedAt = 0;
	mutationBudget = 0;
	started = false;
	onPopState = () => this.schedule("url");
	onHashChange = () => this.schedule("url");
	onVisibility = () => {
		if (document.visibilityState === "visible") this.schedule("visible");
	};
	onPageShow = (event) => {
		if (event.persisted) this.schedule("visible");
	};
	constructor(options) {
		this.options = {
			...DEFAULTS,
			...options
		};
	}
	start() {
		if (this.started) return;
		this.started = true;
		this.lastUrl = location.href;
		this.lastTitle = document.title;
		window.addEventListener("popstate", this.onPopState);
		window.addEventListener("hashchange", this.onHashChange);
		window.addEventListener("pageshow", this.onPageShow);
		document.addEventListener("visibilitychange", this.onVisibility);
		this.mutationObserver = new MutationObserver((records) => this.onMutations(records));
		this.mutationObserver.observe(document.documentElement, {
			childList: true,
			subtree: true,
			characterData: false,
			attributes: false
		});
		this.schedule("initial");
	}
	stop() {
		if (!this.started) return;
		this.started = false;
		window.removeEventListener("popstate", this.onPopState);
		window.removeEventListener("hashchange", this.onHashChange);
		window.removeEventListener("pageshow", this.onPageShow);
		document.removeEventListener("visibilitychange", this.onVisibility);
		this.mutationObserver?.disconnect();
		this.mutationObserver = null;
		if (this.debounceTimer !== null) {
			clearTimeout(this.debounceTimer);
			this.debounceTimer = null;
		}
		this.pendingReason = null;
	}
	/** Hot path — keep it to cheap reads. */
	onMutations(records) {
		if (location.href !== this.lastUrl) {
			this.schedule("url");
			return;
		}
		if (document.title !== this.lastTitle) {
			this.schedule("title");
			return;
		}
		let relevant = 0;
		for (const record of records) if (!isVisoNode(record.target)) relevant++;
		if (relevant === 0) return;
		this.mutationBudget += relevant;
		if (this.mutationBudget >= this.options.domMutationThreshold) this.schedule("dom");
	}
	schedule(reason) {
		if (this.pendingReason === null || rank(reason) > rank(this.pendingReason)) this.pendingReason = reason;
		if (this.debounceTimer !== null) clearTimeout(this.debounceTimer);
		this.debounceTimer = setTimeout(() => this.flush(), this.options.debounceMs);
	}
	flush() {
		this.debounceTimer = null;
		const reason = this.pendingReason ?? "dom";
		this.pendingReason = null;
		this.mutationBudget = 0;
		const url = location.href;
		const title = document.title;
		const signature = fnv1a(`${url}\n${title}`);
		const urlChanged = url !== this.lastUrl;
		const titleChanged = title !== this.lastTitle;
		this.lastUrl = url;
		this.lastTitle = title;
		if (!urlChanged && !titleChanged && reason !== "initial") {
			const sinceLast = Date.now() - this.lastEmittedAt;
			if (signature === this.lastEmittedSignature && sinceLast < this.options.minSameUrlIntervalMs) {
				log.debug("context change suppressed (churn floor)", { sinceLast });
				return;
			}
		}
		this.lastEmittedSignature = signature;
		this.lastEmittedAt = Date.now();
		log.debug("context change", {
			reason,
			url,
			signature
		});
		this.options.onChange({
			url,
			title,
			reason,
			signature
		});
	}
};
/** Ordering for reason precedence when several fire inside one debounce window. */
function rank(reason) {
	switch (reason) {
		case "initial": return 4;
		case "url": return 3;
		case "title": return 2;
		case "visible": return 1;
		case "dom": return 0;
	}
}
function isVisoNode(node) {
	return (node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement)?.closest("viso-root") != null;
}
//#endregion
//#region src/content/ui/hudPosition.ts
var EDGE_MARGIN = 8;
/** The header has to stay on screen, or there is nothing left to grab. */
var HEADER_ALLOWANCE = 48;
var STORAGE_KEY = "viso:hud-top";
/** A press that moves less than this is a click, not a drag. */
var CLICK_SLOP = 4;
function clampTop(top, viewportHeight) {
	const max = Math.max(EDGE_MARGIN, viewportHeight - HEADER_ALLOWANCE - EDGE_MARGIN);
	return Math.round(Math.min(Math.max(top, EDGE_MARGIN), max));
}
/**
* Stored as a fraction of the window height, in chrome.storage so it follows the
* user to every site: a position in pixels lands off-screen in a shorter window.
*/
async function loadTopRatio() {
	try {
		const value = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
		return typeof value === "number" && Number.isFinite(value) ? Math.min(Math.max(value, 0), 1) : null;
	} catch {
		return null;
	}
}
function saveTopRatio(ratio) {
	chrome.storage.local.set({ [STORAGE_KEY]: Math.min(Math.max(ratio, 0), 1) }).catch((error) => {
		log.warn("could not remember the HUD position", error);
	});
}
/**
* Drags the HUD up and down by its header.
*
* Presses that start on a control in the header are left alone, and the click
* that ends a real drag is swallowed — otherwise letting go of a collapsed HUD
* would also expand it.
*/
function makeVerticalDrag(options) {
	const { handle } = options;
	let pointerId = null;
	let startY = 0;
	let startTop = 0;
	let dragging = false;
	let suppressClick = false;
	const onDown = (event) => {
		if (event.button !== 0) return;
		if (event.target?.closest("button, input, textarea") != null) return;
		pointerId = event.pointerId;
		startY = event.clientY;
		startTop = options.currentTop();
		dragging = false;
	};
	const onMove = (event) => {
		if (pointerId !== event.pointerId) return;
		const dy = event.clientY - startY;
		if (!dragging) {
			if (Math.abs(dy) < CLICK_SLOP) return;
			dragging = true;
			handle.setPointerCapture?.(event.pointerId);
		}
		event.preventDefault();
		options.onMove(startTop + dy);
	};
	const onUp = (event) => {
		if (pointerId !== event.pointerId) return;
		pointerId = null;
		if (handle.hasPointerCapture?.(event.pointerId) === true) handle.releasePointerCapture(event.pointerId);
		if (!dragging) return;
		dragging = false;
		suppressClick = true;
		options.onDropped(options.currentTop());
	};
	const onClick = (event) => {
		if (!suppressClick) return;
		suppressClick = false;
		event.stopPropagation();
		event.preventDefault();
	};
	handle.addEventListener("pointerdown", onDown);
	handle.addEventListener("pointermove", onMove);
	handle.addEventListener("pointerup", onUp);
	handle.addEventListener("pointercancel", onUp);
	handle.addEventListener("click", onClick, true);
	return () => {
		handle.removeEventListener("pointerdown", onDown);
		handle.removeEventListener("pointermove", onMove);
		handle.removeEventListener("pointerup", onUp);
		handle.removeEventListener("pointercancel", onUp);
		handle.removeEventListener("click", onClick, true);
	};
}
//#endregion
//#region src/content/selection.ts
/**
* The text the user had selected when they wrote a note.
*
* A note taken on a document is nearly always about a passage, and the passage
* is the part a note cannot reconstruct for itself. Capturing it turns "which
* part of these forty pages" into something the panel can show back.
*
* ## Why not a link into the document
*
* Google Docs renders its text to a canvas, so there is no element to anchor to
* and no fragment that addresses a position — the `#heading=` anchors it does
* accept only exist for headings, and creating a bookmark needs the Docs API
* and an OAuth grant ViSO does not ask for. Chrome's own text fragments
* (`#:~:text=`) address rendered DOM text, which a canvas document has none of.
*
* So the quote is the anchor: shown on the note, and searched for on return by
* whatever the document itself offers. Honest, and it works on every platform
* rather than one.
*/
/** Longer than this and it is the whole page, not a passage. */
var MAX_SELECTION = 400;
/** Shorter than this is a stray click, not a deliberate selection. */
var MIN_SELECTION = 3;
/**
* Reads the current selection, ignoring anything inside ViSO's own UI.
*
* Selecting text in the panel — a draft being edited, a note being re-read —
* would otherwise be captured as the passage the note is about.
*/
function capturedSelection() {
	let selection;
	try {
		selection = window.getSelection();
	} catch {
		return null;
	}
	if (selection === null || selection.isCollapsed) return null;
	const anchor = selection.anchorNode;
	if ((anchor?.nodeType === Node.ELEMENT_NODE ? anchor : anchor?.parentElement)?.closest("viso-root") != null) return null;
	const text = selection.toString().replace(/\s+/gu, " ").trim();
	if (text.length < MIN_SELECTION) return null;
	return text.length > MAX_SELECTION ? `${text.slice(0, MAX_SELECTION)}…` : text;
}
/**
* Keeps the last real selection, because opening the panel destroys it.
*
* Clicking the dot moves focus, and on most pages that collapses the selection
* before any handler can read it — so it is read as it is made, and the last
* one is used when the note is finally saved.
*/
var SelectionKeeper = class {
	last = null;
	onChange = () => {
		const text = capturedSelection();
		if (text !== null) this.last = text;
	};
	start() {
		document.addEventListener("selectionchange", this.onChange, true);
	}
	stop() {
		document.removeEventListener("selectionchange", this.onChange, true);
	}
	/** Reads and clears, so one passage is not attached to two notes. */
	take() {
		const text = this.last;
		this.last = null;
		return text;
	}
	/** Dropped on navigation: a passage belongs to the page it was read on. */
	clear() {
		this.last = null;
	}
};
//#endregion
//#region ../../viso-ext/node_modules/@mozilla/readability/Readability.js
var require_Readability = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Public constructor.
	* @param {HTMLDocument} doc     The document to parse.
	* @param {Object}       options The options object.
	*/
	function Readability(doc, options) {
		if (options && options.documentElement) {
			doc = options;
			options = arguments[2];
		} else if (!doc || !doc.documentElement) throw new Error("First argument to Readability constructor should be a document object.");
		options = options || {};
		this._doc = doc;
		this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
		this._articleTitle = null;
		this._articleByline = null;
		this._articleDir = null;
		this._articleSiteName = null;
		this._attempts = [];
		this._metadata = {};
		this._debug = !!options.debug;
		this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
		this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
		this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
		this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(options.classesToPreserve || []);
		this._keepClasses = !!options.keepClasses;
		this._serializer = options.serializer || function(el) {
			return el.innerHTML;
		};
		this._disableJSONLD = !!options.disableJSONLD;
		this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
		this._linkDensityModifier = options.linkDensityModifier || 0;
		this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
		if (this._debug) {
			let logNode = function(node) {
				if (node.nodeType == node.TEXT_NODE) return `${node.nodeName} ("${node.textContent}")`;
				let attrPairs = Array.from(node.attributes || [], function(attr) {
					return `${attr.name}="${attr.value}"`;
				}).join(" ");
				return `<${node.localName} ${attrPairs}>`;
			};
			this.log = function() {
				if (typeof console !== "undefined") {
					let args = Array.from(arguments, (arg) => {
						if (arg && arg.nodeType == this.ELEMENT_NODE) return logNode(arg);
						return arg;
					});
					args.unshift("Reader: (Readability)");
					console.log(...args);
				} else if (typeof dump !== "undefined") {
					var msg = Array.prototype.map.call(arguments, function(x) {
						return x && x.nodeName ? logNode(x) : x;
					}).join(" ");
					dump("Reader: (Readability) " + msg + "\n");
				}
			};
		} else this.log = function() {};
	}
	Readability.prototype = {
		FLAG_STRIP_UNLIKELYS: 1,
		FLAG_WEIGHT_CLASSES: 2,
		FLAG_CLEAN_CONDITIONALLY: 4,
		ELEMENT_NODE: 1,
		TEXT_NODE: 3,
		DEFAULT_MAX_ELEMS_TO_PARSE: 0,
		DEFAULT_N_TOP_CANDIDATES: 5,
		DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
		DEFAULT_CHAR_THRESHOLD: 500,
		REGEXPS: {
			unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
			okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
			positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
			negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
			extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
			byline: /byline|author|dateline|writtenby|p-author/i,
			replaceFonts: /<(\/?)font[^>]*>/gi,
			normalize: /\s{2,}/g,
			videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
			shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
			nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
			prevLink: /(prev|earl|old|new|<|«)/i,
			tokenize: /\W+/g,
			whitespace: /^\s*$/,
			hasContent: /\S$/,
			hashUrl: /^#.+/,
			srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
			b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
			commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
			jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
			adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
			loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
		},
		UNLIKELY_ROLES: [
			"menu",
			"menubar",
			"complementary",
			"navigation",
			"alert",
			"alertdialog",
			"dialog"
		],
		DIV_TO_P_ELEMS: /* @__PURE__ */ new Set([
			"BLOCKQUOTE",
			"DL",
			"DIV",
			"IMG",
			"OL",
			"P",
			"PRE",
			"TABLE",
			"UL"
		]),
		ALTER_TO_DIV_EXCEPTIONS: [
			"DIV",
			"ARTICLE",
			"SECTION",
			"P",
			"OL",
			"UL"
		],
		PRESENTATIONAL_ATTRIBUTES: [
			"align",
			"background",
			"bgcolor",
			"border",
			"cellpadding",
			"cellspacing",
			"frame",
			"hspace",
			"rules",
			"style",
			"valign",
			"vspace"
		],
		DEPRECATED_SIZE_ATTRIBUTE_ELEMS: [
			"TABLE",
			"TH",
			"TD",
			"HR",
			"PRE"
		],
		PHRASING_ELEMS: [
			"ABBR",
			"AUDIO",
			"B",
			"BDO",
			"BR",
			"BUTTON",
			"CITE",
			"CODE",
			"DATA",
			"DATALIST",
			"DFN",
			"EM",
			"EMBED",
			"I",
			"IMG",
			"INPUT",
			"KBD",
			"LABEL",
			"MARK",
			"MATH",
			"METER",
			"NOSCRIPT",
			"OBJECT",
			"OUTPUT",
			"PROGRESS",
			"Q",
			"RUBY",
			"SAMP",
			"SCRIPT",
			"SELECT",
			"SMALL",
			"SPAN",
			"STRONG",
			"SUB",
			"SUP",
			"TEXTAREA",
			"TIME",
			"VAR",
			"WBR"
		],
		CLASSES_TO_PRESERVE: ["page"],
		HTML_ESCAPE_MAP: {
			lt: "<",
			gt: ">",
			amp: "&",
			quot: "\"",
			apos: "'"
		},
		/**
		* Run any post-process modifications to article content as necessary.
		*
		* @param Element
		* @return void
		**/
		_postProcessContent(articleContent) {
			this._fixRelativeUris(articleContent);
			this._simplifyNestedElements(articleContent);
			if (!this._keepClasses) this._cleanClasses(articleContent);
		},
		/**
		* Iterates over a NodeList, calls `filterFn` for each node and removes node
		* if function returned `true`.
		*
		* If function is not passed, removes all the nodes in node list.
		*
		* @param NodeList nodeList The nodes to operate on
		* @param Function filterFn the function to use as a filter
		* @return void
		*/
		_removeNodes(nodeList, filterFn) {
			if (this._docJSDOMParser && nodeList._isLiveNodeList) throw new Error("Do not pass live node lists to _removeNodes");
			for (var i = nodeList.length - 1; i >= 0; i--) {
				var node = nodeList[i];
				var parentNode = node.parentNode;
				if (parentNode) {
					if (!filterFn || filterFn.call(this, node, i, nodeList)) parentNode.removeChild(node);
				}
			}
		},
		/**
		* Iterates over a NodeList, and calls _setNodeTag for each node.
		*
		* @param NodeList nodeList The nodes to operate on
		* @param String newTagName the new tag name to use
		* @return void
		*/
		_replaceNodeTags(nodeList, newTagName) {
			if (this._docJSDOMParser && nodeList._isLiveNodeList) throw new Error("Do not pass live node lists to _replaceNodeTags");
			for (const node of nodeList) this._setNodeTag(node, newTagName);
		},
		/**
		* Iterate over a NodeList, which doesn't natively fully implement the Array
		* interface.
		*
		* For convenience, the current object context is applied to the provided
		* iterate function.
		*
		* @param  NodeList nodeList The NodeList.
		* @param  Function fn       The iterate function.
		* @return void
		*/
		_forEachNode(nodeList, fn) {
			Array.prototype.forEach.call(nodeList, fn, this);
		},
		/**
		* Iterate over a NodeList, and return the first node that passes
		* the supplied test function
		*
		* For convenience, the current object context is applied to the provided
		* test function.
		*
		* @param  NodeList nodeList The NodeList.
		* @param  Function fn       The test function.
		* @return void
		*/
		_findNode(nodeList, fn) {
			return Array.prototype.find.call(nodeList, fn, this);
		},
		/**
		* Iterate over a NodeList, return true if any of the provided iterate
		* function calls returns true, false otherwise.
		*
		* For convenience, the current object context is applied to the
		* provided iterate function.
		*
		* @param  NodeList nodeList The NodeList.
		* @param  Function fn       The iterate function.
		* @return Boolean
		*/
		_someNode(nodeList, fn) {
			return Array.prototype.some.call(nodeList, fn, this);
		},
		/**
		* Iterate over a NodeList, return true if all of the provided iterate
		* function calls return true, false otherwise.
		*
		* For convenience, the current object context is applied to the
		* provided iterate function.
		*
		* @param  NodeList nodeList The NodeList.
		* @param  Function fn       The iterate function.
		* @return Boolean
		*/
		_everyNode(nodeList, fn) {
			return Array.prototype.every.call(nodeList, fn, this);
		},
		_getAllNodesWithTag(node, tagNames) {
			if (node.querySelectorAll) return node.querySelectorAll(tagNames.join(","));
			return [].concat.apply([], tagNames.map(function(tag) {
				var collection = node.getElementsByTagName(tag);
				return Array.isArray(collection) ? collection : Array.from(collection);
			}));
		},
		/**
		* Removes the class="" attribute from every element in the given
		* subtree, except those that match CLASSES_TO_PRESERVE and
		* the classesToPreserve array from the options object.
		*
		* @param Element
		* @return void
		*/
		_cleanClasses(node) {
			var classesToPreserve = this._classesToPreserve;
			var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
			if (className) node.setAttribute("class", className);
			else node.removeAttribute("class");
			for (node = node.firstElementChild; node; node = node.nextElementSibling) this._cleanClasses(node);
		},
		/**
		* Tests whether a string is a URL or not.
		*
		* @param {string} str The string to test
		* @return {boolean} true if str is a URL, false if not
		*/
		_isUrl(str) {
			try {
				new URL(str);
				return true;
			} catch {
				return false;
			}
		},
		/**
		* Converts each <a> and <img> uri in the given element to an absolute URI,
		* ignoring #ref URIs.
		*
		* @param Element
		* @return void
		*/
		_fixRelativeUris(articleContent) {
			var baseURI = this._doc.baseURI;
			var documentURI = this._doc.documentURI;
			function toAbsoluteURI(uri) {
				if (baseURI == documentURI && uri.charAt(0) == "#") return uri;
				try {
					return new URL(uri, baseURI).href;
				} catch (ex) {}
				return uri;
			}
			var links = this._getAllNodesWithTag(articleContent, ["a"]);
			this._forEachNode(links, function(link) {
				var href = link.getAttribute("href");
				if (href) {
					if (href.indexOf("javascript:") === 0) {
						if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
							var text = this._doc.createTextNode(link.textContent);
							link.parentNode.replaceChild(text, link);
						} else {
							var container = this._doc.createElement("span");
							while (link.firstChild) container.appendChild(link.firstChild);
							link.parentNode.replaceChild(container, link);
						}
					} else link.setAttribute("href", toAbsoluteURI(href));
				}
			});
			var medias = this._getAllNodesWithTag(articleContent, [
				"img",
				"picture",
				"figure",
				"video",
				"audio",
				"source"
			]);
			this._forEachNode(medias, function(media) {
				var src = media.getAttribute("src");
				var poster = media.getAttribute("poster");
				var srcset = media.getAttribute("srcset");
				if (src) media.setAttribute("src", toAbsoluteURI(src));
				if (poster) media.setAttribute("poster", toAbsoluteURI(poster));
				if (srcset) {
					var newSrcset = srcset.replace(this.REGEXPS.srcsetUrl, function(_, p1, p2, p3) {
						return toAbsoluteURI(p1) + (p2 || "") + p3;
					});
					media.setAttribute("srcset", newSrcset);
				}
			});
		},
		_simplifyNestedElements(articleContent) {
			var node = articleContent;
			while (node) {
				if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
					if (this._isElementWithoutContent(node)) {
						node = this._removeAndGetNext(node);
						continue;
					} else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
						var child = node.children[0];
						for (var i = 0; i < node.attributes.length; i++) child.setAttributeNode(node.attributes[i].cloneNode());
						node.parentNode.replaceChild(child, node);
						node = child;
						continue;
					}
				}
				node = this._getNextNode(node);
			}
		},
		/**
		* Get the article title as an H1.
		*
		* @return string
		**/
		_getArticleTitle() {
			var doc = this._doc;
			var curTitle = "";
			var origTitle = "";
			try {
				curTitle = origTitle = doc.title.trim();
				if (typeof curTitle !== "string") curTitle = origTitle = this._getInnerText(doc.getElementsByTagName("title")[0]);
			} catch (e) {}
			var titleHadHierarchicalSeparators = false;
			function wordCount(str) {
				return str.split(/\s+/).length;
			}
			if (/ [\|\-\\\/>»] /.test(curTitle)) {
				titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
				let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
				curTitle = origTitle.substring(0, allSeparators.pop().index);
				if (wordCount(curTitle) < 3) curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
			} else if (curTitle.includes(": ")) {
				var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
				var trimmedTitle = curTitle.trim();
				if (!this._someNode(headings, function(heading) {
					return heading.textContent.trim() === trimmedTitle;
				})) {
					curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
					if (wordCount(curTitle) < 3) curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
					else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) curTitle = origTitle;
				}
			} else if (curTitle.length > 150 || curTitle.length < 15) {
				var hOnes = doc.getElementsByTagName("h1");
				if (hOnes.length === 1) curTitle = this._getInnerText(hOnes[0]);
			}
			curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
			var curTitleWordCount = wordCount(curTitle);
			if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) curTitle = origTitle;
			return curTitle;
		},
		/**
		* Prepare the HTML document for readability to scrape it.
		* This includes things like stripping javascript, CSS, and handling terrible markup.
		*
		* @return void
		**/
		_prepDocument() {
			var doc = this._doc;
			this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
			if (doc.body) this._replaceBrs(doc.body);
			this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
		},
		/**
		* Finds the next node, starting from the given node, and ignoring
		* whitespace in between. If the given node is an element, the same node is
		* returned.
		*/
		_nextNode(node) {
			var next = node;
			while (next && next.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next.textContent)) next = next.nextSibling;
			return next;
		},
		/**
		* Replaces 2 or more successive <br> elements with a single <p>.
		* Whitespace between <br> elements are ignored. For example:
		*   <div>foo<br>bar<br> <br><br>abc</div>
		* will become:
		*   <div>foo<br>bar<p>abc</p></div>
		*/
		_replaceBrs(elem) {
			this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
				var next = br.nextSibling;
				var replaced = false;
				while ((next = this._nextNode(next)) && next.tagName == "BR") {
					replaced = true;
					var brSibling = next.nextSibling;
					next.remove();
					next = brSibling;
				}
				if (replaced) {
					var p = this._doc.createElement("p");
					br.parentNode.replaceChild(p, br);
					next = p.nextSibling;
					while (next) {
						if (next.tagName == "BR") {
							var nextElem = this._nextNode(next.nextSibling);
							if (nextElem && nextElem.tagName == "BR") break;
						}
						if (!this._isPhrasingContent(next)) break;
						var sibling = next.nextSibling;
						p.appendChild(next);
						next = sibling;
					}
					while (p.lastChild && this._isWhitespace(p.lastChild)) p.lastChild.remove();
					if (p.parentNode.tagName === "P") this._setNodeTag(p.parentNode, "DIV");
				}
			});
		},
		_setNodeTag(node, tag) {
			this.log("_setNodeTag", node, tag);
			if (this._docJSDOMParser) {
				node.localName = tag.toLowerCase();
				node.tagName = tag.toUpperCase();
				return node;
			}
			var replacement = node.ownerDocument.createElement(tag);
			while (node.firstChild) replacement.appendChild(node.firstChild);
			node.parentNode.replaceChild(replacement, node);
			if (node.readability) replacement.readability = node.readability;
			for (var i = 0; i < node.attributes.length; i++) replacement.setAttributeNode(node.attributes[i].cloneNode());
			return replacement;
		},
		/**
		* Prepare the article node for display. Clean out any inline styles,
		* iframes, forms, strip extraneous <p> tags, etc.
		*
		* @param Element
		* @return void
		**/
		_prepArticle(articleContent) {
			this._cleanStyles(articleContent);
			this._markDataTables(articleContent);
			this._fixLazyImages(articleContent);
			this._cleanConditionally(articleContent, "form");
			this._cleanConditionally(articleContent, "fieldset");
			this._clean(articleContent, "object");
			this._clean(articleContent, "embed");
			this._clean(articleContent, "footer");
			this._clean(articleContent, "link");
			this._clean(articleContent, "aside");
			var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
			this._forEachNode(articleContent.children, function(topCandidate) {
				this._cleanMatchedNodes(topCandidate, function(node, matchString) {
					return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
				});
			});
			this._clean(articleContent, "iframe");
			this._clean(articleContent, "input");
			this._clean(articleContent, "textarea");
			this._clean(articleContent, "select");
			this._clean(articleContent, "button");
			this._cleanHeaders(articleContent);
			this._cleanConditionally(articleContent, "table");
			this._cleanConditionally(articleContent, "ul");
			this._cleanConditionally(articleContent, "div");
			this._replaceNodeTags(this._getAllNodesWithTag(articleContent, ["h1"]), "h2");
			this._removeNodes(this._getAllNodesWithTag(articleContent, ["p"]), function(paragraph) {
				return this._getAllNodesWithTag(paragraph, [
					"img",
					"embed",
					"object",
					"iframe"
				]).length === 0 && !this._getInnerText(paragraph, false);
			});
			this._forEachNode(this._getAllNodesWithTag(articleContent, ["br"]), function(br) {
				var next = this._nextNode(br.nextSibling);
				if (next && next.tagName == "P") br.remove();
			});
			this._forEachNode(this._getAllNodesWithTag(articleContent, ["table"]), function(table) {
				var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
				if (this._hasSingleTagInsideElement(tbody, "TR")) {
					var row = tbody.firstElementChild;
					if (this._hasSingleTagInsideElement(row, "TD")) {
						var cell = row.firstElementChild;
						cell = this._setNodeTag(cell, this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV");
						table.parentNode.replaceChild(cell, table);
					}
				}
			});
		},
		/**
		* Initialize a node with the readability object. Also checks the
		* className/id for special names to add to its score.
		*
		* @param Element
		* @return void
		**/
		_initializeNode(node) {
			node.readability = { contentScore: 0 };
			switch (node.tagName) {
				case "DIV":
					node.readability.contentScore += 5;
					break;
				case "PRE":
				case "TD":
				case "BLOCKQUOTE":
					node.readability.contentScore += 3;
					break;
				case "ADDRESS":
				case "OL":
				case "UL":
				case "DL":
				case "DD":
				case "DT":
				case "LI":
				case "FORM":
					node.readability.contentScore -= 3;
					break;
				case "H1":
				case "H2":
				case "H3":
				case "H4":
				case "H5":
				case "H6":
				case "TH": node.readability.contentScore -= 5;
			}
			node.readability.contentScore += this._getClassWeight(node);
		},
		_removeAndGetNext(node) {
			var nextNode = this._getNextNode(node, true);
			node.remove();
			return nextNode;
		},
		/**
		* Traverse the DOM from node to node, starting at the node passed in.
		* Pass true for the second parameter to indicate this node itself
		* (and its kids) are going away, and we want the next node over.
		*
		* Calling this in a loop will traverse the DOM depth-first.
		*
		* @param {Element} node
		* @param {boolean} ignoreSelfAndKids
		* @return {Element}
		*/
		_getNextNode(node, ignoreSelfAndKids) {
			if (!ignoreSelfAndKids && node.firstElementChild) return node.firstElementChild;
			if (node.nextElementSibling) return node.nextElementSibling;
			do
				node = node.parentNode;
			while (node && !node.nextElementSibling);
			return node && node.nextElementSibling;
		},
		_textSimilarity(textA, textB) {
			var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
			var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
			if (!tokensA.length || !tokensB.length) return 0;
			return 1 - tokensB.filter((token) => !tokensA.includes(token)).join(" ").length / tokensB.join(" ").length;
		},
		/**
		* Checks whether an element node contains a valid byline
		*
		* @param node {Element}
		* @param matchString {string}
		* @return boolean
		*/
		_isValidByline(node, matchString) {
			var rel = node.getAttribute("rel");
			var itemprop = node.getAttribute("itemprop");
			var bylineLength = node.textContent.trim().length;
			return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
		},
		_getNodeAncestors(node, maxDepth) {
			maxDepth = maxDepth || 0;
			var i = 0, ancestors = [];
			while (node.parentNode) {
				ancestors.push(node.parentNode);
				if (maxDepth && ++i === maxDepth) break;
				node = node.parentNode;
			}
			return ancestors;
		},
		/***
		* grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
		*         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
		*
		* @param page a document to run upon. Needs to be a full document, complete with body.
		* @return Element
		**/
		_grabArticle(page) {
			this.log("**** grabArticle ****");
			var doc = this._doc;
			var isPaging = page !== null;
			page = page ? page : this._doc.body;
			if (!page) {
				this.log("No body found in document. Abort.");
				return null;
			}
			var pageCacheHtml = page.innerHTML;
			while (true) {
				this.log("Starting grabArticle loop");
				var stripUnlikelyCandidates = this._flagIsActive(this.FLAG_STRIP_UNLIKELYS);
				var elementsToScore = [];
				var node = this._doc.documentElement;
				let shouldRemoveTitleHeader = true;
				while (node) {
					if (node.tagName === "HTML") this._articleLang = node.getAttribute("lang");
					var matchString = node.className + " " + node.id;
					if (!this._isProbablyVisible(node)) {
						this.log("Removing hidden node - " + matchString);
						node = this._removeAndGetNext(node);
						continue;
					}
					if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
						node = this._removeAndGetNext(node);
						continue;
					}
					if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
						var endOfSearchMarkerNode = this._getNextNode(node, true);
						var next = this._getNextNode(node);
						var itemPropNameNode = null;
						while (next && next != endOfSearchMarkerNode) {
							var itemprop = next.getAttribute("itemprop");
							if (itemprop && itemprop.includes("name")) {
								itemPropNameNode = next;
								break;
							} else next = this._getNextNode(next);
						}
						this._articleByline = (itemPropNameNode ?? node).textContent.trim();
						node = this._removeAndGetNext(node);
						continue;
					}
					if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
						this.log("Removing header: ", node.textContent.trim(), this._articleTitle.trim());
						shouldRemoveTitleHeader = false;
						node = this._removeAndGetNext(node);
						continue;
					}
					if (stripUnlikelyCandidates) {
						if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
							this.log("Removing unlikely candidate - " + matchString);
							node = this._removeAndGetNext(node);
							continue;
						}
						if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
							this.log("Removing content with role " + node.getAttribute("role") + " - " + matchString);
							node = this._removeAndGetNext(node);
							continue;
						}
					}
					if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
						node = this._removeAndGetNext(node);
						continue;
					}
					if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) elementsToScore.push(node);
					if (node.tagName === "DIV") {
						var p = null;
						var childNode = node.firstChild;
						while (childNode) {
							var nextSibling = childNode.nextSibling;
							if (this._isPhrasingContent(childNode)) {
								if (p !== null) p.appendChild(childNode);
								else if (!this._isWhitespace(childNode)) {
									p = doc.createElement("p");
									node.replaceChild(p, childNode);
									p.appendChild(childNode);
								}
							} else if (p !== null) {
								while (p.lastChild && this._isWhitespace(p.lastChild)) p.lastChild.remove();
								p = null;
							}
							childNode = nextSibling;
						}
						if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < .25) {
							var newNode = node.children[0];
							node.parentNode.replaceChild(newNode, node);
							node = newNode;
							elementsToScore.push(node);
						} else if (!this._hasChildBlockElement(node)) {
							node = this._setNodeTag(node, "P");
							elementsToScore.push(node);
						}
					}
					node = this._getNextNode(node);
				}
				/**
				* Loop through all paragraphs, and assign a score to them based on how content-y they look.
				* Then add their score to their parent node.
				*
				* A score is determined by things like number of commas, class names, etc. Maybe eventually link density.
				**/
				var candidates = [];
				this._forEachNode(elementsToScore, function(elementToScore) {
					if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") return;
					var innerText = this._getInnerText(elementToScore);
					if (innerText.length < 25) return;
					var ancestors = this._getNodeAncestors(elementToScore, 5);
					if (ancestors.length === 0) return;
					var contentScore = 0;
					contentScore += 1;
					contentScore += innerText.split(this.REGEXPS.commas).length;
					contentScore += Math.min(Math.floor(innerText.length / 100), 3);
					this._forEachNode(ancestors, function(ancestor, level) {
						if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") return;
						if (typeof ancestor.readability === "undefined") {
							this._initializeNode(ancestor);
							candidates.push(ancestor);
						}
						if (level === 0) var scoreDivider = 1;
						else if (level === 1) scoreDivider = 2;
						else scoreDivider = level * 3;
						ancestor.readability.contentScore += contentScore / scoreDivider;
					});
				});
				var topCandidates = [];
				for (var c = 0, cl = candidates.length; c < cl; c += 1) {
					var candidate = candidates[c];
					var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
					candidate.readability.contentScore = candidateScore;
					this.log("Candidate:", candidate, "with score " + candidateScore);
					for (var t = 0; t < this._nbTopCandidates; t++) {
						var aTopCandidate = topCandidates[t];
						if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
							topCandidates.splice(t, 0, candidate);
							if (topCandidates.length > this._nbTopCandidates) topCandidates.pop();
							break;
						}
					}
				}
				var topCandidate = topCandidates[0] || null;
				var neededToCreateTopCandidate = false;
				var parentOfTopCandidate;
				if (topCandidate === null || topCandidate.tagName === "BODY") {
					topCandidate = doc.createElement("DIV");
					neededToCreateTopCandidate = true;
					while (page.firstChild) {
						this.log("Moving child out:", page.firstChild);
						topCandidate.appendChild(page.firstChild);
					}
					page.appendChild(topCandidate);
					this._initializeNode(topCandidate);
				} else if (topCandidate) {
					var alternativeCandidateAncestors = [];
					for (var i = 1; i < topCandidates.length; i++) if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= .75) alternativeCandidateAncestors.push(this._getNodeAncestors(topCandidates[i]));
					var MINIMUM_TOPCANDIDATES = 3;
					if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
						parentOfTopCandidate = topCandidate.parentNode;
						while (parentOfTopCandidate.tagName !== "BODY") {
							var listsContainingThisAncestor = 0;
							for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) listsContainingThisAncestor += Number(alternativeCandidateAncestors[ancestorIndex].includes(parentOfTopCandidate));
							if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
								topCandidate = parentOfTopCandidate;
								break;
							}
							parentOfTopCandidate = parentOfTopCandidate.parentNode;
						}
					}
					if (!topCandidate.readability) this._initializeNode(topCandidate);
					parentOfTopCandidate = topCandidate.parentNode;
					var lastScore = topCandidate.readability.contentScore;
					var scoreThreshold = lastScore / 3;
					while (parentOfTopCandidate.tagName !== "BODY") {
						if (!parentOfTopCandidate.readability) {
							parentOfTopCandidate = parentOfTopCandidate.parentNode;
							continue;
						}
						var parentScore = parentOfTopCandidate.readability.contentScore;
						if (parentScore < scoreThreshold) break;
						if (parentScore > lastScore) {
							topCandidate = parentOfTopCandidate;
							break;
						}
						lastScore = parentOfTopCandidate.readability.contentScore;
						parentOfTopCandidate = parentOfTopCandidate.parentNode;
					}
					parentOfTopCandidate = topCandidate.parentNode;
					while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
						topCandidate = parentOfTopCandidate;
						parentOfTopCandidate = topCandidate.parentNode;
					}
					if (!topCandidate.readability) this._initializeNode(topCandidate);
				}
				var articleContent = doc.createElement("DIV");
				if (isPaging) articleContent.id = "readability-content";
				var siblingScoreThreshold = Math.max(10, topCandidate.readability.contentScore * .2);
				parentOfTopCandidate = topCandidate.parentNode;
				var siblings = parentOfTopCandidate.children;
				for (var s = 0, sl = siblings.length; s < sl; s++) {
					var sibling = siblings[s];
					var append = false;
					this.log("Looking at sibling node:", sibling, sibling.readability ? "with score " + sibling.readability.contentScore : "");
					this.log("Sibling has score", sibling.readability ? sibling.readability.contentScore : "Unknown");
					if (sibling === topCandidate) append = true;
					else {
						var contentBonus = 0;
						if (sibling.className === topCandidate.className && topCandidate.className !== "") contentBonus += topCandidate.readability.contentScore * .2;
						if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) append = true;
						else if (sibling.nodeName === "P") {
							var linkDensity = this._getLinkDensity(sibling);
							var nodeContent = this._getInnerText(sibling);
							var nodeLength = nodeContent.length;
							if (nodeLength > 80 && linkDensity < .25) append = true;
							else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) append = true;
						}
					}
					if (append) {
						this.log("Appending node:", sibling);
						if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
							this.log("Altering sibling:", sibling, "to div.");
							sibling = this._setNodeTag(sibling, "DIV");
						}
						articleContent.appendChild(sibling);
						siblings = parentOfTopCandidate.children;
						s -= 1;
						sl -= 1;
					}
				}
				if (this._debug) this.log("Article content pre-prep: " + articleContent.innerHTML);
				this._prepArticle(articleContent);
				if (this._debug) this.log("Article content post-prep: " + articleContent.innerHTML);
				if (neededToCreateTopCandidate) {
					topCandidate.id = "readability-page-1";
					topCandidate.className = "page";
				} else {
					var div = doc.createElement("DIV");
					div.id = "readability-page-1";
					div.className = "page";
					while (articleContent.firstChild) div.appendChild(articleContent.firstChild);
					articleContent.appendChild(div);
				}
				if (this._debug) this.log("Article content after paging: " + articleContent.innerHTML);
				var parseSuccessful = true;
				var textLength = this._getInnerText(articleContent, true).length;
				if (textLength < this._charThreshold) {
					parseSuccessful = false;
					page.innerHTML = pageCacheHtml;
					this._attempts.push({
						articleContent,
						textLength
					});
					if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
					else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) this._removeFlag(this.FLAG_WEIGHT_CLASSES);
					else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
					else {
						this._attempts.sort(function(a, b) {
							return b.textLength - a.textLength;
						});
						if (!this._attempts[0].textLength) return null;
						articleContent = this._attempts[0].articleContent;
						parseSuccessful = true;
					}
				}
				if (parseSuccessful) {
					var ancestors = [parentOfTopCandidate, topCandidate].concat(this._getNodeAncestors(parentOfTopCandidate));
					this._someNode(ancestors, function(ancestor) {
						if (!ancestor.tagName) return false;
						var articleDir = ancestor.getAttribute("dir");
						if (articleDir) {
							this._articleDir = articleDir;
							return true;
						}
						return false;
					});
					return articleContent;
				}
			}
		},
		/**
		* Converts some of the common HTML entities in string to their corresponding characters.
		*
		* @param str {string} - a string to unescape.
		* @return string without HTML entity.
		*/
		_unescapeHtmlEntities(str) {
			if (!str) return str;
			var htmlEscapeMap = this.HTML_ESCAPE_MAP;
			return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
				return htmlEscapeMap[tag];
			}).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
				var num = parseInt(hex || numStr, hex ? 16 : 10);
				if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) num = 65533;
				return String.fromCodePoint(num);
			});
		},
		/**
		* Try to extract metadata from JSON-LD object.
		* For now, only Schema.org objects of type Article or its subtypes are supported.
		* @return Object with any metadata that could be extracted (possibly none)
		*/
		_getJSONLD(doc) {
			var scripts = this._getAllNodesWithTag(doc, ["script"]);
			var metadata;
			this._forEachNode(scripts, function(jsonLdElement) {
				if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") try {
					var content = jsonLdElement.textContent.replace(/^\s*<!\[CDATA\[|\]\]>\s*$/g, "");
					var parsed = JSON.parse(content);
					if (Array.isArray(parsed)) {
						parsed = parsed.find((it) => {
							return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
						});
						if (!parsed) return;
					}
					var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
					if (!(typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex))) return;
					if (!parsed["@type"] && Array.isArray(parsed["@graph"])) parsed = parsed["@graph"].find((it) => {
						return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
					});
					if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) return;
					metadata = {};
					if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
						var title = this._getArticleTitle();
						var nameMatches = this._textSimilarity(parsed.name, title) > .75;
						if (this._textSimilarity(parsed.headline, title) > .75 && !nameMatches) metadata.title = parsed.headline;
						else metadata.title = parsed.name;
					} else if (typeof parsed.name === "string") metadata.title = parsed.name.trim();
					else if (typeof parsed.headline === "string") metadata.title = parsed.headline.trim();
					if (parsed.author) {
						if (typeof parsed.author.name === "string") metadata.byline = parsed.author.name.trim();
						else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") metadata.byline = parsed.author.filter(function(author) {
							return author && typeof author.name === "string";
						}).map(function(author) {
							return author.name.trim();
						}).join(", ");
					}
					if (typeof parsed.description === "string") metadata.excerpt = parsed.description.trim();
					if (parsed.publisher && typeof parsed.publisher.name === "string") metadata.siteName = parsed.publisher.name.trim();
					if (typeof parsed.datePublished === "string") metadata.datePublished = parsed.datePublished.trim();
				} catch (err) {
					this.log(err.message);
				}
			});
			return metadata ? metadata : {};
		},
		/**
		* Attempts to get excerpt and byline metadata for the article.
		*
		* @param {Object} jsonld — object containing any metadata that
		* could be extracted from JSON-LD object.
		*
		* @return Object with optional "excerpt" and "byline" properties
		*/
		_getArticleMetadata(jsonld) {
			var metadata = {};
			var values = {};
			var metaElements = this._doc.getElementsByTagName("meta");
			var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
			var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
			this._forEachNode(metaElements, function(element) {
				var elementName = element.getAttribute("name");
				var elementProperty = element.getAttribute("property");
				var content = element.getAttribute("content");
				if (!content) return;
				var matches = null;
				var name = null;
				if (elementProperty) {
					matches = elementProperty.match(propertyPattern);
					if (matches) {
						name = matches[0].toLowerCase().replace(/\s/g, "");
						values[name] = content.trim();
					}
				}
				if (!matches && elementName && namePattern.test(elementName)) {
					name = elementName;
					if (content) {
						name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
						values[name] = content.trim();
					}
				}
			});
			metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
			if (!metadata.title) metadata.title = this._getArticleTitle();
			const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
			metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
			metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
			metadata.siteName = jsonld.siteName || values["og:site_name"];
			metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
			metadata.title = this._unescapeHtmlEntities(metadata.title);
			metadata.byline = this._unescapeHtmlEntities(metadata.byline);
			metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
			metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
			metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
			return metadata;
		},
		/**
		* Check if node is image, or if node contains exactly only one image
		* whether as a direct child or as its descendants.
		*
		* @param Element
		**/
		_isSingleImage(node) {
			while (node) {
				if (node.tagName === "IMG") return true;
				if (node.children.length !== 1 || node.textContent.trim() !== "") return false;
				node = node.children[0];
			}
			return false;
		},
		/**
		* Find all <noscript> that are located after <img> nodes, and which contain only one
		* <img> element. Replace the first image with the image from inside the <noscript> tag,
		* and remove the <noscript> tag. This improves the quality of the images we use on
		* some sites (e.g. Medium).
		*
		* @param Element
		**/
		_unwrapNoscriptImages(doc) {
			var imgs = Array.from(doc.getElementsByTagName("img"));
			this._forEachNode(imgs, function(img) {
				for (var i = 0; i < img.attributes.length; i++) {
					var attr = img.attributes[i];
					switch (attr.name) {
						case "src":
						case "srcset":
						case "data-src":
						case "data-srcset": return;
					}
					if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) return;
				}
				img.remove();
			});
			var noscripts = Array.from(doc.getElementsByTagName("noscript"));
			this._forEachNode(noscripts, function(noscript) {
				if (!this._isSingleImage(noscript)) return;
				var tmp = doc.createElement("div");
				tmp.innerHTML = noscript.innerHTML;
				var prevElement = noscript.previousElementSibling;
				if (prevElement && this._isSingleImage(prevElement)) {
					var prevImg = prevElement;
					if (prevImg.tagName !== "IMG") prevImg = prevElement.getElementsByTagName("img")[0];
					var newImg = tmp.getElementsByTagName("img")[0];
					for (var i = 0; i < prevImg.attributes.length; i++) {
						var attr = prevImg.attributes[i];
						if (attr.value === "") continue;
						if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
							if (newImg.getAttribute(attr.name) === attr.value) continue;
							var attrName = attr.name;
							if (newImg.hasAttribute(attrName)) attrName = "data-old-" + attrName;
							newImg.setAttribute(attrName, attr.value);
						}
					}
					noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
				}
			});
		},
		/**
		* Removes script tags from the document.
		*
		* @param Element
		**/
		_removeScripts(doc) {
			this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
		},
		/**
		* Check if this node has only whitespace and a single element with given tag
		* Returns false if the DIV node contains non-empty text nodes
		* or if it contains no element with given tag or more than 1 element.
		*
		* @param Element
		* @param string tag of child element
		**/
		_hasSingleTagInsideElement(element, tag) {
			if (element.children.length != 1 || element.children[0].tagName !== tag) return false;
			return !this._someNode(element.childNodes, function(node) {
				return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
			});
		},
		_isElementWithoutContent(node) {
			return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
		},
		/**
		* Determine whether element has any children block level elements.
		*
		* @param Element
		*/
		_hasChildBlockElement(element) {
			return this._someNode(element.childNodes, function(node) {
				return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
			});
		},
		/***
		* Determine if a node qualifies as phrasing content.
		* https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
		**/
		_isPhrasingContent(node) {
			return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
		},
		_isWhitespace(node) {
			return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
		},
		/**
		* Get the inner text of a node - cross browser compatibly.
		* This also strips out any excess whitespace to be found.
		*
		* @param Element
		* @param Boolean normalizeSpaces (default: true)
		* @return string
		**/
		_getInnerText(e, normalizeSpaces) {
			normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
			var textContent = e.textContent.trim();
			if (normalizeSpaces) return textContent.replace(this.REGEXPS.normalize, " ");
			return textContent;
		},
		/**
		* Get the number of times a string s appears in the node e.
		*
		* @param Element
		* @param string - what to split on. Default is ","
		* @return number (integer)
		**/
		_getCharCount(e, s) {
			s = s || ",";
			return this._getInnerText(e).split(s).length - 1;
		},
		/**
		* Remove the style attribute on every e and under.
		* TODO: Test if getElementsByTagName(*) is faster.
		*
		* @param Element
		* @return void
		**/
		_cleanStyles(e) {
			if (!e || e.tagName.toLowerCase() === "svg") return;
			for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
			if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
				e.removeAttribute("width");
				e.removeAttribute("height");
			}
			var cur = e.firstElementChild;
			while (cur !== null) {
				this._cleanStyles(cur);
				cur = cur.nextElementSibling;
			}
		},
		/**
		* Get the density of links as a percentage of the content
		* This is the amount of text that is inside a link divided by the total text in the node.
		*
		* @param Element
		* @return number (float)
		**/
		_getLinkDensity(element) {
			var textLength = this._getInnerText(element).length;
			if (textLength === 0) return 0;
			var linkLength = 0;
			this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
				var href = linkNode.getAttribute("href");
				var coefficient = href && this.REGEXPS.hashUrl.test(href) ? .3 : 1;
				linkLength += this._getInnerText(linkNode).length * coefficient;
			});
			return linkLength / textLength;
		},
		/**
		* Get an elements class/id weight. Uses regular expressions to tell if this
		* element looks good or bad.
		*
		* @param Element
		* @return number (Integer)
		**/
		_getClassWeight(e) {
			if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) return 0;
			var weight = 0;
			if (typeof e.className === "string" && e.className !== "") {
				if (this.REGEXPS.negative.test(e.className)) weight -= 25;
				if (this.REGEXPS.positive.test(e.className)) weight += 25;
			}
			if (typeof e.id === "string" && e.id !== "") {
				if (this.REGEXPS.negative.test(e.id)) weight -= 25;
				if (this.REGEXPS.positive.test(e.id)) weight += 25;
			}
			return weight;
		},
		/**
		* Clean a node of all elements of type "tag".
		* (Unless it's a youtube/vimeo video. People love movies.)
		*
		* @param Element
		* @param string tag to clean
		* @return void
		**/
		_clean(e, tag) {
			var isEmbed = [
				"object",
				"embed",
				"iframe"
			].includes(tag);
			this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
				if (isEmbed) {
					for (var i = 0; i < element.attributes.length; i++) if (this._allowedVideoRegex.test(element.attributes[i].value)) return false;
					if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) return false;
				}
				return true;
			});
		},
		/**
		* Check if a given node has one of its ancestor tag name matching the
		* provided one.
		* @param  HTMLElement node
		* @param  String      tagName
		* @param  Number      maxDepth
		* @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
		* @return Boolean
		*/
		_hasAncestorTag(node, tagName, maxDepth, filterFn) {
			maxDepth = maxDepth || 3;
			tagName = tagName.toUpperCase();
			var depth = 0;
			while (node.parentNode) {
				if (maxDepth > 0 && depth > maxDepth) return false;
				if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) return true;
				node = node.parentNode;
				depth++;
			}
			return false;
		},
		/**
		* Return an object indicating how many rows and columns this table has.
		*/
		_getRowAndColumnCount(table) {
			var rows = 0;
			var columns = 0;
			var trs = table.getElementsByTagName("tr");
			for (var i = 0; i < trs.length; i++) {
				var rowspan = trs[i].getAttribute("rowspan") || 0;
				if (rowspan) rowspan = parseInt(rowspan, 10);
				rows += rowspan || 1;
				var columnsInThisRow = 0;
				var cells = trs[i].getElementsByTagName("td");
				for (var j = 0; j < cells.length; j++) {
					var colspan = cells[j].getAttribute("colspan") || 0;
					if (colspan) colspan = parseInt(colspan, 10);
					columnsInThisRow += colspan || 1;
				}
				columns = Math.max(columns, columnsInThisRow);
			}
			return {
				rows,
				columns
			};
		},
		/**
		* Look for 'data' (as opposed to 'layout') tables, for which we use
		* similar checks as
		* https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
		*/
		_markDataTables(root) {
			var tables = root.getElementsByTagName("table");
			for (var i = 0; i < tables.length; i++) {
				var table = tables[i];
				if (table.getAttribute("role") == "presentation") {
					table._readabilityDataTable = false;
					continue;
				}
				if (table.getAttribute("datatable") == "0") {
					table._readabilityDataTable = false;
					continue;
				}
				if (table.getAttribute("summary")) {
					table._readabilityDataTable = true;
					continue;
				}
				var caption = table.getElementsByTagName("caption")[0];
				if (caption && caption.childNodes.length) {
					table._readabilityDataTable = true;
					continue;
				}
				var dataTableDescendants = [
					"col",
					"colgroup",
					"tfoot",
					"thead",
					"th"
				];
				var descendantExists = function(tag) {
					return !!table.getElementsByTagName(tag)[0];
				};
				if (dataTableDescendants.some(descendantExists)) {
					this.log("Data table because found data-y descendant");
					table._readabilityDataTable = true;
					continue;
				}
				if (table.getElementsByTagName("table")[0]) {
					table._readabilityDataTable = false;
					continue;
				}
				var sizeInfo = this._getRowAndColumnCount(table);
				if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
					table._readabilityDataTable = false;
					continue;
				}
				if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
					table._readabilityDataTable = true;
					continue;
				}
				table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
			}
		},
		_fixLazyImages(root) {
			this._forEachNode(this._getAllNodesWithTag(root, [
				"img",
				"picture",
				"figure"
			]), function(elem) {
				if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
					var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
					if (parts[1] === "image/svg+xml") return;
					var srcCouldBeRemoved = false;
					for (var i = 0; i < elem.attributes.length; i++) {
						var attr = elem.attributes[i];
						if (attr.name === "src") continue;
						if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
							srcCouldBeRemoved = true;
							break;
						}
					}
					if (srcCouldBeRemoved) {
						var b64starts = parts[0].length;
						if (elem.src.length - b64starts < 133) elem.removeAttribute("src");
					}
				}
				if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) return;
				for (var j = 0; j < elem.attributes.length; j++) {
					attr = elem.attributes[j];
					if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") continue;
					var copyTo = null;
					if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) copyTo = "srcset";
					else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) copyTo = "src";
					if (copyTo) {
						if (elem.tagName === "IMG" || elem.tagName === "PICTURE") elem.setAttribute(copyTo, attr.value);
						else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
							var img = this._doc.createElement("img");
							img.setAttribute(copyTo, attr.value);
							elem.appendChild(img);
						}
					}
				}
			});
		},
		_getTextDensity(e, tags) {
			var textLength = this._getInnerText(e, true).length;
			if (textLength === 0) return 0;
			var childrenLength = 0;
			var children = this._getAllNodesWithTag(e, tags);
			this._forEachNode(children, (child) => childrenLength += this._getInnerText(child, true).length);
			return childrenLength / textLength;
		},
		/**
		* Clean an element of all tags of type "tag" if they look fishy.
		* "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
		*
		* @return void
		**/
		_cleanConditionally(e, tag) {
			if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) return;
			this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
				var isDataTable = function(t) {
					return t._readabilityDataTable;
				};
				var isList = tag === "ul" || tag === "ol";
				if (!isList) {
					var listLength = 0;
					var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
					this._forEachNode(listNodes, (list) => listLength += this._getInnerText(list).length);
					isList = listLength / this._getInnerText(node).length > .9;
				}
				if (tag === "table" && isDataTable(node)) return false;
				if (this._hasAncestorTag(node, "table", -1, isDataTable)) return false;
				if (this._hasAncestorTag(node, "code")) return false;
				if ([...node.getElementsByTagName("table")].some((tbl) => tbl._readabilityDataTable)) return false;
				var weight = this._getClassWeight(node);
				this.log("Cleaning Conditionally", node);
				if (weight + 0 < 0) return true;
				if (this._getCharCount(node, ",") < 10) {
					var p = node.getElementsByTagName("p").length;
					var img = node.getElementsByTagName("img").length;
					var li = node.getElementsByTagName("li").length - 100;
					var input = node.getElementsByTagName("input").length;
					var headingDensity = this._getTextDensity(node, [
						"h1",
						"h2",
						"h3",
						"h4",
						"h5",
						"h6"
					]);
					var embedCount = 0;
					var embeds = this._getAllNodesWithTag(node, [
						"object",
						"embed",
						"iframe"
					]);
					for (var i = 0; i < embeds.length; i++) {
						for (var j = 0; j < embeds[i].attributes.length; j++) if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) return false;
						if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) return false;
						embedCount++;
					}
					var innerText = this._getInnerText(node);
					if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) return true;
					var contentLength = innerText.length;
					var linkDensity = this._getLinkDensity(node);
					var textishTags = [
						"SPAN",
						"LI",
						"TD"
					].concat(Array.from(this.DIV_TO_P_ELEMS));
					var textDensity = this._getTextDensity(node, textishTags);
					var isFigureChild = this._hasAncestorTag(node, "figure");
					const shouldRemoveNode = () => {
						const errs = [];
						if (!isFigureChild && img > 1 && p / img < .5) errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
						if (!isList && li > p) errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
						if (input > Math.floor(p / 3)) errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
						if (!isList && !isFigureChild && headingDensity < .9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) errs.push(`Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`);
						if (!isList && weight < 25 && linkDensity > .2 + this._linkDensityModifier) errs.push(`Low weight and a little linky. (linkDensity=${linkDensity})`);
						if (weight >= 25 && linkDensity > .5 + this._linkDensityModifier) errs.push(`High weight and mostly links. (linkDensity=${linkDensity})`);
						if (embedCount === 1 && contentLength < 75 || embedCount > 1) errs.push(`Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`);
						if (img === 0 && textDensity === 0) errs.push(`No useful content. (img=${img}, textDensity=${textDensity})`);
						if (errs.length) {
							this.log("Checks failed", errs);
							return true;
						}
						return false;
					};
					var haveToRemove = shouldRemoveNode();
					if (isList && haveToRemove) {
						for (var x = 0; x < node.children.length; x++) if (node.children[x].children.length > 1) return haveToRemove;
						if (img == node.getElementsByTagName("li").length) return false;
					}
					return haveToRemove;
				}
				return false;
			});
		},
		/**
		* Clean out elements that match the specified conditions
		*
		* @param Element
		* @param Function determines whether a node should be removed
		* @return void
		**/
		_cleanMatchedNodes(e, filter) {
			var endOfSearchMarkerNode = this._getNextNode(e, true);
			var next = this._getNextNode(e);
			while (next && next != endOfSearchMarkerNode) if (filter.call(this, next, next.className + " " + next.id)) next = this._removeAndGetNext(next);
			else next = this._getNextNode(next);
		},
		/**
		* Clean out spurious headers from an Element.
		*
		* @param Element
		* @return void
		**/
		_cleanHeaders(e) {
			let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
			this._removeNodes(headingNodes, function(node) {
				let shouldRemove = this._getClassWeight(node) < 0;
				if (shouldRemove) this.log("Removing header with low class weight:", node);
				return shouldRemove;
			});
		},
		/**
		* Check if this node is an H1 or H2 element whose content is mostly
		* the same as the article title.
		*
		* @param Element  the node to check.
		* @return boolean indicating whether this is a title-like header.
		*/
		_headerDuplicatesTitle(node) {
			if (node.tagName != "H1" && node.tagName != "H2") return false;
			var heading = this._getInnerText(node, false);
			this.log("Evaluating similarity of header:", heading, this._articleTitle);
			return this._textSimilarity(this._articleTitle, heading) > .75;
		},
		_flagIsActive(flag) {
			return (this._flags & flag) > 0;
		},
		_removeFlag(flag) {
			this._flags = this._flags & ~flag;
		},
		_isProbablyVisible(node) {
			return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
		},
		/**
		* Runs readability.
		*
		* Workflow:
		*  1. Prep the document by removing script tags, css, etc.
		*  2. Build readability's DOM tree.
		*  3. Grab the article content from the current dom tree.
		*  4. Replace the current DOM tree with the new one.
		*  5. Read peacefully.
		*
		* @return void
		**/
		parse() {
			if (this._maxElemsToParse > 0) {
				var numTags = this._doc.getElementsByTagName("*").length;
				if (numTags > this._maxElemsToParse) throw new Error("Aborting parsing document; " + numTags + " elements found");
			}
			this._unwrapNoscriptImages(this._doc);
			var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
			this._removeScripts(this._doc);
			this._prepDocument();
			var metadata = this._getArticleMetadata(jsonLd);
			this._metadata = metadata;
			this._articleTitle = metadata.title;
			var articleContent = this._grabArticle();
			if (!articleContent) return null;
			this.log("Grabbed: " + articleContent.innerHTML);
			this._postProcessContent(articleContent);
			if (!metadata.excerpt) {
				var paragraphs = articleContent.getElementsByTagName("p");
				if (paragraphs.length) metadata.excerpt = paragraphs[0].textContent.trim();
			}
			var textContent = articleContent.textContent;
			return {
				title: this._articleTitle,
				byline: metadata.byline || this._articleByline,
				dir: this._articleDir,
				lang: this._articleLang,
				content: this._serializer(articleContent),
				textContent,
				length: textContent.length,
				excerpt: metadata.excerpt,
				siteName: metadata.siteName || this._articleSiteName,
				publishedTime: metadata.publishedTime
			};
		}
	};
	if (typeof module === "object") module.exports = Readability;
}));
//#endregion
//#region ../../viso-ext/node_modules/@mozilla/readability/Readability-readerable.js
var require_Readability_readerable = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var REGEXPS = {
		unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
		okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
	};
	function isNodeVisible(node) {
		return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
	}
	/**
	* Decides whether or not the document is reader-able without parsing the whole thing.
	* @param {Object} options Configuration object.
	* @param {number} [options.minContentLength=140] The minimum node content length used to decide if the document is readerable.
	* @param {number} [options.minScore=20] The minumum cumulated 'score' used to determine if the document is readerable.
	* @param {Function} [options.visibilityChecker=isNodeVisible] The function used to determine if a node is visible.
	* @return {boolean} Whether or not we suspect Readability.parse() will suceeed at returning an article object.
	*/
	function isProbablyReaderable(doc, options = {}) {
		if (typeof options == "function") options = { visibilityChecker: options };
		options = Object.assign({
			minScore: 20,
			minContentLength: 140,
			visibilityChecker: isNodeVisible
		}, options);
		var nodes = doc.querySelectorAll("p, pre, article");
		var brNodes = doc.querySelectorAll("div > br");
		if (brNodes.length) {
			var set = new Set(nodes);
			[].forEach.call(brNodes, function(node) {
				set.add(node.parentNode);
			});
			nodes = Array.from(set);
		}
		var score = 0;
		return [].some.call(nodes, function(node) {
			if (!options.visibilityChecker(node)) return false;
			var matchString = node.className + " " + node.id;
			if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) return false;
			if (node.matches("li p")) return false;
			var textContentLength = node.textContent.trim().length;
			if (textContentLength < options.minContentLength) return false;
			score += Math.sqrt(textContentLength - options.minContentLength);
			if (score > options.minScore) return true;
			return false;
		});
	}
	if (typeof module === "object") module.exports = isProbablyReaderable;
}));
//#endregion
//#region src/content/extract/appLike.ts
var import_readability = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		Readability: require_Readability(),
		isProbablyReaderable: require_Readability_readerable()
	};
})))();
/**
* §5.5 rule 3 — does this URL look like an application surface rather than a
* document?
*
* Both the pathname and the hash are examined: plenty of app UIs route entirely
* in the fragment (Gmail's `#inbox`, older SPAs' `#/board/3`), and ignoring it
* would miss exactly the surfaces this check exists for.
*
* The query string is deliberately excluded — `?q=/inbox` describes a search,
* not the page the user is looking at.
*/
function isAppLikeUrl(url) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return false;
	}
	return hasAppLikeSegment(parsed.pathname) || hasAppLikeSegment(parsed.hash.replace(/^#\/?/, ""));
}
function hasAppLikeSegment(path) {
	for (const segment of path.toLowerCase().split("/")) if (segment !== "" && APP_LIKE_PATH_SEGMENTS.has(segment)) return true;
	return false;
}
//#endregion
//#region src/content/extract/metadata.ts
function readHeadMetadata(doc) {
	const ogTitle = metaContent(doc, "property", "og:title");
	const ogDescription = metaContent(doc, "property", "og:description");
	const ogSiteName = metaContent(doc, "property", "og:site_name");
	const metaDescription = metaContent(doc, "name", "description");
	const title = ogTitle !== "" ? ogTitle : doc.title.trim();
	const description = ogDescription !== "" ? ogDescription : metaDescription;
	return {
		title,
		description,
		siteName: ogSiteName,
		hasSemanticMain: doc.querySelector("article, [role=\"main\"], main") !== null,
		isSufficient: ogTitle !== "" && description.length >= EXTRACT_CONFIG.MIN_STRUCTURED_DESCRIPTION
	};
}
function metaContent(doc, attribute, key) {
	return (doc.querySelector(`meta[${attribute}="${key}"]`)?.getAttribute("content") ?? "").trim();
}
//#endregion
//#region src/content/extract/generic.ts
/**
* Generic fallback extractor (§5.4) plus the confidence gate (§5.5).
*
* Order of operations, cheapest first:
*   1. app-like URL with no adapter  -> degraded success, no clone
*   2. head metadata (og:*)          -> structured success, no clone
*   3. body too large                -> degraded success, no clone
*   4. clone body, run Readability   -> success, or a typed failure
*
* Only step 4 clones anything, and the original DOM is never touched: the
* synthetic document Readability mutates is built from an imported copy.
*/
function extractGenericContext(doc, url, now = Date.now()) {
	try {
		return runExtraction(doc, url, now);
	} catch {
		return {
			ok: false,
			reason: "extractor_threw"
		};
	}
}
function runExtraction(doc, url, now) {
	const meta = readHeadMetadata(doc);
	if (isAppLikeUrl(url)) return {
		ok: true,
		context: degraded(doc, url, meta, now, "app-like")
	};
	if (meta.isSufficient) return {
		ok: true,
		context: structured(url, meta, now)
	};
	if (countBodyElements(doc) > EXTRACT_CONFIG.MAX_BODY_ELEMENTS) return {
		ok: true,
		context: degraded(doc, url, meta, now, "too-large")
	};
	const clone = cloneBodyIntoDocument(doc, url);
	const article = new import_readability.Readability(clone, { charThreshold: EXTRACT_CONFIG.MIN_TEXT_LENGTH }).parse();
	if (article === null) return {
		ok: false,
		reason: "no_content"
	};
	const text = (article.textContent ?? "").trim();
	if (text.length === 0) return {
		ok: false,
		reason: "no_content"
	};
	if (text.length < EXTRACT_CONFIG.MIN_TEXT_LENGTH) return {
		ok: false,
		reason: "text_too_short"
	};
	const title = (article.title ?? meta.title).trim();
	const byline = (article.byline ?? "").trim();
	const siteName = (article.siteName ?? meta.siteName).trim();
	let confidence = EXTRACT_CONFIG.CONFIDENCE.READABILITY_BASE;
	if (meta.hasSemanticMain) confidence += EXTRACT_CONFIG.CONFIDENCE.SEMANTIC_BONUS;
	if (byline !== "" || siteName !== "") confidence += EXTRACT_CONFIG.CONFIDENCE.BYLINE_BONUS;
	confidence = Math.min(confidence, EXTRACT_CONFIG.CONFIDENCE.READABILITY_MAX);
	const entityRefs = buildEntities$1(url, siteName, byline);
	return {
		ok: true,
		context: {
			title,
			body: snippet$1(text),
			entities: entityRefs.map((e) => e.value),
			entity_refs: entityRefs,
			source_url: url,
			deep_link: url,
			platform_type: "generic",
			timestamp: now,
			confidence,
			context_hash: contextHash(url),
			extractor: "generic-readability@1"
		}
	};
}
/**
* Degraded success: document.title + URL, nothing else (§5.5 rule 3).
*
* Not a failure. It carries confidence 0.2, which is below the §7.2 floor of
* 0.6, so the relevance gate silently discards it — one gate rather than two.
*/
function degraded(doc, url, meta, now, cause) {
	const title = (meta.title !== "" ? meta.title : doc.title).trim();
	const entityRefs = buildEntities$1(url, meta.siteName, "");
	return {
		title,
		body: "",
		entities: entityRefs.map((e) => e.value),
		entity_refs: entityRefs,
		source_url: url,
		deep_link: url,
		platform_type: "generic",
		timestamp: now,
		confidence: EXTRACT_CONFIG.CONFIDENCE.DEGRADED,
		context_hash: contextHash(url),
		extractor: `generic-degraded-${cause}@1`
	};
}
/** Structured path: og: tags, read without cloning (§5.5 rule 2). */
function structured(url, meta, now) {
	const entityRefs = buildEntities$1(url, meta.siteName, "");
	return {
		title: meta.title,
		body: snippet$1(meta.description),
		entities: entityRefs.map((e) => e.value),
		entity_refs: entityRefs,
		source_url: url,
		deep_link: url,
		platform_type: "generic",
		timestamp: now,
		confidence: EXTRACT_CONFIG.CONFIDENCE.STRUCTURED,
		context_hash: contextHash(url),
		extractor: "generic-metadata@1"
	};
}
/**
* Live HTMLCollection: reading `.length` does not materialise an array, unlike
* querySelectorAll('*') which would allocate one node reference per element on
* exactly the huge pages this check exists to avoid.
*/
function countBodyElements(doc) {
	return doc.body?.getElementsByTagName("*").length ?? 0;
}
/**
* Builds the throwaway document Readability parses.
*
* importNode clones and adopts in one step, so the live DOM is read once and
* never modified. The <base> element matters: Readability resolves relative
* URLs against baseURI, which on a synthetic document is otherwise about:blank.
*/
function cloneBodyIntoDocument(doc, url) {
	const clone = doc.implementation.createHTMLDocument(doc.title);
	const base = clone.createElement("base");
	base.setAttribute("href", url);
	clone.head.appendChild(base);
	if (doc.body !== null) clone.body.replaceWith(clone.importNode(doc.body, true));
	return clone;
}
function buildEntities$1(url, siteName, byline) {
	const entities = [];
	try {
		const host = new URL(url).hostname.replace(/^www\./, "");
		if (host !== "") entities.push({
			type: "domain",
			value: host
		});
	} catch {}
	if (siteName !== "") entities.push({
		type: "other",
		value: siteName
	});
	if (byline !== "") entities.push({
		type: "person",
		value: byline
	});
	return entities;
}
/**
* Identity of a view, for finding the notes taken on it.
*
* The URL alone. Title was part of this and had to come out: titles mutate on
* the same page constantly — unread counts, "(1) …" prefixes, live timers — so
* a note saved a minute ago stopped matching the page it was written on, and
* the panel showed nothing. Stability matters more here than precision, because
* the failure it causes is invisible: nothing errors, the note is simply gone.
*
* The body is excluded for the same reason it always was: text that shifts
* between visits is still the same context.
*
* Platform adapters override this with a real entity id — a Gmail thread id, a
* Jira key — which is stronger than either.
*/
function contextHash(url) {
	return fnv1a(url);
}
function snippet$1(text) {
	const normalized = text.replace(/\s+/g, " ").trim();
	return normalized.length <= EXTRACT_CONFIG.BODY_SNIPPET_LENGTH ? normalized : `${normalized.slice(0, EXTRACT_CONFIG.BODY_SNIPPET_LENGTH)}…`;
}
//#endregion
//#region src/content/extract/adapters/gmail.ts
/**
* Gmail adapter (spec §5.6, first platform).
*
* Gmail's markup is generated and its class names are short and unstable, which
* §11 lists as a live risk. Two things guard against it:
*
*  1. Every field is read through an ordered list of selectors, newest-known
*     first, so one rename does not blank the whole extraction.
*  2. `confidence` is computed from how much was actually found. When the
*     selectors rot, confidence falls and the §7.2 gate goes quiet on its own,
*     rather than the adapter confidently reporting nonsense.
*/
var SUBJECT_SELECTORS = [
	"h2.hP",
	"[data-thread-perm-id] h2",
	"h2[data-legacy-thread-id]"
];
var SENDER_SELECTORS = [
	"span.gD",
	".gE span[email]",
	"span[email]"
];
var BODY_SELECTORS = [
	"div.a3s",
	"div[data-message-id] div.ii",
	".adn .ii"
];
/**
* Gmail thread ids are long opaque tokens ("FMfcgzGtxSrBpwHqJDvJHzBLKPBqDVLL",
* and 16-hex-digit legacy ids). View names are short words — "inbox", "sent",
* "starred", "important" — so length is what separates them.
*
* A long `#search/<query>` term can slip through; that page then fails the
* subject/body read and returns no_content, which is the right outcome anyway.
*/
var THREAD_ID_PATTERN = /^[A-Za-z0-9_-]{12,}$/;
var gmailAdapter = {
	id: "gmail@1",
	matches(url) {
		try {
			return new URL(url).hostname === "mail.google.com";
		} catch {
			return false;
		}
	},
	buildDeepLink(entityId) {
		return `https://mail.google.com/mail/u/0/#inbox/${entityId}`;
	},
	extractContext(doc, url, now) {
		const location = parseGmailUrl(url);
		if (location.threadId === null) return {
			ok: true,
			context: listView(doc, url, now, location)
		};
		const subject = firstText(doc, SUBJECT_SELECTORS);
		const senderEl = firstElement(doc, SENDER_SELECTORS);
		const senderName = (senderEl?.getAttribute("name") ?? senderEl?.textContent ?? "").trim();
		const senderEmail = (senderEl?.getAttribute("email") ?? "").trim();
		const body = firstText(doc, BODY_SELECTORS);
		if (subject === "" && body === "") return {
			ok: false,
			reason: "no_content"
		};
		const entities = buildEntities(senderName, senderEmail);
		return {
			ok: true,
			context: {
				title: subject !== "" ? subject : doc.title.replace(/ - Gmail$/, "").trim(),
				body: snippet(body),
				entities: entities.map((e) => e.value),
				entity_refs: entities,
				source_url: url,
				deep_link: `https://mail.google.com/mail/u/${location.account}/#${location.view}/${location.threadId}`,
				platform_type: "gmail",
				timestamp: now,
				confidence: confidenceFor(subject, senderName || senderEmail, body),
				context_hash: fnv1a(`gmail:${location.threadId}`),
				extractor: gmailAdapter.id
			}
		};
	}
};
/** Gmail routes in the hash: `#<view>/<threadId>`, under `/mail/u/<account>/`. */
function parseGmailUrl(url) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return {
			account: "0",
			view: "inbox",
			threadId: null
		};
	}
	const account = /\/mail\/u\/(\d+)/.exec(parsed.pathname)?.[1] ?? "0";
	const segments = parsed.hash.replace(/^#/, "").split("/").filter((s) => s !== "");
	const view = segments[0] ?? "inbox";
	const last = segments[segments.length - 1];
	return {
		account,
		view,
		threadId: last !== void 0 && last !== view && THREAD_ID_PATTERN.test(last) ? last : null
	};
}
function listView(doc, url, now, location) {
	const title = doc.title.replace(/ - Gmail$/, "").trim();
	const entities = [{
		type: "domain",
		value: "mail.google.com"
	}];
	return {
		title: title !== "" ? title : "Gmail",
		body: "",
		entities: entities.map((e) => e.value),
		entity_refs: entities,
		source_url: url,
		deep_link: url,
		platform_type: "gmail",
		timestamp: now,
		confidence: .2,
		context_hash: fnv1a(`gmail:list:${location.account}:${location.view}`),
		extractor: "gmail-list@1"
	};
}
/**
* Confidence from completeness. A thread with subject, sender and body is the
* best signal ViSO gets anywhere; a partial read scores lower on purpose.
*/
function confidenceFor(subject, sender, body) {
	let score = .5;
	if (subject !== "") score += .2;
	if (sender !== "") score += .1;
	if (body.length >= 100) score += .15;
	return Math.min(.95, score);
}
function buildEntities(name, email) {
	const entities = [];
	if (name !== "") entities.push({
		type: "person",
		value: name
	});
	if (email !== "") {
		entities.push({
			type: "email",
			value: email
		});
		const domain = email.split("@")[1];
		if (domain !== void 0 && domain !== "") entities.push({
			type: "domain",
			value: domain
		});
	}
	return entities;
}
function firstElement(doc, selectors) {
	for (const selector of selectors) {
		const found = doc.querySelector(selector);
		if (found !== null) return found;
	}
	return null;
}
function firstText(doc, selectors) {
	return (firstElement(doc, selectors)?.textContent ?? "").replace(/\s+/g, " ").trim();
}
function snippet(text) {
	return text.length <= 1e3 ? text : `${text.slice(0, 1e3)}…`;
}
//#endregion
//#region src/content/extract/index.ts
/**
* Registration order is priority order (§5.3).
*
* Gmail first: it is the only adapter that reads the DOM, so it knows the
* sender and the body where the table-driven ones know only the address. The
* rest follow in table order, and none of their hosts overlap except Jira and
* Confluence, which separate on their path.
*/
var adapters = [gmailAdapter, ...urlAdapters()];
function findAdapter(url) {
	for (const adapter of adapters) try {
		if (adapter.matches(url)) return adapter;
	} catch {
		log.warn("adapter matcher threw", adapter.id);
	}
	return null;
}
/**
* Extracts context from the live document.
*
* The URL is sampled before and after: every target platform is an SPA, and a
* navigation mid-extraction would otherwise attribute this content to a page
* the user has already left (`stale_context`).
*/
function extractContext(doc = document, url = location.href, now = Date.now()) {
	const adapter = findAdapter(url);
	let result;
	try {
		result = adapter === null ? extractGenericContext(doc, url, now) : adapter.extractContext(doc, url, now);
	} catch {
		return {
			ok: false,
			reason: "extractor_threw"
		};
	}
	const href = currentHref();
	if (href !== null && href !== url) return {
		ok: false,
		reason: "stale_context"
	};
	return result;
}
/** Guarded so the router stays runnable outside a browser (tests, workers). */
function currentHref() {
	return typeof location === "undefined" ? null : location.href;
}
//#endregion
//#region src/content/ui/ContextCard.ts
/**
* Proactively surfaced memory (spec §8.2).
*
* Unlike the save-confirmation card, this one does NOT auto-dismiss: it appeared
* without being asked for, so it waits to be acknowledged rather than vanishing
* while the user is mid-sentence.
*
* The thumbs are not decoration — §11 lists a wrong relevance threshold as a
* top risk and asks for exactly this signal to tune it.
*/
var ContextCard = class {
	options;
	card;
	textEl;
	sourceEl;
	openBtn;
	current = null;
	mode = "surfaced";
	dismissTimer = null;
	titleEl;
	ratingEl;
	undoBtn;
	constructor(root, options) {
		this.options = options;
		this.card = el$5("div", "card");
		this.card.hidden = true;
		this.card.setAttribute("role", "status");
		const header = el$5("div", "card__header");
		const title = el$5("p", "card__title");
		title.textContent = "ViSO nhớ điều này";
		this.titleEl = title;
		const close = iconButton$1("×", "Bỏ qua");
		close.addEventListener("click", () => this.dismiss());
		header.append(title, close);
		this.textEl = el$5("p", "card__memory");
		this.sourceEl = el$5("p", "card__source");
		const actions = el$5("div", "card__actions");
		this.openBtn = button$1("Mở nguồn", "btn");
		this.openBtn.addEventListener("click", () => {
			const link = this.current?.deepLink;
			if (link !== null && link !== void 0 && link !== "") this.options.onOpenSource(link);
		});
		const up = iconButton$1("👍", "Đúng lúc");
		const down = iconButton$1("👎", "Không liên quan");
		up.addEventListener("click", () => this.rate(1));
		down.addEventListener("click", () => this.rate(-1));
		const rating = el$5("div", "card__rating");
		rating.append(up, down);
		this.ratingEl = rating;
		this.undoBtn = button$1("Hoàn tác", "btn");
		this.undoBtn.hidden = true;
		this.undoBtn.addEventListener("click", () => {
			const memory = this.current;
			this.hide();
			if (memory !== null) this.options.onUndo(memory.id);
		});
		actions.append(rating, this.undoBtn, this.openBtn);
		this.card.append(header, this.textEl, this.sourceEl, actions);
		root.append(this.card);
	}
	show(memory) {
		this.clearTimer();
		this.mode = "surfaced";
		this.titleEl.textContent = "ViSO nhớ điều này";
		this.ratingEl.hidden = false;
		this.undoBtn.hidden = true;
		this.current = memory;
		this.textEl.textContent = memory.text;
		this.sourceEl.textContent = describeSource(memory);
		this.openBtn.hidden = memory.deepLink === null || memory.deepLink === "";
		this.card.hidden = false;
	}
	/**
	* Save confirmation (§8.2): auto-dismisses after 4s.
	*
	* Auto-dismiss is correct here and wrong for a surfaced card — the user asked
	* for this one, so it is an acknowledgement, not an interruption.
	*/
	showSaved(memory) {
		this.clearTimer();
		this.mode = "saved";
		this.titleEl.textContent = memory.intent === void 0 ? "Đã lưu" : SAVED_LABELS[memory.intent];
		this.ratingEl.hidden = true;
		this.undoBtn.hidden = false;
		this.openBtn.hidden = true;
		this.current = memory;
		this.textEl.textContent = memory.text;
		const repeat = memory.repeat == null ? "" : `, ${REPEAT_LABELS[memory.repeat]}`;
		this.sourceEl.textContent = memory.remindAt !== null && memory.remindAt !== void 0 ? `Nhắc lúc ${formatWhen(memory.remindAt)}${repeat}` : describeSource(memory);
		this.card.hidden = false;
		this.dismissTimer = setTimeout(() => this.hide(), 4e3);
	}
	hide() {
		this.clearTimer();
		this.card.hidden = true;
		this.current = null;
	}
	clearTimer() {
		if (this.dismissTimer !== null) {
			clearTimeout(this.dismissTimer);
			this.dismissTimer = null;
		}
	}
	dismiss() {
		const memory = this.current;
		const mode = this.mode;
		this.hide();
		if (memory !== null && mode === "surfaced") this.options.onDismiss(memory.id);
	}
	/**
	* A thumbs-down is also a dismissal: telling ViSO this was irrelevant and
	* then having to close it separately would be one interaction too many.
	*/
	rate(feedback) {
		const memory = this.current;
		if (memory === null) return;
		this.options.onFeedback(memory.id, feedback);
		if (feedback === -1) this.dismiss();
		else this.hide();
	}
};
var SAVED_LABELS = {
	REMEMBER: "Đã ghi nhớ",
	TASK: "Đã thêm việc",
	REMINDER: "Đã đặt nhắc"
};
/** "20:30 hôm nay" / "15:00 ngày 08/09" — short enough for one line. */
function formatWhen(timestamp) {
	const at = new Date(timestamp);
	const clock = at.toLocaleTimeString("vi-VN", {
		hour: "2-digit",
		minute: "2-digit"
	});
	const today = /* @__PURE__ */ new Date();
	if (at.toDateString() === today.toDateString()) return `${clock} hôm nay`;
	const tomorrow = new Date(today.getTime() + 864e5);
	if (at.toDateString() === tomorrow.toDateString()) return `${clock} ngày mai`;
	return `${clock} ngày ${at.toLocaleDateString("vi-VN", {
		day: "2-digit",
		month: "2-digit"
	})}`;
}
function describeSource(memory) {
	const when = relativeDay(memory.createdAt);
	return memory.sourceTitle === null || memory.sourceTitle === "" ? when : `${memory.sourceTitle} · ${when}`;
}
function relativeDay(timestamp) {
	const days = Math.floor((Date.now() - timestamp) / 864e5);
	if (days <= 0) return "hôm nay";
	if (days === 1) return "hôm qua";
	if (days < 30) return `${days} ngày trước`;
	const months = Math.floor(days / 30);
	return months === 1 ? "1 tháng trước" : `${months} tháng trước`;
}
function el$5(tag, className) {
	const node = document.createElement(tag);
	node.className = className;
	return node;
}
function button$1(text, className) {
	const node = el$5("button", className);
	node.type = "button";
	node.textContent = text;
	return node;
}
function iconButton$1(glyph, label) {
	const node = el$5("button", "btn-icon");
	node.type = "button";
	node.textContent = glyph;
	node.setAttribute("aria-label", label);
	node.title = label;
	return node;
}
//#endregion
//#region src/content/ui/Coach.ts
/**
* The one-line explanations, in the order they become true.
*
* Each is shown once, and only at the moment it describes something the user
* has just done or is about to. A tour shown at install is a tour shown before
* any of it means anything — and this product is meant to be noticed as little
* as possible, so the budget for interrupting is small and spent late.
*/
var LESSONS = {
	welcome: {
		title: "ViSO đang chạy",
		body: "Trang nào đã có ghi chú, ViSO tự hiện ở mép phải. Mở ở bất kỳ trang nào bằng Ctrl+Shift+K (trên Mac: Control+Shift+Space) hoặc icon ViSO trên thanh công cụ. Ctrl+Space để nói, cần app ViSO trên máy tính."
	},
	saved: {
		title: "Đã lưu kèm nơi bạn đang đứng",
		body: "Lần sau quay lại trang này, ghi chú sẽ có sẵn trong panel. Nói kèm giờ thì ViSO tự đặt nhắc."
	},
	places: {
		title: "Ghi chú gắn với từng nơi",
		body: "Mỗi site có ghi chú riêng; Google Docs, Notion, Figma thì riêng từng file. Agent Hub xem được tất cả.",
		action: "Mở Agent Hub"
	}
};
/**
* A one-off explanation, in the corner, next to the thing it explains.
*
* Deliberately not a modal and not a tour: it sits where the dot is, says one
* sentence, and goes away for good. Anything longer would be teaching an
* interface that is three controls wide.
*/
var Coach = class {
	options;
	card;
	titleEl;
	bodyEl;
	actionBtn;
	current = null;
	timer = null;
	constructor(root, options) {
		this.options = options;
		this.card = el$4("div", "card coach");
		this.card.hidden = true;
		this.card.setAttribute("role", "status");
		const header = el$4("div", "card__header");
		this.titleEl = el$4("p", "card__title");
		const close = el$4("button", "btn-icon");
		close.type = "button";
		close.textContent = "×";
		close.setAttribute("aria-label", "Đã hiểu");
		close.addEventListener("click", () => this.finish());
		header.append(this.titleEl, close);
		this.bodyEl = el$4("p", "card__body");
		const actions = el$4("div", "card__actions");
		this.actionBtn = el$4("button", "btn");
		this.actionBtn.type = "button";
		this.actionBtn.hidden = true;
		this.actionBtn.addEventListener("click", () => {
			options.onOpenHub();
			this.finish();
		});
		const got = el$4("button", "btn btn--primary");
		got.type = "button";
		got.textContent = "Đã hiểu";
		got.addEventListener("click", () => this.finish());
		actions.append(this.actionBtn, got);
		this.card.append(header, this.bodyEl, actions);
		root.append(this.card);
	}
	show(step) {
		const lesson = LESSONS[step];
		this.current = step;
		this.titleEl.textContent = lesson.title;
		this.bodyEl.textContent = lesson.body;
		this.actionBtn.hidden = lesson.action === void 0;
		if (lesson.action !== void 0) this.actionBtn.textContent = lesson.action;
		this.card.hidden = false;
		this.clearTimer();
		this.timer = setTimeout(() => this.finish(), 12e3);
	}
	hide() {
		this.clearTimer();
		this.card.hidden = true;
	}
	finish() {
		const step = this.current;
		this.hide();
		this.current = null;
		if (step !== null) this.options.onDismiss(step);
	}
	clearTimer() {
		if (this.timer !== null) {
			clearTimeout(this.timer);
			this.timer = null;
		}
	}
};
function el$4(tag, className) {
	const node = document.createElement(tag);
	node.className = className;
	return node;
}
//#endregion
//#region src/content/ui/lang.ts
var DICT = {
	vi: {
		placeholder: "Ghi gì? @ chọn loại",
		search: "Tìm trong ghi chú ở đây",
		filter: "Lọc ghi chú",
		openHub: "Mở trang ViSO",
		settings: "Cài đặt",
		view: "Cách xem",
		mic: "Nói với Orb (Ctrl+Space)",
		save: "Lưu",
		unpickKind: "Bỏ chọn loại",
		pickKind: "Chọn loại: ghi chú, nhắc, việc",
		pickKindAria: "Chọn loại ghi chú",
		expand: "Mở rộng",
		collapse: "Thu gọn",
		noMatch: "Không có ghi chú nào khớp.",
		emptyHere: "Chưa có ghi chú nào ở đây — gõ bên dưới để lưu ghi chú đầu tiên.",
		empty: "Chưa có ghi chú nào — gõ bên dưới để lưu ghi chú đầu tiên.",
		all: "Tất cả",
		reminders: "Lời nhắc",
		tasks: "Việc",
		noGroup: "Không nhóm",
		groupNone: "Nhóm: không — bấm để chọn",
		groupNamed: (name) => `Nhóm: ${name} — bấm để đổi`,
		groupNewNone: "Ghi chú mới không vào nhóm nào — bấm để chọn",
		groupNewNamed: (name) => `Ghi chú mới vào nhóm ${name} — bấm để đổi`,
		viewTitle: "Ghi chú của",
		groupByTitle: "Gộp theo",
		thisPage: "Chỉ trang web này",
		allPages: "Tất cả trang web",
		groupNo: "Không gộp",
		groupKind: "Theo loại",
		groupGroup: "Theo nhóm",
		whenNewPage: "Xem trước",
		autoOpen: "Bật lên",
		autoTab: "Nút nhỏ",
		autoHint: "Lúc nào cũng gọi ra được bằng nút ViSO trên thanh công cụ, hoặc Ctrl+Shift+K.",
		language: "Ngôn ngữ",
		kindNote: "Ghi chú",
		kindReminder: "Lời nhắc",
		kindTask: "Việc",
		hintNote: "nhớ điều này về trang",
		hintReminder: "kèm giờ, ViSO sẽ báo",
		hintTask: "vào danh sách việc cần làm",
		more: "Xem thêm",
		less: "Thu gọn",
		openWhere: "Mở chỗ đã ghi",
		editOrDelete: "Sửa hoặc xoá",
		edit: "Sửa",
		remove: "Xoá",
		group: "Nhóm",
		addToGroup: "Thêm vào nhóm",
		inGroup: (name) => `Nhóm ${name} — bấm để đổi`,
		setDue: "Đặt giờ",
		dueHint: "vd: mai 9h, thứ 6 3h chiều, 30p nữa",
		dueAria: "Thời gian nhắc",
		dueSaved: "Đã đặt · đang cập nhật…",
		taskDone: "Xong việc",
		taskReopen: "Mở lại việc",
		justNow: "vừa xong",
		minutes: (n) => `${n} phút`,
		hours: (n) => `${n} giờ`,
		yesterday: "hôm qua",
		days: (n) => `${n} ngày`,
		today: "hôm nay",
		tomorrow: "mai",
		weekday: (d) => d === 0 ? "CN" : `T${d + 1}`,
		newGroup: "Nhóm mới",
		findOrCreate: "Tìm hoặc tạo nhóm",
		noGroupsYet: "Chưa có nhóm nào — bấm + để tạo.",
		noSuchGroup: "Chưa có nhóm này — bấm Tạo.",
		create: "Tạo",
		choose: "Chọn",
		notesCount: (n) => `${n} ghi chú`,
		pickDate: "Chọn ngày giờ",
		clearDate: "Bỏ",
		qToday: "Hôm nay",
		qTomorrow: "Mai",
		qNextWeek: "Tuần sau",
		timeLabel: "Giờ",
		months: [
			"Tháng 1",
			"Tháng 2",
			"Tháng 3",
			"Tháng 4",
			"Tháng 5",
			"Tháng 6",
			"Tháng 7",
			"Tháng 8",
			"Tháng 9",
			"Tháng 10",
			"Tháng 11",
			"Tháng 12"
		],
		dows: [
			"T2",
			"T3",
			"T4",
			"T5",
			"T6",
			"T7",
			"CN"
		],
		done: "Xong",
		seeAll: (n) => `Xem thêm (${n} ghi chú)`,
		appNotes: "Ghi chú",
		appSettings: "Cài đặt",
		appYourNotes: "Ghi chú của bạn",
		appUiLang: "Ngôn ngữ hiển thị",
		appSpeechLang: "Ngôn ngữ nói",
		appHelper: "Bộ nhận giọng",
		appCleanup: "Lọc âm thanh",
		appOff: "Tắt",
		appOn: "Bật",
		appLoadingModel: "Đang nạp mô hình…",
		appZipMissing: "Zipformer chưa được cài trên máy này.",
		appZipNeedsVi: "Zipformer cần ngôn ngữ nói là Tiếng Việt.",
		appVadLocked: "Đã cố định bởi ASR_VAD trong môi trường.",
		appNoDenoise: "Chưa cài bộ giảm ồn, nên chỉ cắt khoảng lặng.",
		appQuit: "Thoát ViSO",
		appQuitAgain: "Bấm lần nữa để thoát",
		appClose: "Đóng bảng ViSO",
		appNoLink: "Trình duyệt chưa kết nối — mở Chrome/Brave có ViSO rồi thử lại",
		appNotReady: "ViSO chưa sẵn sàng, thử lại sau một chút"
	},
	en: {
		placeholder: "Note something… @ to pick a kind",
		search: "Search notes here",
		filter: "Filter notes",
		openHub: "Open the ViSO page",
		settings: "Settings",
		view: "View",
		mic: "Talk to the Orb (Ctrl+Space)",
		save: "Save",
		unpickKind: "Clear the kind",
		pickKind: "Pick a kind: note, reminder, to-do",
		pickKindAria: "Pick the note kind",
		expand: "Expand",
		collapse: "Collapse",
		noMatch: "No notes match.",
		emptyHere: "Nothing here yet — type below to save the first note.",
		empty: "No notes yet — type below to save the first one.",
		all: "All",
		reminders: "Reminders",
		tasks: "To-dos",
		noGroup: "No group",
		groupNone: "Group: none — click to pick",
		groupNamed: (name) => `Group: ${name} — click to change`,
		groupNewNone: "New notes go in no group — click to pick",
		groupNewNamed: (name) => `New notes go in ${name} — click to change`,
		viewTitle: "Notes from",
		groupByTitle: "Group by",
		thisPage: "Only this site",
		allPages: "All sites",
		groupNo: "Nothing",
		groupKind: "Kind",
		groupGroup: "Group",
		whenNewPage: "Preview",
		autoOpen: "Pop up",
		autoTab: "Button",
		autoHint: "Always one click away on the ViSO toolbar button, or Ctrl+Shift+K.",
		language: "Language",
		kindNote: "Note",
		kindReminder: "Reminder",
		kindTask: "To-do",
		hintNote: "remember this about the page",
		hintReminder: "with a time, ViSO pings you",
		hintTask: "onto the to-do list",
		more: "More",
		less: "Less",
		openWhere: "Open where it was written",
		editOrDelete: "Edit or delete",
		edit: "Edit",
		remove: "Delete",
		group: "Group",
		addToGroup: "Add to a group",
		inGroup: (name) => `Group ${name} — click to change`,
		setDue: "Set a time",
		dueHint: "e.g. tomorrow 9am, friday 3pm, in 30 min",
		dueAria: "Reminder time",
		dueSaved: "Set · updating…",
		taskDone: "Mark done",
		taskReopen: "Reopen",
		justNow: "just now",
		minutes: (n) => `${n} min`,
		hours: (n) => `${n} h`,
		yesterday: "yesterday",
		days: (n) => `${n} d`,
		today: "today",
		tomorrow: "tomorrow",
		weekday: (d) => [
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		][d] ?? "",
		newGroup: "New group",
		findOrCreate: "Find or create a group",
		noGroupsYet: "No groups yet — press + to create one.",
		noSuchGroup: "No such group — press Create.",
		create: "Create",
		choose: "Choose",
		notesCount: (n) => `${n} ${n === 1 ? "note" : "notes"}`,
		pickDate: "Pick a date and time",
		clearDate: "Clear",
		qToday: "Today",
		qTomorrow: "Tomorrow",
		qNextWeek: "Next week",
		timeLabel: "Time",
		months: [
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December"
		],
		dows: [
			"Mo",
			"Tu",
			"We",
			"Th",
			"Fr",
			"Sa",
			"Su"
		],
		done: "Done",
		seeAll: (n) => `See more (${n} notes)`,
		appNotes: "Notes",
		appSettings: "Settings",
		appYourNotes: "Your notes",
		appUiLang: "Display language",
		appSpeechLang: "Speech language",
		appHelper: "Speech engine",
		appCleanup: "Clean up audio",
		appOff: "Off",
		appOn: "On",
		appLoadingModel: "Loading model…",
		appZipMissing: "Zipformer is not installed on this machine.",
		appZipNeedsVi: "Zipformer needs the speech language set to Tiếng Việt.",
		appVadLocked: "Fixed by ASR_VAD in the environment.",
		appNoDenoise: "Noise reduction is not installed, so this trims silence only.",
		appQuit: "Quit ViSO",
		appQuitAgain: "Click again to quit",
		appClose: "Close the ViSO panel",
		appNoLink: "The browser is not connected — open Chrome/Brave with ViSO and try again",
		appNotReady: "ViSO is not ready yet, try again in a moment"
	}
};
var current = "vi";
var listeners = /* @__PURE__ */ new Set();
function getLang() {
	return current;
}
function setLang(lang) {
	if (lang === current) return;
	current = lang;
	for (const listener of listeners) listener(lang);
}
/** What the browser speaks, for the first time. */
function browserLang() {
	const nav = typeof navigator === "undefined" ? "" : navigator.language;
	return /^vi/i.test(nav) ? "vi" : "en";
}
function t(key) {
	return DICT[current][key];
}
/** `flag` is SVG markup, for innerHTML of a span. */
var LANG_LABELS = {
	vi: {
		flag: "<svg viewBox=\"0 0 30 20\" width=\"20\" height=\"14\" aria-hidden=\"true\"><rect width=\"30\" height=\"20\" rx=\"2\" fill=\"#da251d\"/><path fill=\"#ff0\" d=\"m15 4 1.76 5.41h5.69l-4.6 3.35 1.76 5.41L15 14.82l-4.61 3.35 1.76-5.41-4.6-3.35h5.69z\"/></svg>",
		name: "Tiếng Việt"
	},
	en: {
		flag: "<svg viewBox=\"0 0 60 40\" width=\"20\" height=\"14\" aria-hidden=\"true\"><clipPath id=\"viso-fgb\"><rect width=\"60\" height=\"40\" rx=\"4\"/></clipPath><g clip-path=\"url(#viso-fgb)\"><rect width=\"60\" height=\"40\" fill=\"#012169\"/><path d=\"M0 0 60 40M60 0 0 40\" stroke=\"#fff\" stroke-width=\"8\"/><path d=\"M0 0 60 40M60 0 0 40\" stroke=\"#C8102E\" stroke-width=\"3\"/><path d=\"M30 0v40M0 20h60\" stroke=\"#fff\" stroke-width=\"12\"/><path d=\"M30 0v40M0 20h60\" stroke=\"#C8102E\" stroke-width=\"6\"/></g></svg>",
		name: "English"
	}
};
//#endregion
//#region src/content/ui/DatePicker.ts
var el$3 = (tag, cls) => {
	const node = document.createElement(tag);
	node.className = cls;
	return node;
};
var pad = (n) => String(n).padStart(2, "0");
var iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
var DatePicker = class {
	onPick;
	element;
	month;
	date;
	time;
	grid;
	title;
	clock;
	constructor(onPick, initial = null) {
		this.onPick = onPick;
		const now = /* @__PURE__ */ new Date();
		this.date = initial?.date ?? iso(now);
		this.time = initial?.time ?? "09:00";
		this.month = new Date(Number(this.date.slice(0, 4)), Number(this.date.slice(5, 7)) - 1, 1);
		this.element = el$3("div", "hud__cal");
		this.element.setAttribute("role", "dialog");
		this.element.setAttribute("aria-label", t("pickDate"));
		this.element.addEventListener("click", (event) => event.stopPropagation());
		this.element.addEventListener("keydown", (event) => event.stopPropagation());
		const quick = el$3("div", "hud__cal-quick");
		for (const [label, days] of [
			[t("qToday"), 0],
			[t("qTomorrow"), 1],
			[t("qNextWeek"), 7]
		]) {
			const b = el$3("button", "hud__cal-q");
			b.type = "button";
			b.textContent = label;
			b.addEventListener("click", () => {
				const d = /* @__PURE__ */ new Date();
				d.setDate(d.getDate() + days);
				this.setDate(iso(d));
			});
			quick.append(b);
		}
		const head = el$3("div", "hud__cal-head");
		const prev = el$3("button", "hud__cal-nav");
		prev.type = "button";
		prev.append(icon("chevronLeft", 16));
		const next = el$3("button", "hud__cal-nav");
		next.type = "button";
		next.append(icon("chevronRight", 16));
		this.title = el$3("span", "hud__cal-title");
		prev.addEventListener("click", () => {
			this.month = new Date(this.month.getFullYear(), this.month.getMonth() - 1, 1);
			this.render();
		});
		next.addEventListener("click", () => {
			this.month = new Date(this.month.getFullYear(), this.month.getMonth() + 1, 1);
			this.render();
		});
		head.append(prev, this.title, next);
		const dows = el$3("div", "hud__cal-dows");
		for (const d of t("dows")) {
			const s = el$3("span", "");
			s.textContent = d;
			dows.append(s);
		}
		this.grid = el$3("div", "hud__cal-grid");
		const foot = el$3("div", "hud__cal-foot");
		const clockLabel = el$3("label", "hud__cal-clock");
		clockLabel.append(document.createTextNode(t("timeLabel")));
		this.clock = el$3("input", "hud__cal-time");
		this.clock.type = "time";
		this.clock.value = this.time;
		this.clock.addEventListener("change", () => {
			if (this.clock.value) this.time = this.clock.value;
		});
		clockLabel.append(this.clock);
		const clear = el$3("button", "hud__cal-clear");
		clear.type = "button";
		clear.textContent = t("clearDate");
		clear.addEventListener("click", () => this.onPick(null));
		const done = el$3("button", "btn btn--primary hud__cal-done");
		done.type = "button";
		done.textContent = t("done");
		done.addEventListener("click", () => this.onPick({
			date: this.date,
			time: this.time
		}));
		foot.append(clockLabel, clear, done);
		this.element.append(quick, head, dows, this.grid, foot);
		this.render();
	}
	setDate(date) {
		this.date = date;
		this.month = new Date(Number(date.slice(0, 4)), Number(date.slice(5, 7)) - 1, 1);
		this.render();
	}
	render() {
		this.title.textContent = `${t("months")[this.month.getMonth()] ?? ""} ${this.month.getFullYear()}`;
		this.grid.replaceChildren();
		const today = iso(/* @__PURE__ */ new Date());
		const lead = (this.month.getDay() + 6) % 7;
		const days = new Date(this.month.getFullYear(), this.month.getMonth() + 1, 0).getDate();
		for (let i = 0; i < lead; i++) this.grid.append(el$3("span", "hud__cal-pad"));
		for (let d = 1; d <= days; d++) {
			const b = el$3("button", "hud__cal-day");
			b.type = "button";
			const value = `${this.month.getFullYear()}-${pad(this.month.getMonth() + 1)}-${pad(d)}`;
			b.textContent = String(d);
			if (value === today) b.classList.add("hud__cal-day--today");
			if (value === this.date) b.classList.add("hud__cal-day--on");
			if (value < today) b.classList.add("hud__cal-day--past");
			b.addEventListener("click", () => {
				this.date = value;
				this.render();
			});
			this.grid.append(b);
		}
	}
};
/**
* The comparison key for a name.
*
* Accents and case are folded because the same group gets typed both ways —
* "Khách hàng A" in the menu, "khach hang a" in a hurry — and two groups that
* differ only by a tone mark are one group with a typo, not two.
*/
function foldGroupName(name) {
	return name.normalize("NFD").replace(/\p{M}/gu, "").replace(/đ/gi, "d").toLowerCase().replace(/\s+/g, " ").trim();
}
/** Trimmed and single-spaced, or null when empty or too long to show on a chip. */
function normalizeGroupName(raw) {
	const name = raw.normalize("NFC").replace(/\s+/g, " ").trim();
	if (name === "" || [...name].length > 40) return null;
	return name;
}
var PREPOSITIONS = /* @__PURE__ */ new Set([
	"vao",
	"trong",
	"cho",
	"thuoc"
]);
var TRAILING_PUNCTUATION = /[:,.;!?]+$/u;
/**
* Finds "vào nhóm X" in a sentence, for a group that already exists.
*
* Only existing groups: speech recognition mishears names, and a sentence must
* never quietly create a group called whatever it misheard.
*
* Only with a preposition ("vào/trong/cho/thuộc nhóm X") or as a heading at the
* very start ("Nhóm X: …"). "Họp nhóm dự án" is a meeting, not a filing
* instruction, and without that rule a group named "dự án" would eat the words.
* The longest matching group wins, so "Khách hàng A" beats "Khách hàng".
*
* Returns the group and the sentence with the instruction taken out.
*/
function matchGroupCue(text, groups) {
	const words = text.trim().split(/\s+/).filter(Boolean);
	if (words.length === 0 || groups.length === 0) return null;
	const folded = words.map((word) => foldGroupName(word.replace(TRAILING_PUNCTUATION, "")));
	const candidates = groups.map((group) => ({
		group,
		parts: foldGroupName(group.name).split(" ")
	})).sort((a, b) => b.parts.length - a.parts.length);
	for (let i = 0; i < words.length; i++) {
		if (folded[i] !== "nhom") continue;
		const atStart = i === 0;
		const afterPreposition = i > 0 && PREPOSITIONS.has(folded[i - 1]);
		if (!atStart && !afterPreposition) continue;
		const cueStart = atStart ? 0 : i - 1;
		const nameStart = i + 1;
		for (const { group, parts } of candidates) {
			if (nameStart + parts.length > words.length) continue;
			if (!parts.every((part, k) => folded[nameStart + k] === part)) continue;
			const end = nameStart + parts.length;
			if (atStart && end < words.length && !TRAILING_PUNCTUATION.test(words[end - 1])) continue;
			return {
				group,
				text: [...words.slice(0, cueStart), ...words.slice(end)].join(" ").replace(/^[\s:,.;-]+/u, "").trim()
			};
		}
	}
	return null;
}
//#endregion
//#region src/content/ui/GroupMenu.ts
/**
* Choosing a group, or making one, in place.
*
* Inline in the HUD rather than floating over the page: a popover positioned
* against somebody else's layout is one more thing their CSS can break, and the
* HUD already knows how to scroll.
*
* The list first, and a "+" row under it; pressing that reveals the field,
* which both narrows the list and creates. A name that already exists — in any
* accent or case — is picked rather than created, because the store would hand
* that group back anyway, and a button saying "Tạo" for something that is not
* created would be lying.
*/
var GroupMenu = class {
	options;
	element;
	list;
	input;
	submitBtn;
	addBtn;
	create;
	errorEl;
	groups;
	busy = false;
	listeners = [];
	constructor(options) {
		this.options = options;
		this.groups = [...options.groups];
		this.element = el$2("div", "hud__menu");
		this.element.setAttribute("role", "group");
		this.element.setAttribute("aria-label", t("findOrCreate"));
		this.list = el$2("div", "hud__menu-list");
		this.list.setAttribute("role", "menu");
		this.addBtn = el$2("button", "hud__menu-add");
		this.addBtn.type = "button";
		this.addBtn.append(icon("plus", 15), document.createTextNode(t("newGroup")));
		this.addBtn.addEventListener("click", () => this.showCreate());
		this.create = el$2("div", "hud__menu-create");
		this.create.hidden = true;
		const create = this.create;
		this.input = el$2("input", "hud__menu-input");
		this.input.type = "text";
		this.input.placeholder = t("findOrCreate");
		this.input.setAttribute("aria-label", t("findOrCreate"));
		this.input.autocomplete = "off";
		this.input.spellcheck = false;
		this.input.addEventListener("input", () => {
			this.errorEl.hidden = true;
			this.render();
		});
		this.input.addEventListener("keydown", (event) => {
			if (event.key !== "Enter") return;
			event.preventDefault();
			this.submit();
		});
		this.submitBtn = el$2("button", "btn btn--primary hud__menu-submit");
		this.submitBtn.type = "button";
		this.submitBtn.addEventListener("click", () => void this.submit());
		create.append(this.input, this.submitBtn);
		this.errorEl = el$2("p", "hud__menu-error");
		this.errorEl.setAttribute("role", "alert");
		this.errorEl.hidden = true;
		this.element.append(this.list, this.addBtn, create, this.errorEl);
		this.element.addEventListener("keydown", (event) => {
			if (event.key === "Escape") {
				event.preventDefault();
				this.options.onClose();
			} else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
				event.preventDefault();
				this.moveFocus(event.key === "ArrowDown" ? 1 : -1);
			}
		});
		for (const type of [
			"keydown",
			"keypress",
			"keyup"
		]) this.element.addEventListener(type, (event) => event.stopPropagation());
		this.element.addEventListener("click", (event) => event.stopPropagation());
		this.render();
	}
	/** Puts the menu in the document, starts listening for presses outside it, and focuses the field. */
	mount(place) {
		place(this.element);
		const root = this.element.getRootNode();
		const onPress = (event) => {
			const path = event.composedPath();
			if (path.includes(this.element) || path.includes(this.options.anchor)) return;
			if (event.currentTarget === document && root !== document && event.target === root.host) return;
			this.options.onClose();
		};
		const targets = root === document ? [document] : [root, document];
		for (const target of targets) {
			target.addEventListener("pointerdown", onPress, true);
			this.listeners.push([target, onPress]);
		}
		this.list.querySelector(".hud__menu-item")?.focus();
	}
	/** Reveals the field for a new group's name, and puts the cursor in it. */
	showCreate() {
		this.addBtn.hidden = true;
		this.create.hidden = false;
		this.input.focus();
	}
	destroy() {
		for (const [target, listener] of this.listeners) target.removeEventListener("pointerdown", listener, true);
		this.listeners = [];
		this.element.remove();
	}
	render() {
		const needle = foldGroupName(this.input.value);
		const items = [];
		if (needle === "") {
			items.push(this.item(null, t("noGroup"), null));
			for (const group of this.groups) items.push(this.item(group.id, group.name, group.count));
			if (this.groups.length === 0) items.push(note(t("noGroupsYet")));
		} else {
			const matches = this.groups.filter((group) => foldGroupName(group.name).includes(needle));
			for (const group of matches) items.push(this.item(group.id, group.name, group.count));
			if (matches.length === 0) items.push(note(t("noSuchGroup")));
		}
		this.list.replaceChildren(...items);
		const exact = needle === "" ? void 0 : this.groups.find((group) => foldGroupName(group.name) === needle);
		this.submitBtn.textContent = exact === void 0 ? t("create") : t("choose");
		this.submitBtn.disabled = this.busy || needle === "";
	}
	item(id, name, count) {
		const node = el$2("button", "hud__menu-item");
		node.type = "button";
		node.setAttribute("role", "menuitemradio");
		const checked = id === this.options.selected;
		node.setAttribute("aria-checked", String(checked));
		const mark = el$2("span", "hud__menu-check");
		if (checked) mark.append(icon("check", 14));
		const label = el$2("span", "hud__menu-name");
		label.textContent = name;
		node.append(mark, label);
		if (count !== null) {
			const counter = el$2("span", "hud__menu-count");
			counter.textContent = String(count);
			node.append(counter);
		}
		node.addEventListener("click", () => this.options.onPick(id));
		return node;
	}
	async submit() {
		if (this.busy || this.input.value.trim() === "") return;
		const name = normalizeGroupName(this.input.value);
		if (name === null) {
			this.showError(`Tên nhóm dài tối đa 40 ký tự.`);
			return;
		}
		const existing = this.groups.find((group) => foldGroupName(group.name) === foldGroupName(name));
		if (existing !== void 0) {
			this.options.onPick(existing.id);
			return;
		}
		this.busy = true;
		this.input.disabled = true;
		this.render();
		const result = await this.options.onCreate(name).catch((error) => error instanceof Error ? error.message : String(error));
		this.busy = false;
		if (!this.element.isConnected) return;
		this.input.disabled = false;
		if (typeof result === "string") {
			this.render();
			this.showError(result);
			this.input.focus();
			return;
		}
		this.options.onPick(result.id);
	}
	showError(message) {
		this.errorEl.textContent = message;
		this.errorEl.hidden = false;
	}
	moveFocus(step) {
		const targets = [...this.list.querySelectorAll(".hud__menu-item"), this.input];
		const scope = this.element.getRootNode();
		const current = targets.indexOf(scope.activeElement);
		targets[current === -1 ? step > 0 ? 0 : targets.length - 1 : (current + step + targets.length) % targets.length]?.focus();
	}
};
function note(text) {
	const node = el$2("p", "hud__menu-empty");
	node.textContent = text;
	return node;
}
function el$2(tag, className) {
	const node = document.createElement(tag);
	node.className = className;
	return node;
}
//#endregion
//#region src/content/ui/PlaceNotes.ts
/**
* The notes of one place, in the HUD.
*
* ## What a click does
*
* A note written somewhere else on this site — another Gmail thread, another
* Google Doc — still goes there: that is the reason to click it. A note written
* on the page already open does not. It used to, and on Google Docs, which opens
* documents in a new tab, clicking a note opened a second copy of the document
* the user was reading. So "same page" opens the note in place instead: its full
* text, the passage it quotes, and exactly when it was written.
*
* "Same page" is the same context hash, or the same URL — compared without the
* query string, which apps fill with tracking and view state, but with the
* fragment, which is where Gmail keeps the thread.
*
* ## No ellipsis
*
* A note cut at "…" hides the part that was worth writing down. Rows show up to
* three lines, fade the rest out instead of cutting it, and offer "Xem thêm"
* only when there is more to see — measured, not guessed from character counts.
*/
var PlaceNotes = class {
	options;
	root;
	list;
	moreBtn;
	currentContextHash = null;
	currentUrl = null;
	/**
	* One observer for every row's text, re-armed on each render.
	*
	* Overflow can only be measured once the text has a layout, and the list is
	* often built while the HUD is hidden or collapsed — so the measurement waits
	* for the size to change rather than being taken at render time, when it
	* would read zero and never offer "Xem thêm".
	*/
	overflowObserver;
	syncers = /* @__PURE__ */ new WeakMap();
	/** Rows with a second overflow reading pending. */
	settling = /* @__PURE__ */ new WeakSet();
	constructor(parent, options) {
		this.options = options;
		this.root = el$1("div", "hud__notes");
		this.list = el$1("div", "hud__list");
		this.list.setAttribute("role", "list");
		this.moreBtn = el$1("button", "hud__more");
		this.moreBtn.type = "button";
		this.moreBtn.hidden = true;
		this.moreBtn.addEventListener("click", () => options.onOpenAll());
		this.overflowObserver = typeof ResizeObserver === "undefined" ? null : new ResizeObserver((entries) => {
			for (const entry of entries) {
				const row = entry.target.closest(".hud__row");
				if (row !== null) this.measure(row);
			}
		});
		this.root.append(this.list, this.moreBtn);
		parent.append(this.root);
		this.list.addEventListener("click", (event) => {
			if (event.target?.closest(".hud__actions") !== null) return;
			for (const menu of this.list.querySelectorAll(".hud__row-menu")) menu.hidden = true;
			for (const btn of this.list.querySelectorAll(".hud__menu-btn")) btn.setAttribute("aria-expanded", "false");
			this.list.classList.remove("hud__list--menu-room");
		});
	}
	/** Which page the user is on, to tell a note written here from one written elsewhere. */
	setCurrentContext(contextHash, url = null) {
		this.currentContextHash = contextHash;
		this.currentUrl = url;
	}
	renderAll(notes, total, highlightId = null, emptyText = t("empty"), groupBy = "none") {
		this.root.hidden = false;
		this.renderRows(notes, highlightId, emptyText, groupBy);
		const remaining = total - notes.length;
		this.moreBtn.hidden = remaining <= 0;
		if (!this.moreBtn.hidden) this.moreBtn.textContent = t("seeAll")(total);
	}
	hide() {
		this.root.hidden = true;
	}
	renderRows(notes, highlightId, emptyText, groupBy) {
		this.overflowObserver?.disconnect();
		if (notes.length === 0) {
			const empty = el$1("p", "hud__empty");
			empty.textContent = emptyText;
			this.list.replaceChildren(empty);
			return;
		}
		if (groupBy === "none") this.list.replaceChildren(...notes.map((note) => this.row(note, highlightId)));
		else {
			const keyOf = (note) => groupBy === "kind" ? labelOfKind(note.intent) : (note.groupName ?? "").trim() || t("noGroup");
			const sections = /* @__PURE__ */ new Map();
			for (const note of notes) {
				const key = keyOf(note);
				const bucket = sections.get(key);
				if (bucket === void 0) sections.set(key, [note]);
				else bucket.push(note);
			}
			const nodes = [];
			for (const [name, bucket] of sections) {
				const heading = el$1("p", "hud__section");
				heading.textContent = `${name} · ${bucket.length}`;
				nodes.push(heading, ...bucket.map((note) => this.row(note, highlightId)));
			}
			this.list.replaceChildren(...nodes);
		}
		if (this.overflowObserver !== null) for (const title of this.list.querySelectorAll(".hud__title")) this.overflowObserver.observe(title);
	}
	row(note, highlightId) {
		const row = el$1("div", "hud__row");
		row.setAttribute("role", "listitem");
		if (note.id === highlightId) {
			row.classList.add("hud__row--highlight", "hud__row--expanded");
			requestAnimationFrame(() => row.scrollIntoView({ block: "nearest" }));
		}
		const kind = tileKind(note);
		const done = note.intent === "TASK" && note.doneAt != null;
		if (done) row.classList.add("hud__row--done");
		const tile = note.intent === "TASK" ? el$1("button", `hud__tile hud__tile--${kind} hud__check`) : el$1("span", `hud__tile hud__tile--${kind}`);
		if (note.intent === "TASK") {
			const box = tile;
			box.type = "button";
			box.setAttribute("role", "checkbox");
			box.setAttribute("aria-checked", String(done));
			box.title = done ? t("taskReopen") : t("taskDone");
			box.append(icon("check", 16));
			box.addEventListener("click", (event) => {
				event.stopPropagation();
				const next = !row.classList.contains("hud__row--done");
				row.classList.toggle("hud__row--done", next);
				box.setAttribute("aria-checked", String(next));
				this.options.onSetDone(note.id, next).then((error) => {
					if (error === null) return;
					row.classList.toggle("hud__row--done", !next);
					box.setAttribute("aria-checked", String(!next));
				});
			});
		} else {
			tile.setAttribute("aria-hidden", "true");
			tile.append(icon(TILE_ICONS[kind], 18));
		}
		const favicon = (note.favicon ?? "").trim();
		let tileSlot = tile;
		if (favicon !== "") {
			const wrap = el$1("span", "hud__tile-wrap");
			const badge = el$1("img", "hud__tile-badge");
			badge.src = favicon;
			badge.alt = "";
			badge.draggable = false;
			badge.addEventListener("error", () => badge.remove());
			wrap.append(tile, badge);
			tileSlot = wrap;
		}
		const head = el$1("div", "hud__head");
		const body = el$1("div", "hud__body");
		const title = el$1("p", "hud__title");
		title.textContent = note.text;
		const meta = el$1("p", "hud__meta");
		const kindLabel = el$1("span", "hud__kind");
		kindLabel.textContent = labelOfKind(note.intent);
		const dot = el$1("span", "hud__sep");
		dot.textContent = "·";
		const when = el$1("span", "hud__time");
		when.textContent = relativeTime(note.createdAt);
		const line = el$1("span", "hud__meta-line");
		line.append(kindLabel, dot, when);
		meta.append(line);
		const changeGroup = this.options.onChangeGroup;
		const groupName = (note.groupName ?? "").trim();
		if (groupName !== "" || changeGroup !== void 0) {
			const slot = el$1("span", groupName === "" ? "hud__group-slot hud__group-slot--empty" : "hud__group-slot");
			const groupSep = el$1("span", "hud__sep");
			groupSep.textContent = "·";
			slot.append(groupSep);
			if (changeGroup === void 0) {
				const label = el$1("span", "hud__group");
				label.textContent = groupName;
				slot.append(label);
			} else {
				const pick = el$1("button", groupName === "" ? "hud__group hud__group--empty" : "hud__group");
				pick.type = "button";
				pick.textContent = groupName === "" ? `+ ${t("group")}` : groupName;
				const hint = groupName === "" ? t("addToGroup") : t("inGroup")(groupName);
				pick.title = hint;
				pick.setAttribute("aria-label", hint);
				pick.setAttribute("aria-haspopup", "menu");
				pick.setAttribute("aria-expanded", "false");
				pick.addEventListener("click", (event) => {
					event.stopPropagation();
					changeGroup(note, body, pick);
				});
				slot.append(pick);
			}
			meta.append(slot);
		}
		const details = el$1("div", "hud__details");
		const quote = (note.selection ?? "").trim();
		if (quote !== "") {
			const quoted = el$1("p", "hud__quote");
			quoted.textContent = quote;
			details.append(quoted);
		}
		const where = (note.sourceTitle ?? "").trim();
		if (where !== "") {
			const stamp = el$1("p", "hud__stamp");
			stamp.textContent = where;
			stamp.title = where;
			details.append(stamp);
		}
		const more = el$1("button", "hud__more-toggle");
		more.type = "button";
		body.append(title, details, more);
		if (note.intent === "REMINDER" || note.intent === "TASK") body.append(this.dueLine(note));
		const sync = () => {
			const expanded = row.classList.contains("hud__row--expanded");
			const overflowing = row.classList.contains("hud__row--overflow");
			details.hidden = !expanded;
			more.hidden = !(expanded || overflowing || quote !== "" || where !== "");
			more.textContent = expanded ? t("less") : t("more");
			more.setAttribute("aria-expanded", String(expanded));
		};
		this.syncers.set(row, sync);
		const toggle = () => {
			row.classList.toggle("hud__row--expanded");
			sync();
			if (!row.classList.contains("hud__row--expanded")) requestAnimationFrame(() => this.measure(row));
		};
		more.addEventListener("click", (event) => {
			event.stopPropagation();
			toggle();
		});
		const link = note.deepLink ?? "";
		const elsewhere = link !== "" && !this.isHere(note, link);
		if (elsewhere) {
			row.classList.add("hud__row--elsewhere");
			body.title = t("openWhere");
		}
		body.addEventListener("click", (event) => {
			if (row.classList.contains("hud__row--editing")) return;
			if (event.target?.closest("button, a, textarea, input, .hud__menu") != null) return;
			if (elsewhere) {
				this.options.onOpenNote(link, note.id, note.openInNewTab === true);
				return;
			}
			toggle();
		});
		sync();
		const actions = el$1("div", "hud__actions");
		const moreBtn = el$1("button", "hud__menu-btn");
		moreBtn.type = "button";
		moreBtn.title = t("editOrDelete");
		moreBtn.setAttribute("aria-label", t("editOrDelete"));
		moreBtn.setAttribute("aria-haspopup", "menu");
		moreBtn.setAttribute("aria-expanded", "false");
		moreBtn.append(icon("more", 20));
		const menu = el$1("div", "hud__row-menu");
		menu.setAttribute("role", "menu");
		menu.hidden = true;
		const setOpen = (open) => {
			menu.hidden = !open;
			row.classList.toggle("hud__row--menu-open", open);
			moreBtn.setAttribute("aria-expanded", String(open));
			if (!open) this.list.classList.remove("hud__list--menu-room");
		};
		moreBtn.addEventListener("click", (event) => {
			event.stopPropagation();
			const opening = menu.hidden;
			for (const other of this.list.querySelectorAll(".hud__row-menu")) other.hidden = true;
			for (const other of this.list.querySelectorAll(".hud__row--menu-open")) other.classList.remove("hud__row--menu-open");
			for (const other of this.list.querySelectorAll(".hud__menu-btn")) other.setAttribute("aria-expanded", "false");
			const list = this.list.getBoundingClientRect();
			const button = moreBtn.getBoundingClientRect();
			const below = list.bottom - button.bottom;
			const above = button.top - list.top;
			const up = below < MENU_HEIGHT && above >= MENU_HEIGHT;
			menu.classList.toggle("hud__row-menu--up", up);
			this.list.classList.toggle("hud__list--menu-room", opening && !up && below < MENU_HEIGHT);
			setOpen(opening);
		});
		if (changeGroup !== void 0) {
			const tag = actionButton("tag", t("group"));
			tag.classList.add("hud__action--group");
			tag.addEventListener("click", (event) => {
				event.stopPropagation();
				setOpen(false);
				changeGroup(note, body, moreBtn);
			});
			menu.append(tag);
		}
		const edit = actionButton("pencil", t("edit"));
		edit.addEventListener("click", (event) => {
			event.stopPropagation();
			setOpen(false);
			this.beginEdit(row, title, note);
		});
		const remove = actionButton("trash", t("remove"), "hud__action--danger");
		remove.addEventListener("click", (event) => {
			event.stopPropagation();
			row.remove();
			this.options.onDelete(note.id);
		});
		menu.append(edit, remove);
		actions.append(moreBtn, menu);
		head.append(tileSlot, meta, actions);
		row.append(head, body, comet(72, "down-left", "hud__comet"));
		return row;
	}
	/** True when the note was written on the page already open — nowhere to go. */
	isHere(note, link) {
		if (note.contextHash != null && note.contextHash === this.currentContextHash) return true;
		return samePage(link, this.currentUrl);
	}
	/** The time line under a reminder or to-do, and the way to change it. */
	dueLine(note) {
		const line = el$1("div", "hud__due");
		const due = typeof note.remindAt === "number" ? note.remindAt : null;
		const btn = el$1("button", "hud__due-btn");
		btn.type = "button";
		if (due === null) {
			btn.classList.add("hud__due-btn--unset");
			btn.append(icon("bell", 13), document.createTextNode(t("setDue")));
		} else {
			btn.append(icon("bell", 13), document.createTextNode(dueLabel(due)));
			btn.title = new Date(due).toLocaleString("vi-VN");
			if (due < Date.now()) line.classList.add("hud__due--past");
		}
		btn.addEventListener("click", (event) => {
			event.stopPropagation();
			if (line.querySelector(".hud__cal") !== null) return;
			const err = el$1("span", "hud__due-err");
			const initial = due === null ? null : {
				date: isoDate(new Date(due)),
				time: clock(new Date(due))
			};
			let closeOnOutside = null;
			const row = line.closest(".hud__row");
			const list = row?.parentElement ?? null;
			const root = line.getRootNode();
			const targets = root === document ? [document] : [root, document];
			const close = () => {
				picker.element.remove();
				err.remove();
				row?.classList.remove("hud__row--menu-open");
				list?.classList.remove("hud__list--cal-room");
				if (closeOnOutside !== null) for (const target of targets) target.removeEventListener("pointerdown", closeOnOutside, true);
			};
			const picker = new DatePicker((picked) => {
				this.options.onSetDue(note.id, picked).then((error) => {
					if (error !== null) {
						err.textContent = error;
						line.append(err);
						return;
					}
					btn.replaceChildren(icon("bell", 13), document.createTextNode(picked === null ? t("setDue") : t("dueSaved")));
					close();
				});
			}, initial);
			picker.element.classList.add("hud__cal--due");
			if (row !== null && list !== null && row.offsetLeft > list.clientWidth / 2) picker.element.classList.add("hud__cal--due-right");
			line.append(picker.element);
			row?.classList.add("hud__row--menu-open");
			list?.classList.add("hud__list--cal-room");
			row?.scrollIntoView({ block: "nearest" });
			closeOnOutside = (e) => {
				const path = e.composedPath();
				if (path.includes(picker.element) || path.includes(btn)) return;
				if (e.currentTarget === document && root !== document && e.target === root.host) return;
				close();
			};
			for (const target of targets) target.addEventListener("pointerdown", closeOnOutside, true);
		});
		line.append(btn);
		return line;
	}
	/** Marks a collapsed row as overflowing its three lines, or not. */
	measure(row) {
		if (!row.isConnected || row.classList.contains("hud__row--expanded")) return;
		const title = row.querySelector(".hud__title");
		if (title === null) return;
		const overflowing = title.scrollHeight > title.clientHeight + 1;
		row.classList.toggle("hud__row--overflow", overflowing);
		this.syncers.get(row)?.();
		if (overflowing && !this.settling.has(row)) {
			this.settling.add(row);
			window.setTimeout(() => {
				this.settling.delete(row);
				if (!row.isConnected || row.classList.contains("hud__row--expanded")) return;
				row.classList.toggle("hud__row--overflow", title.scrollHeight > title.clientHeight + 1);
				this.syncers.get(row)?.();
			}, 400);
		}
	}
	/**
	* Turns a row's text into a textarea over itself.
	*
	* In place rather than in the composer: the composer is where new notes are
	* written, and borrowing it to edit an old one invites the edit being saved
	* as a second note.
	*/
	beginEdit(row, title, note) {
		if (row.classList.contains("hud__row--editing")) return;
		row.classList.add("hud__row--editing");
		const editor = document.createElement("textarea");
		editor.className = "hud__editor";
		editor.value = note.text;
		editor.rows = Math.min(8, Math.max(2, Math.ceil(note.text.length / 34)));
		title.replaceWith(editor);
		editor.focus();
		editor.setSelectionRange(editor.value.length, editor.value.length);
		let done = false;
		const finish = (newText) => {
			done = true;
			row.classList.remove("hud__row--editing");
			if (newText !== null) {
				note.text = newText;
				title.textContent = newText;
			}
			editor.replaceWith(title);
			requestAnimationFrame(() => this.measure(row));
		};
		for (const type of [
			"keydown",
			"keypress",
			"keyup"
		]) editor.addEventListener(type, (event) => event.stopPropagation());
		editor.addEventListener("click", (event) => event.stopPropagation());
		const commit = () => {
			if (done) return;
			const next = editor.value.trim();
			if (next === "" || next === note.text) {
				finish(null);
				return;
			}
			editor.disabled = true;
			this.options.onEdit(note.id, next).then((error) => {
				finish(error === null ? next : null);
				if (error !== null) row.title = error;
			});
		};
		editor.addEventListener("keydown", (event) => {
			if (event.key === "Escape") {
				event.preventDefault();
				finish(null);
				return;
			}
			if (event.key === "Enter" && !event.shiftKey) {
				event.preventDefault();
				commit();
			}
		});
		editor.addEventListener("blur", () => {
			if (!done && row.isConnected) commit();
		});
	}
};
/** The ··· menu's height with its two items, for deciding which way it opens. */
var MENU_HEIGHT = 96;
/** The words beside the time, so the kind is said as well as drawn. */
function labelOfKind(intent) {
	return intent === "TASK" ? t("kindTask") : intent === "REMINDER" ? t("kindReminder") : t("kindNote");
}
var TILE_ICONS = {
	note: "note",
	reminder: "bell",
	task: "task",
	quote: "quote"
};
/** Reminder and task outrank a quote: when it fires matters more than what it cites. */
function tileKind(note) {
	if (note.intent === "REMINDER") return "reminder";
	if (note.intent === "TASK") return "task";
	if ((note.selection ?? "").trim() !== "") return "quote";
	return "note";
}
function actionButton(name, label, extra = "") {
	const node = el$1("button", `hud__action ${extra}`.trim());
	node.type = "button";
	node.setAttribute("role", "menuitem");
	node.append(icon(name, 15), document.createTextNode(label));
	return node;
}
/** Short — "3 giờ", not "3 giờ trước": it shares one line with the kind, on a card half the panel wide. */
/** "hôm nay 09:00", "mai 09:00", "T6 09:00", "20/10 09:00". */
function dueLabel(at) {
	const d = new Date(at);
	const hhmm = `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
	const today = /* @__PURE__ */ new Date();
	today.setHours(0, 0, 0, 0);
	const days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - today.getTime()) / 864e5);
	if (days === 0) return `${t("today")} ${hhmm}`;
	if (days === 1) return `${t("tomorrow")} ${hhmm}`;
	if (days > 1 && days < 7) return `${t("weekday")(d.getDay())} ${hhmm}`;
	return `${d.getDate()}/${d.getMonth() + 1} ${hhmm}`;
}
function relativeTime(timestamp) {
	const minutes = Math.floor((Date.now() - timestamp) / 6e4);
	if (minutes < 1) return t("justNow");
	if (minutes < 60) return t("minutes")(minutes);
	const hours = Math.floor(minutes / 60);
	if (hours < 24) return t("hours")(hours);
	const days = Math.floor(hours / 24);
	if (days === 1) return t("yesterday");
	if (days < 30) return t("days")(days);
	return `${Math.floor(days / 30)} tháng`;
}
function el$1(tag, className) {
	const node = document.createElement(tag);
	node.className = className;
	return node;
}
var two = (n) => String(n).padStart(2, "0");
var isoDate = (d) => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
var clock = (d) => `${two(d.getHours())}:${two(d.getMinutes())}`;
//#endregion
//#region src/content/ui/QuickActionsPanel.ts
/**
* The HUD: this place's notes, on the right edge of the page.
*
* "This place" is a site, or a document on platforms that open documents — the
* caller decides and hands over the notes; see shared/noteScope.ts. Everything
* here works within that one scope, including search, which is why it filters
* in place instead of asking the store: the notes are already loaded, and a
* search box that returned notes from other sites would contradict the list it
* sits above.
*
* It shows itself on pages that have notes, without taking focus — a HUD that
* grabbed the cursor on load would swallow whatever the user started typing
* into the page. Opened on purpose (shortcut, toolbar button), it does take it.
*/
/**
* What "@" in the composer offers: the kind of note, picked rather than
* typed as a cue word. The cue is still what the classifier reads — prefixed
* to the words on save — so "@ Lời nhắc" + "3 giờ chiều gọi anh Đông" parses
* the time exactly as "nhắc tôi 3 giờ chiều gọi anh Đông" would.
*/
/** Rows built at a time; the rest wait behind "see more". */
var ROW_PAGE = 40;
/** How long the peek beside the button stays. */
var PEEK_MS = 9e3;
var KINDS = () => [
	{
		intent: "REMEMBER",
		label: t("kindNote"),
		hint: t("hintNote"),
		cue: "ghi chú",
		icon: "note"
	},
	{
		intent: "REMINDER",
		label: t("kindReminder"),
		hint: t("hintReminder"),
		cue: "nhắc tôi",
		icon: "bell"
	},
	{
		intent: "TASK",
		label: t("kindTask"),
		hint: t("hintTask"),
		cue: "việc cần làm",
		icon: "task"
	}
];
var DEFAULT_VIEW = {
	scope: "here",
	groupBy: "none"
};
/**
* The two ways offered: pop up on arrival, or just the button on the edge.
* `off` still exists as a stored value (older installs) and behaves as the
* button; it is not offered any more — "hidden" was the mode nobody wanted
* and everybody asked about.
*/
var AUTO_SHOW_LABELS = () => ({
	open: t("autoOpen"),
	tab: t("autoTab")
});
var AUTO_SHOW_ICONS = {
	open: "eye",
	tab: "edge",
	off: "eye-off"
};
/**
* How long the HUD stays open when it showed itself.
*
* Three seconds: long enough to see what is here on arriving at a page, short
* enough to be gone before anyone reaches for the page itself. It was five,
* and five is a long time to have somebody's panel over your reading. Opened
* on purpose, it never collapses on its own.
*/
var AUTO_COLLAPSE_MS = 3e3;
/** Filtering is local and cheap; this only skips the keystrokes inside a word. */
var FILTER_DEBOUNCE_MS = 120;
var QuickActionsPanel = class {
	options;
	panel;
	header;
	nameEl;
	countEl;
	collapseBtn;
	/** The place's name and count, above the composer. */
	placeEl;
	placeName;
	placeCount;
	placeIcon;
	/** The kind chosen with "@", shown as a chip in the field; null means "read the words". */
	kind = null;
	kindChip;
	atMenu;
	atBtn;
	field;
	whenBtn;
	whenChip;
	picked = null;
	picker = null;
	settingsBtn;
	settingsMenu;
	autoShow = "open";
	viewBtn;
	viewMenu;
	view = { ...DEFAULT_VIEW };
	tab;
	peek;
	peekTimer = null;
	tabCount;
	searchInput;
	chipsEl;
	input;
	saveBtn;
	groupBtn;
	groupLabel;
	composerMenuSlot;
	hintEl;
	places;
	pendingHighlight = null;
	notes = [];
	filter = "all";
	collapsed = false;
	filterTimer = null;
	/** Every group, from every site. */
	groups = [];
	/** Where new notes go: the group last chosen on this place, or none. */
	composerGroup = null;
	/** The group chip pressed, if any. Combines with the kind chips. */
	groupFilter = null;
	menu = null;
	/** Set while the HUD is showing itself; cleared the moment the user touches it. */
	autoCollapseTimer = null;
	/** True while the HUD is open because ViSO showed it, not because the user asked. */
	autoShown = false;
	/** How many rows are built; "see more" adds a page. */
	rowCap = ROW_PAGE;
	/** The listener that cancels it, kept so it can be taken off again. */
	autoCollapseStop = null;
	constructor(root, options) {
		this.options = options;
		this.panel = el("div", "card panel hud");
		this.panel.hidden = true;
		this.panel.setAttribute("role", "dialog");
		this.panel.setAttribute("aria-label", "ViSO");
		this.header = el("div", "hud__header");
		const heading = el("button", "hud__heading");
		heading.type = "button";
		heading.title = t("openHub");
		heading.setAttribute("aria-label", t("openHub"));
		heading.addEventListener("click", () => options.onOpenHub?.());
		const logo = el("img", "hud__logo");
		logo.alt = "";
		logo.draggable = false;
		try {
			logo.src = options.logoUrl ?? chrome.runtime.getURL("icons/icon-48.png");
		} catch {}
		const brand = el("span", "hud__brand");
		brand.textContent = "ViSO";
		heading.append(logo, brand);
		this.placeEl = el("div", "hud__place");
		this.placeIcon = el("img", "hud__place-icon");
		this.placeIcon.alt = "";
		this.placeIcon.draggable = false;
		this.placeIcon.hidden = true;
		this.nameEl = el("span", "hud__name");
		this.nameEl.textContent = "ViSO";
		this.countEl = el("span", "hud__count");
		this.placeName = el("span", "hud__place-name");
		this.placeName.append(this.nameEl);
		this.placeCount = el("span", "hud__place-count");
		this.placeCount.append(this.countEl);
		const placeText = el("span", "hud__place-text");
		placeText.append(this.placeName, this.placeCount);
		this.placeEl.append(this.placeIcon, placeText);
		const trail = comet(96, "up-right", "hud__comet-title");
		this.collapseBtn = iconButton("minus", t("collapse"));
		this.collapseBtn.classList.add("hud__collapse");
		this.collapseBtn.addEventListener("click", () => this.setCollapsed(!this.collapsed, true));
		this.settingsBtn = iconButton("gear", t("settings"));
		this.settingsBtn.className = "hud__gear";
		this.settingsBtn.setAttribute("aria-haspopup", "menu");
		this.settingsBtn.setAttribute("aria-expanded", "false");
		this.settingsBtn.addEventListener("click", () => this.toggleSettings());
		this.settingsMenu = el("div", "hud__settings");
		this.settingsMenu.setAttribute("role", "menu");
		this.settingsMenu.hidden = true;
		this.viewBtn = iconButton("view", t("view"));
		this.viewBtn.className = "hud__view-btn";
		this.viewBtn.setAttribute("aria-haspopup", "menu");
		this.viewBtn.setAttribute("aria-expanded", "false");
		this.viewBtn.addEventListener("click", () => this.toggleView());
		this.viewMenu = el("div", "hud__view-menu");
		this.viewMenu.setAttribute("role", "menu");
		this.viewMenu.hidden = true;
		this.tab = el("div", "hud__tab");
		this.tab.setAttribute("role", "button");
		this.tab.tabIndex = 0;
		this.tabCount = el("span", "hud__tab-count");
		const mark = el("img", "hud__tab-logo");
		mark.alt = "";
		mark.draggable = false;
		try {
			mark.src = options.logoUrl ?? chrome.runtime.getURL("icons/icon-48.png");
		} catch {}
		this.tab.append(mark, this.tabCount);
		this.peek = el("div", "hud__peek");
		this.peek.hidden = true;
		this.tab.append(mark, this.tabCount);
		this.tab.addEventListener("click", () => this.setCollapsed(false, true));
		this.tab.addEventListener("keydown", (event) => {
			if (event.key !== "Enter" && event.key !== " ") return;
			event.preventDefault();
			this.setCollapsed(false, true);
		});
		guardKeys(this.tab);
		this.header.append(this.peek, this.tab, heading, trail, this.viewBtn, this.settingsBtn, this.collapseBtn);
		const search = el("label", "hud__search");
		this.searchInput = el("input", "hud__search-input");
		this.searchInput.type = "search";
		this.searchInput.placeholder = t("search");
		this.searchInput.setAttribute("aria-label", t("search"));
		this.searchInput.autocomplete = "off";
		this.searchInput.spellcheck = false;
		this.searchInput.addEventListener("input", () => this.scheduleFilter());
		this.searchInput.addEventListener("keydown", (event) => {
			if (event.key === "Escape") {
				event.preventDefault();
				if (this.searchInput.value !== "") {
					this.searchInput.value = "";
					this.applyFilter();
				} else this.dismiss();
			} else if (event.key === "Enter") {
				event.preventDefault();
				this.applyFilter();
			}
		});
		guardKeys(this.searchInput);
		search.append(icon("search", 18), this.searchInput, star(20, "hud__search-star"));
		this.chipsEl = el("div", "hud__chips");
		this.chipsEl.setAttribute("role", "toolbar");
		this.chipsEl.setAttribute("aria-label", t("filter"));
		this.panel.append(this.header, this.viewMenu, this.settingsMenu, search, this.chipsEl);
		this.places = new PlaceNotes(this.panel, {
			onDelete: (uid) => {
				this.notes = this.notes.filter((note) => note.id !== uid);
				this.renderCount();
				this.renderChips();
				options.onDeleteNote(uid);
			},
			onOpenAll: () => {
				this.rowCap += ROW_PAGE;
				this.renderList(null);
			},
			onOpenNote: options.onOpenNote,
			onEdit: options.onEditNote,
			onSetDue: options.onSetDue,
			onSetDone: async (uid, done) => {
				const error = await options.onSetDone(uid, done);
				if (error !== null) this.showHint(error);
				else this.hintEl.hidden = true;
				return error;
			},
			onChangeGroup: (note, mount, anchor) => this.openRowMenu(note, mount, anchor)
		});
		const composer = el("div", "hud__composer");
		this.input = el("textarea", "panel__input");
		this.input.placeholder = t("placeholder");
		this.input.rows = 1;
		this.input.addEventListener("input", () => {
			this.syncSaveState();
			this.announceDraft();
		});
		this.input.addEventListener("keydown", (event) => {
			if (event.key === "Enter" && !event.shiftKey) {
				event.preventDefault();
				this.save();
			} else if (event.key === "Escape") {
				event.preventDefault();
				this.dismiss();
			}
		});
		guardKeys(this.input);
		this.hintEl = el("p", "panel__hint");
		this.hintEl.hidden = true;
		const actions = el("div", "hud__composer-actions");
		const field = el("div", "hud__field");
		const mic = iconButton("mic", t("mic"));
		mic.classList.add("hud__mic");
		mic.replaceChildren(icon("mic", 22));
		mic.addEventListener("click", () => options.onVoice());
		this.groupBtn = el("button", "hud__group-picker");
		this.groupBtn.type = "button";
		this.groupBtn.setAttribute("aria-haspopup", "menu");
		this.groupBtn.setAttribute("aria-expanded", "false");
		this.groupLabel = el("span", "hud__group-picker-label");
		this.groupBtn.append(icon("folder", 18), this.groupLabel);
		this.groupBtn.addEventListener("click", () => this.openComposerMenu());
		this.kindChip = el("button", "hud__kind-chip");
		this.kindChip.type = "button";
		this.kindChip.hidden = true;
		this.kindChip.title = t("unpickKind");
		this.kindChip.addEventListener("click", () => this.setKind(null));
		this.atMenu = el("div", "hud__at-menu");
		this.atMenu.setAttribute("role", "menu");
		this.atMenu.hidden = true;
		for (const kind of KINDS()) {
			const item = el("button", "hud__at-item");
			item.type = "button";
			item.setAttribute("role", "menuitem");
			const tile = el("span", "hud__at-tile");
			tile.append(icon(kind.icon, 16));
			const words = el("span", "hud__at-words");
			const label = el("span", "hud__at-label");
			label.textContent = kind.label;
			const hint = el("span", "hud__at-hint");
			hint.textContent = kind.hint;
			words.append(label, hint);
			item.append(tile, words);
			item.addEventListener("click", () => {
				this.input.value = this.input.value.replace(/@\s*$/, "");
				this.setKind(kind);
				this.input.focus();
			});
			this.atMenu.append(item);
		}
		const syncAtMenu = () => {
			const caret = this.input.selectionStart ?? this.input.value.length;
			const before = this.input.value.slice(0, caret);
			const show = /(^|\s)@$/.test(before);
			if (show && this.atMenu.hidden) this.highlightAt(0);
			this.atMenu.hidden = !show;
		};
		for (const kind of [
			"input",
			"keyup",
			"compositionend"
		]) this.input.addEventListener(kind, syncAtMenu);
		this.atBtn = el("button", "hud__at-btn");
		this.atBtn.type = "button";
		this.atBtn.textContent = "@";
		this.atBtn.title = t("pickKind");
		this.atBtn.setAttribute("aria-label", t("pickKindAria"));
		this.atBtn.setAttribute("aria-haspopup", "menu");
		this.atBtn.addEventListener("click", () => {
			if (this.atMenu.hidden) this.highlightAt(0);
			this.atMenu.hidden = !this.atMenu.hidden;
			this.input.focus();
		});
		this.input.addEventListener("keydown", (event) => {
			if (this.atMenu.hidden) return;
			const items = [...this.atMenu.querySelectorAll(".hud__at-item")];
			const index = Number(this.atMenu.dataset["index"] ?? "-1");
			if (event.key === "ArrowDown" || event.key === "ArrowUp") {
				event.preventDefault();
				this.highlightAt(event.key === "ArrowDown" ? Math.min(items.length - 1, index + 1) : Math.max(0, index - 1));
			} else if (event.key === "Enter" || event.key === "Tab") {
				event.preventDefault();
				event.stopImmediatePropagation();
				items[Math.max(0, index)]?.click();
			} else if (event.key === "Escape") {
				event.preventDefault();
				event.stopImmediatePropagation();
				this.atMenu.hidden = true;
			}
		}, { capture: true });
		this.whenBtn = el("button", "hud__when-btn");
		this.whenBtn.type = "button";
		this.whenBtn.hidden = true;
		this.whenBtn.title = t("pickDate");
		this.whenBtn.setAttribute("aria-label", t("pickDate"));
		this.whenBtn.setAttribute("aria-haspopup", "dialog");
		this.whenBtn.append(icon("calendar", 17));
		this.whenBtn.addEventListener("click", () => this.togglePicker());
		this.whenChip = el("button", "hud__when-chip");
		this.whenChip.type = "button";
		this.whenChip.hidden = true;
		this.whenChip.title = t("pickDate");
		this.whenChip.addEventListener("click", (event) => {
			const target = event.target;
			if (target.closest("svg:last-child") !== null && this.whenChip.lastElementChild === target.closest("svg")) this.setPicked(null);
			else this.togglePicker();
		});
		field.append(this.groupBtn, this.whenBtn, this.kindChip, this.whenChip, this.input, this.atBtn);
		this.field = field;
		this.saveBtn = button(t("save"), "btn btn--primary hud__save");
		this.saveBtn.append(star(18));
		this.saveBtn.addEventListener("click", () => this.save());
		actions.append(mic, field, this.saveBtn);
		this.composerMenuSlot = el("div", "hud__composer-menu");
		composer.append(this.placeEl, this.hintEl, this.composerMenuSlot, this.atMenu, actions);
		this.panel.append(composer);
		root.append(this.panel);
		this.syncSaveState();
		this.renderGroupPicker();
	}
	/** True while the HUD is on screen because a page arrived, not because the user opened it. */
	get wasAutoShown() {
		return this.isOpen && this.autoShown;
	}
	get isOpen() {
		return !this.panel.hidden;
	}
	get isCollapsed() {
		return this.collapsed;
	}
	/** What the user has typed and not yet saved. */
	get draft() {
		return this.input.value;
	}
	/** The header, for dragging the HUD along the right edge. */
	get dragHandle() {
		return this.header;
	}
	/** Which page the user is on, to tell a note written here from one written elsewhere. */
	setCurrentContext(contextHash, url = null) {
		this.places.setCurrentContext(contextHash, url);
	}
	/**
	* "Gmail", or a document's own title.
	*
	* `siteLabel` is no longer shown separately: a page's list holds the whole
	* site, so there is nothing to name apart from the place itself.
	*/
	setScopeLabel(label, _siteLabel = null) {
		this.nameEl.textContent = label ?? "ViSO";
		this.panel.setAttribute("aria-label", label === null ? "ViSO" : `ViSO — ${label}`);
		try {
			const url = new URL(chrome.runtime.getURL("/_favicon/"));
			url.searchParams.set("pageUrl", location.href);
			url.searchParams.set("size", "32");
			this.placeIcon.src = url.toString();
			this.placeIcon.hidden = false;
		} catch {
			this.placeIcon.hidden = true;
		}
	}
	/**
	* Beside the button, on arrival: the two newest notes of this place as
	* small cards, and "+N" for the rest — the way a phone stacks a site's
	* notifications. Gone on their own after a moment; the count on the button
	* stays. Pressing a card opens the HUD on that note; "+N" just opens it.
	*/
	showPeek() {
		if (this.peekTimer !== null) clearTimeout(this.peekTimer);
		const newest = [...this.notes].sort((a, b) => b.createdAt - a.createdAt).slice(0, 2);
		if (newest.length === 0) {
			this.hidePeek();
			return;
		}
		const cards = newest.map((note) => {
			const card = el("button", `hud__peek-card hud__peek-card--${note.intent.toLowerCase()}`);
			card.type = "button";
			card.title = note.text;
			const mark = el("span", "hud__peek-icon");
			const favicon = (note.favicon ?? "").trim();
			if (favicon !== "") {
				const img = el("img", "hud__peek-favicon");
				img.src = favicon;
				img.alt = "";
				img.draggable = false;
				img.addEventListener("error", () => {
					img.remove();
					mark.append(icon(note.intent === "TASK" ? "task" : note.intent === "REMINDER" ? "bell" : "note", 18));
				});
				mark.append(img);
			} else mark.append(icon(note.intent === "TASK" ? "task" : note.intent === "REMINDER" ? "bell" : "note", 18));
			const words = el("span", "hud__peek-words");
			const line = el("span", "hud__peek-line");
			const text = el("span", "hud__peek-text");
			text.textContent = note.text;
			const ago = el("span", "hud__peek-ago");
			ago.textContent = relativeTime(note.createdAt);
			line.append(text, ago);
			const kind = el("span", "hud__peek-kind");
			kind.textContent = note.intent === "TASK" ? t("kindTask") : note.intent === "REMINDER" ? t("kindReminder") : t("kindNote");
			words.append(line, kind);
			card.append(mark, words);
			card.addEventListener("click", (event) => {
				event.stopPropagation();
				this.hidePeek();
				this.setCollapsed(false, true);
				this.highlight(note.id);
			});
			return card;
		});
		const more = this.notes.length - newest.length;
		const rest = [];
		if (more > 0) {
			const btn = el("button", "hud__peek-more");
			btn.type = "button";
			btn.textContent = `+${more}`;
			btn.addEventListener("click", (event) => {
				event.stopPropagation();
				this.hidePeek();
				this.setCollapsed(false, true);
			});
			rest.push(btn);
		}
		this.peek.replaceChildren(...cards, ...rest);
		this.peek.hidden = false;
		this.peek.addEventListener("mouseenter", () => {
			if (this.peekTimer !== null) clearTimeout(this.peekTimer);
		});
		this.peek.addEventListener("mouseleave", () => this.armPeekFade());
		this.armPeekFade();
	}
	armPeekFade() {
		if (this.peekTimer !== null) clearTimeout(this.peekTimer);
		this.peekTimer = setTimeout(() => this.hidePeek(), PEEK_MS);
	}
	hidePeek() {
		if (this.peekTimer !== null) clearTimeout(this.peekTimer);
		this.peekTimer = null;
		this.peek.hidden = true;
		this.peek.replaceChildren();
	}
	/** Lights one row of the "@" menu, the one Enter will take. */
	highlightAt(index) {
		this.atMenu.dataset["index"] = String(index);
		[...this.atMenu.querySelectorAll(".hud__at-item")].forEach((item, i) => item.classList.toggle("hud__at-item--on", i === index));
	}
	/** The kind "@" chose, or none. */
	setKind(kind) {
		this.kind = kind;
		this.announceDraft();
		this.atMenu.hidden = true;
		delete this.atMenu.dataset["index"];
		for (const item of this.atMenu.querySelectorAll(".hud__at-item")) item.classList.remove("hud__at-item--on");
		this.field.classList.toggle("hud__field--kind", kind !== null);
		this.whenBtn.hidden = kind === null || kind.intent === "REMEMBER";
		if (kind === null) {
			this.kindChip.hidden = true;
			this.kindChip.replaceChildren();
			this.setPicked(null);
			return;
		}
		this.kindChip.hidden = false;
		this.kindChip.replaceChildren(icon(kind.icon, 15), document.createTextNode(kind.label), icon("close", 13));
		this.kindChip.setAttribute("aria-label", `${kind.label} — bấm để bỏ chọn`);
		this.syncSaveState();
	}
	/** A group's name, for filing an app note — the app knows groups by name. */
	groupName(groupId) {
		return this.groups.find((group) => group.id === groupId)?.name ?? null;
	}
	/** Every group, shared by all sites. A chosen group that went away is let go. */
	setGroups(groups) {
		this.groups = [...groups];
		if (this.composerGroup !== null && !this.groups.some((group) => group.id === this.composerGroup)) this.composerGroup = null;
		this.renderGroupPicker();
	}
	/** The group new notes here go into — the one last chosen on this place. After setGroups. */
	setComposerGroup(groupId) {
		this.composerGroup = groupId !== null && this.groups.some((group) => group.id === groupId) ? groupId : null;
		this.renderGroupPicker();
	}
	/**
	* Shows the HUD because this place has notes.
	*
	* Never takes focus, and never overrides a HUD the user already has open —
	* that one is theirs, in whatever state they left it.
	*/
	showAuto(collapsed) {
		this.options.onTrace?.(`showAuto collapsed=${collapsed} open=${this.isOpen} wasCollapsed=${this.collapsed}`);
		if (this.isOpen) {
			if (!this.collapsed && this.autoShown && !this.inUse()) this.armAutoCollapse();
			return;
		}
		this.autoShown = true;
		this.setCollapsed(collapsed, false);
		this.panel.hidden = false;
		this.renderList(null);
		if (collapsed) this.showPeek();
		if (!collapsed) this.armAutoCollapse();
	}
	armAutoCollapse() {
		this.cancelAutoCollapse();
		const stop = () => this.cancelAutoCollapse();
		this.autoCollapseStop = stop;
		for (const type of [
			"pointerdown",
			"focusin",
			"keydown"
		]) this.panel.addEventListener(type, stop);
		this.autoCollapseTimer = setTimeout(() => {
			this.autoCollapseTimer = null;
			if (this.isOpen && !this.collapsed && !this.inUse()) this.setCollapsed(true, false);
		}, AUTO_COLLAPSE_MS);
	}
	cancelAutoCollapse() {
		if (this.autoCollapseStop !== null) {
			for (const type of [
				"pointerdown",
				"focusin",
				"keydown"
			]) this.panel.removeEventListener(type, this.autoCollapseStop);
			this.autoCollapseStop = null;
		}
		if (this.autoCollapseTimer === null) return;
		clearTimeout(this.autoCollapseTimer);
		this.autoCollapseTimer = null;
	}
	/** Opened on purpose: expanded, refreshed, and focused unless told otherwise. */
	open(focus = true) {
		this.options.onTrace?.(`open focus=${focus} ${(/* @__PURE__ */ new Error()).stack?.split("\n").slice(2, 5).map((l) => l.trim()).join(" < ") ?? ""}`);
		this.autoShown = false;
		this.cancelAutoCollapse();
		this.panel.hidden = false;
		if (focus && this.collapsed) this.setCollapsed(false, true);
		this.renderList(null);
		if (focus) this.input.focus();
		this.options.loadNotes();
	}
	/** Shortcut and toolbar button: open it, expand it, or hide it. */
	toggle() {
		if (!this.isOpen) {
			this.open(true);
			return;
		}
		if (this.collapsed) {
			this.setCollapsed(false, true);
			this.input.focus();
			return;
		}
		this.dismiss();
	}
	/**
	* Reopens with a draft carried over from the page just left.
	*
	* Restored rather than saved: the note will attach to wherever the user now
	* is, and the list shows which place that is.
	*/
	reopenWith(draft) {
		this.open(true);
		if (draft === "") return;
		this.input.value = draft;
		this.input.setSelectionRange(draft.length, draft.length);
		this.syncSaveState();
	}
	/**
	* Marks a note after a same-document navigation.
	*
	* Held and applied by whichever render arrives, because the list is fetched
	* after the navigation settles.
	*/
	highlight(uid) {
		this.pendingHighlight = uid;
	}
	setNotes(notes, highlightId = null) {
		const mark = highlightId ?? this.pendingHighlight;
		this.pendingHighlight = null;
		this.notes = notes;
		this.renderCount();
		this.renderList(mark);
	}
	close() {
		this.cancelAutoCollapse();
		this.panel.hidden = true;
		this.clearComposer(false);
		this.searchInput.value = "";
		this.filter = "all";
		if (this.filterTimer !== null) {
			clearTimeout(this.filterTimer);
			this.filterTimer = null;
		}
		this.places.hide();
		this.closeMenu();
		this.groupFilter = null;
	}
	/** What the gear's menu shows as chosen. */
	setAutoShow(mode) {
		this.autoShow = mode;
		this.renderSettings();
	}
	/** What the view menu shows as chosen, and how the list is drawn. */
	setView(view) {
		this.view = { ...view };
		this.viewBtn.classList.toggle("hud__view-btn--on", view.scope !== "here");
		this.renderView();
		if (this.isOpen) this.renderList(null);
	}
	get currentView() {
		return { ...this.view };
	}
	toggleView() {
		const open = this.viewMenu.hidden;
		this.viewMenu.hidden = !open;
		this.settingsMenu.hidden = true;
		this.viewBtn.setAttribute("aria-expanded", String(open));
		if (open) this.renderView();
	}
	renderView() {
		const item = (label, checked, pick) => {
			const node = el("button", "hud__setting hud__view-item");
			node.type = "button";
			node.setAttribute("role", "menuitemradio");
			node.setAttribute("aria-checked", String(checked));
			const check = el("span", "hud__setting-check");
			if (checked) check.append(icon("check", 14));
			const name = el("span", "hud__setting-name");
			name.textContent = label;
			node.append(check, name);
			node.addEventListener("click", () => {
				pick();
				this.viewMenu.hidden = true;
				this.viewBtn.setAttribute("aria-expanded", "false");
				this.setView(this.view);
				this.options.onViewChange?.(this.currentView);
			});
			return node;
		};
		const scopeTitle = el("p", "hud__menu-title");
		scopeTitle.textContent = t("viewTitle");
		this.viewMenu.replaceChildren(scopeTitle, item(t("thisPage"), this.view.scope === "here", () => {
			this.view.scope = "here";
		}), item(t("allPages"), this.view.scope === "all", () => {
			this.view.scope = "all";
		}));
	}
	toggleSettings() {
		const open = this.settingsMenu.hidden;
		this.settingsMenu.hidden = !open;
		this.viewMenu.hidden = true;
		this.settingsBtn.setAttribute("aria-expanded", String(open));
		if (open) this.renderSettings();
	}
	renderSettings() {
		const title = el("p", "hud__menu-title");
		title.textContent = t("whenNewPage");
		const labels = AUTO_SHOW_LABELS();
		const chosen = this.autoShow === "off" ? "tab" : this.autoShow;
		const items = Object.keys(labels).map((mode) => {
			const item = el("button", "hud__setting hud__setting--mode");
			item.type = "button";
			item.setAttribute("role", "menuitemradio");
			item.setAttribute("aria-checked", String(mode === chosen));
			const tile = el("span", "hud__at-tile");
			tile.append(icon(AUTO_SHOW_ICONS[mode], 16));
			const name = el("span", "hud__setting-name");
			name.textContent = labels[mode] ?? "";
			const check = el("span", "hud__setting-check");
			if (mode === chosen) check.append(icon("check", 14));
			item.append(tile, name, check);
			item.addEventListener("click", () => {
				this.autoShow = mode;
				this.options.onAutoShowChange?.(mode);
				this.renderSettings();
			});
			return item;
		});
		const hint = el("p", "hud__setting-hint");
		hint.textContent = t("autoHint");
		const langTitle = el("p", "hud__menu-title");
		langTitle.textContent = t("language");
		const langRow = el("div", "hud__lang");
		for (const lang of ["vi", "en"]) {
			const b = el("button", "hud__lang-btn");
			b.type = "button";
			b.setAttribute("role", "radio");
			b.setAttribute("aria-checked", String(getLang() === lang));
			const flag = el("span", "hud__lang-flag");
			flag.innerHTML = LANG_LABELS[lang].flag;
			b.append(flag, document.createTextNode(LANG_LABELS[lang].name));
			b.addEventListener("click", () => {
				setLang(lang);
				this.options.onLangChange?.(lang);
				this.relabel();
			});
			langRow.append(b);
		}
		this.settingsMenu.replaceChildren(langTitle, langRow, title, ...items, hint);
	}
	/** Every label set once at construction, set again in the new language. */
	relabel() {
		this.input.placeholder = t("placeholder");
		this.searchInput.placeholder = t("search");
		this.searchInput.setAttribute("aria-label", t("search"));
		this.chipsEl.setAttribute("aria-label", t("filter"));
		this.settingsBtn.title = t("settings");
		this.settingsBtn.setAttribute("aria-label", t("settings"));
		this.viewBtn.title = t("view");
		this.viewBtn.setAttribute("aria-label", t("view"));
		this.kindChip.title = t("unpickKind");
		this.atBtn.title = t("pickKind");
		this.atBtn.setAttribute("aria-label", t("pickKindAria"));
		this.saveBtn.replaceChildren(document.createTextNode(t("save")), star(18));
		const items = [...this.atMenu.querySelectorAll(".hud__at-item")];
		KINDS().forEach((kind, i) => {
			const label = items[i]?.querySelector(".hud__at-label");
			if (label) label.textContent = kind.label;
			const hint = items[i]?.querySelector(".hud__at-hint");
			if (hint) hint.textContent = kind.hint;
		});
		if (this.kind !== null) this.setKind(KINDS().find((k) => k.intent === this.kind?.intent) ?? null);
		this.renderGroupPicker();
		this.renderChips();
		this.renderList(null);
		this.renderView();
		this.renderSettings();
		this.setCollapsed(this.collapsed, false);
	}
	/** Something is being written: focus in the composer, words in it, or a kind chosen. */
	inUse() {
		const scope = this.panel.getRootNode();
		return this.input.value.trim() !== "" || this.kind !== null || this.panel.contains(scope.activeElement);
	}
	setCollapsed(collapsed, notify) {
		if (!collapsed && this.collapsed) this.options.onTrace?.(`expand notify=${notify} ${(/* @__PURE__ */ new Error()).stack?.split("\n").slice(2, 5).map((l) => l.trim()).join(" < ") ?? ""}`);
		if (!collapsed && notify) {
			this.autoShown = false;
			this.cancelAutoCollapse();
		}
		const scope = this.panel.getRootNode();
		const focusInside = this.panel.contains(scope.activeElement);
		this.collapsed = collapsed;
		if (!collapsed) this.hidePeek();
		if (collapsed && focusInside) this.tab.focus();
		this.panel.classList.toggle("hud--collapsed", collapsed);
		const [name, label] = collapsed ? ["chevron", t("expand")] : ["minus", t("collapse")];
		this.collapseBtn.replaceChildren(icon(name, 16));
		this.collapseBtn.title = label;
		this.collapseBtn.setAttribute("aria-label", label);
		this.collapseBtn.setAttribute("aria-expanded", String(!collapsed));
		if (notify) this.options.onCollapsedChange(collapsed);
	}
	/** Searches this place's notes, as if typed into the search field. */
	search(question) {
		if (!this.isOpen) this.open(false);
		if (this.collapsed) this.setCollapsed(false, false);
		this.searchInput.value = question;
		this.applyFilter();
	}
	showHint(message) {
		if (!this.isOpen) this.open(false);
		if (this.collapsed) this.setCollapsed(false, false);
		this.hintEl.textContent = message;
		this.hintEl.hidden = false;
	}
	setText(text) {
		this.input.value = text;
		this.syncSaveState();
	}
	/**
	* Escape, and the shortcut on an open HUD.
	*
	* Collapses rather than hides. There used to be a separate × beside −, and
	* the stronger of the two left nothing on the page to bring the HUD back
	* with. Collapsed, the tab stays on the edge. Only a place with no notes has
	* no tab worth leaving, so there the HUD goes away entirely.
	*/
	dismiss() {
		if (this.notes.length > 0) {
			this.setCollapsed(true, true);
			return;
		}
		this.close();
		this.options.onClose?.();
	}
	save() {
		const written = this.input.value.trim();
		if (written === "") return;
		const cue = matchGroupCue(written, this.groups);
		const typed = cue?.text ?? written;
		if (typed === "") return;
		const groupId = cue?.group.id ?? this.composerGroup;
		if (this.kind === null && classifyIntent(typed).intent === "QUERY") {
			this.clearComposer();
			this.search(typed);
			return;
		}
		const read = readTyped(typed, this.kind?.intent ?? null);
		const intent = read.intent;
		const text = read.text;
		const remindAt = this.picked !== null && (intent === "REMINDER" || intent === "TASK") ? (/* @__PURE__ */ new Date(`${this.picked.date}T${this.picked.time}:00`)).getTime() : read.remindAt;
		const repeat = intent === "REMINDER" ? classifyIntent(`nhắc tôi ${typed}`).repeat ?? null : null;
		const onContext = classifyIntent(`nhắc tôi ${typed}`).onContext === true;
		this.options.onSave(intent, text, remindAt, onContext, repeat, groupId);
		this.clearComposer();
	}
	/** The calendar's answer: shown as a chip beside the kind, or nothing. */
	setPicked(picked) {
		this.picked = picked;
		this.announceDraft();
		this.closePicker();
		this.whenChip.hidden = picked === null;
		this.whenBtn.classList.toggle("hud__when-btn--set", picked !== null);
		if (picked === null) {
			this.whenChip.replaceChildren();
			return;
		}
		const d = /* @__PURE__ */ new Date(`${picked.date}T${picked.time}:00`);
		const today = /* @__PURE__ */ new Date();
		today.setHours(0, 0, 0, 0);
		const days = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - today.getTime()) / 864e5);
		const day = days === 0 ? t("today") : days === 1 ? t("tomorrow") : days > 1 && days < 7 ? t("weekday")(d.getDay()) : `${d.getDate()}/${d.getMonth() + 1}`;
		this.whenChip.replaceChildren(icon("calendar", 13), document.createTextNode(`${day} ${picked.time}`), icon("close", 12));
	}
	togglePicker() {
		if (this.picker !== null) {
			this.closePicker();
			return;
		}
		this.picker = new DatePicker((picked) => this.setPicked(picked), this.picked);
		this.composerMenuSlot.append(this.picker.element);
	}
	closePicker() {
		this.picker?.element.remove();
		this.picker = null;
	}
	clearComposer(forget = true) {
		this.quietDraft = !forget;
		this.input.value = "";
		this.hintEl.hidden = true;
		this.setKind(null);
		this.syncSaveState();
		this.quietDraft = false;
		if (forget) this.options.onDraftChange?.(null);
	}
	/** True while the composer is being emptied without the draft being given up. */
	quietDraft = false;
	announceDraft() {
		if (this.quietDraft) return;
		const text = this.input.value;
		this.tab.classList.toggle("hud__tab--draft", text.trim() !== "");
		if (text.trim() === "" && this.kind === null) {
			this.options.onDraftChange?.(null);
			return;
		}
		this.options.onDraftChange?.({
			text,
			intent: this.kind?.intent ?? null,
			when: this.picked
		});
	}
	/**
	* Puts a kept draft back into the composer — words, kind and date — without
	* opening or focusing anything. Only into an empty composer: what is being
	* typed right now always wins over what was typed before.
	*/
	restoreDraft(draft) {
		if (this.input.value.trim() !== "" || this.kind !== null) return;
		this.quietDraft = true;
		const kind = draft.intent === null ? null : KINDS().find((k) => k.intent === draft.intent) ?? null;
		if (kind !== null) this.setKind(kind);
		if (draft.when !== null && kind !== null && kind.intent !== "REMEMBER") this.setPicked(draft.when);
		this.input.value = draft.text;
		this.quietDraft = false;
		this.syncSaveState();
		this.tab.classList.toggle("hud__tab--draft", draft.text.trim() !== "");
	}
	syncSaveState() {
		this.saveBtn.disabled = this.input.value.trim() === "";
	}
	scheduleFilter() {
		if (this.filterTimer !== null) clearTimeout(this.filterTimer);
		this.filterTimer = setTimeout(() => this.applyFilter(), FILTER_DEBOUNCE_MS);
	}
	applyFilter() {
		if (this.filterTimer !== null) {
			clearTimeout(this.filterTimer);
			this.filterTimer = null;
		}
		this.rowCap = ROW_PAGE;
		this.renderList(null);
	}
	renderCount() {
		const count = this.notes.length;
		this.countEl.textContent = ` · ${t("notesCount")(count)}`;
		this.tabCount.textContent = String(count);
		const label = `Mở ghi chú ở đây (${count})`;
		this.tab.title = label;
		this.tab.setAttribute("aria-label", label);
	}
	renderList(highlightId) {
		if (this.menu !== null && this.menu.anchor !== this.groupBtn) this.closeMenu();
		this.renderChips();
		const visible = this.filtered();
		const searching = this.searchInput.value.trim() !== "";
		const at = highlightId === null ? -1 : visible.findIndex((note) => note.id === highlightId);
		if (at >= this.rowCap) this.rowCap = Math.ceil((at + 1) / ROW_PAGE) * ROW_PAGE;
		this.places.renderAll(visible.slice(0, this.rowCap), visible.length, highlightId, searching ? t("noMatch") : t("emptyHere"), this.view.groupBy);
	}
	/**
	* Chips for the slices that have something in them.
	*
	* An empty chip is a button that leads nowhere, and "Lời nhắc 0" on every
	* page for someone who never sets reminders is noise.
	*/
	renderChips() {
		const reminders = this.notes.filter((note) => note.intent === "REMINDER").length;
		const tasks = this.notes.filter((note) => note.intent === "TASK").length;
		const chips = [{
			id: "all",
			label: t("all"),
			count: this.notes.length
		}];
		if (reminders > 0) chips.push({
			id: "reminder",
			label: t("reminders"),
			count: reminders
		});
		if (tasks > 0) chips.push({
			id: "task",
			label: t("tasks"),
			count: tasks
		});
		if (!chips.some((chip) => chip.id === this.filter)) this.filter = "all";
		const groupCounts = /* @__PURE__ */ new Map();
		for (const note of this.notes) {
			if (note.groupId == null) continue;
			const entry = groupCounts.get(note.groupId);
			if (entry === void 0) groupCounts.set(note.groupId, {
				name: note.groupName ?? "",
				count: 1
			});
			else entry.count++;
		}
		if (this.groupFilter !== null && !groupCounts.has(this.groupFilter)) this.groupFilter = null;
		const groupChips = [...groupCounts].map(([id, group]) => ({
			id,
			...group
		})).sort((a, b) => a.name.localeCompare(b.name, "vi"));
		const scope = this.chipsEl.getRootNode();
		const focusedId = this.chipsEl.contains(scope.activeElement) ? scope.activeElement?.dataset["filter"] ?? null : null;
		this.chipsEl.hidden = this.notes.length === 0;
		this.chipsEl.replaceChildren(...chips.map((chip) => {
			const node = button("", "hud__chip");
			node.dataset["filter"] = chip.id;
			const active = chip.id === this.filter && (chip.id !== "all" || this.groupFilter === null);
			if (active) node.classList.add("hud__chip--active");
			node.setAttribute("aria-pressed", String(active));
			const label = el("span", "hud__chip-label");
			label.textContent = chip.label;
			const count = el("span", "hud__chip-count");
			count.textContent = String(chip.count);
			node.append(label, count);
			node.addEventListener("click", () => {
				this.filter = chip.id;
				this.rowCap = ROW_PAGE;
				if (chip.id === "all") this.groupFilter = null;
				this.renderList(null);
			});
			return node;
		}));
		this.chipsEl.append(...groupChips.map((group) => {
			const node = button("", "hud__chip hud__chip--group");
			node.dataset["filter"] = `group:${group.id}`;
			const active = group.id === this.groupFilter;
			if (active) node.classList.add("hud__chip--active");
			node.setAttribute("aria-pressed", String(active));
			node.title = `Nhóm ${group.name}`;
			const label = el("span", "hud__chip-label");
			label.textContent = group.name;
			const count = el("span", "hud__chip-count");
			count.textContent = String(group.count);
			node.append(icon("folder", 13), label, count);
			node.addEventListener("click", () => {
				this.groupFilter = active ? null : group.id;
				this.renderList(null);
			});
			return node;
		}));
		if (focusedId !== null) this.chipsEl.querySelector(`[data-filter="${focusedId}"]`)?.focus();
	}
	renderGroupPicker() {
		const group = this.groups.find((candidate) => candidate.id === this.composerGroup) ?? null;
		this.groupLabel.textContent = group?.name ?? t("noGroup");
		this.groupBtn.title = group === null ? t("groupNone") : t("groupNamed")(group.name);
		this.groupBtn.setAttribute("aria-label", this.groupBtn.title);
		this.groupBtn.classList.toggle("hud__group-picker--set", group !== null);
		const label = group === null ? t("groupNewNone") : t("groupNewNamed")(group.name);
		this.groupBtn.title = label;
		this.groupBtn.setAttribute("aria-label", label);
	}
	openComposerMenu() {
		this.openMenu(this.composerGroup, this.groupBtn, (element) => this.composerMenuSlot.append(element), (groupId) => {
			this.composerGroup = groupId;
			this.renderGroupPicker();
			this.options.onComposerGroupChange(groupId);
			this.input.focus();
		});
	}
	/** A note's group, changed from its row: shown at once, put back if the store refuses. */
	openRowMenu(note, mount, anchor) {
		const selected = note.groupId ?? this.groups.find((group) => note.groupName !== null && note.groupName !== void 0 && group.name === note.groupName)?.id ?? null;
		this.openMenu(selected, anchor, (element) => mount.append(element), (groupId) => {
			const before = {
				groupId: note.groupId ?? null,
				groupName: note.groupName ?? null
			};
			if (groupId === selected) return;
			note.groupId = groupId;
			note.groupName = this.groups.find((group) => group.id === groupId)?.name ?? null;
			this.renderList(null);
			this.options.onSetNoteGroup(note.id, groupId).then((error) => {
				if (error === null) return;
				note.groupId = before.groupId;
				note.groupName = before.groupName;
				this.renderList(null);
				this.showHint(error);
			});
		});
	}
	openMenu(selected, anchor, place, pick) {
		const again = this.menu !== null && this.menu.anchor === anchor;
		this.closeMenu();
		if (again) return;
		const menu = new GroupMenu({
			groups: this.groups,
			selected,
			anchor,
			onPick: (groupId) => {
				this.closeMenu();
				pick(groupId);
			},
			onCreate: async (name) => {
				const result = await this.options.onCreateGroup(name);
				if (typeof result !== "string" && !this.groups.some((group) => group.id === result.id)) this.groups = [...this.groups, result].sort((a, b) => a.name.localeCompare(b.name, "vi"));
				return result;
			},
			onClose: () => this.closeMenu()
		});
		this.menu = {
			instance: menu,
			anchor
		};
		anchor.setAttribute("aria-expanded", "true");
		menu.mount(place);
	}
	closeMenu() {
		const menu = this.menu;
		if (menu === null) return;
		this.menu = null;
		const scope = menu.instance.element.getRootNode();
		const focusInside = menu.instance.element.contains(scope.activeElement);
		menu.instance.destroy();
		menu.anchor.setAttribute("aria-expanded", "false");
		if (focusInside && menu.anchor.isConnected) menu.anchor.focus();
	}
	filtered() {
		const byKind = this.filter === "all" ? this.notes : this.notes.filter((note) => note.intent === (this.filter === "reminder" ? "REMINDER" : "TASK"));
		const byChip = this.groupFilter === null ? byKind : byKind.filter((note) => note.groupId === this.groupFilter);
		const query = this.searchInput.value.trim();
		return query === "" ? byChip : byChip.filter(queryMatcher(query));
	}
};
/**
* What a search matches, read the way the rest of ViSO reads a question.
*
* "tôi ghi gì về báo giá" searches for "báo giá", "lời nhắc tuần này" narrows
* to reminders written this week — the same parser the store's search uses,
* applied to notes already in hand. Accent-insensitive, because nobody types
* tone marks into a search box.
*/
function queryMatcher(query) {
	const spec = parseQuery(query);
	const terms = spec.terms.length > 0 ? spec.terms.map(fold) : spec.from === null && spec.intent === null ? [fold(query)] : [];
	return (note) => {
		if (spec.intent !== null && note.intent !== spec.intent) return false;
		if (spec.from !== null && note.createdAt < spec.from) return false;
		if (spec.to !== null && note.createdAt > spec.to) return false;
		const haystack = fold(`${note.text} ${note.selection ?? ""} ${note.sourceTitle ?? ""} ${note.groupName ?? ""}`);
		return terms.every((term) => haystack.includes(term));
	};
}
/** `đ` is its own letter, not d with a mark, so decomposition leaves it alone. */
function fold(value) {
	return value.normalize("NFD").replace(/\p{M}/gu, "").replace(/đ/gi, "d").toLowerCase();
}
/** Keystrokes typed into ViSO never reach the page's own shortcuts. */
function guardKeys(target) {
	for (const type of [
		"keydown",
		"keypress",
		"keyup"
	]) target.addEventListener(type, (event) => event.stopPropagation());
}
function iconButton(name, label) {
	const node = el("button", "hud__icon-btn");
	node.type = "button";
	node.title = label;
	node.setAttribute("aria-label", label);
	node.append(icon(name, 16));
	return node;
}
function el(tag, className) {
	const node = document.createElement(tag);
	node.className = className;
	return node;
}
function button(text, className) {
	const node = el("button", className);
	node.type = "button";
	node.textContent = text;
	return node;
}
//#endregion
//#region src/content/content.ts
/**
* Content script entry (spec §3). Read-only with respect to the page: the only
* DOM write is appending our own <viso-root> host element.
*/
function shouldInject() {
	if (window.top !== window.self) return false;
	if (!document.contentType.includes("html")) return false;
	if (location.protocol === "chrome-extension:") return false;
	return true;
}
async function main() {
	try {
		const stored = (await chrome.storage.local.get(LANG_KEY))[LANG_KEY];
		setLang(stored === "vi" || stored === "en" ? stored : browserLang());
	} catch {
		setLang(browserLang());
	}
	if (!shouldInject()) {
		log.debug("skipping injection for", location.href);
		return;
	}
	const world = globalThis;
	if (world.__visoContentStarted === true) return;
	world.__visoContentStarted = true;
	const host = ShadowHost.mount();
	if (host === null) return;
	/**
	* The most recent successful extraction. Saved memories carry it so a note
	* knows where it was written — a note with no source is far less useful when
	* it resurfaces.
	*/
	let lastContext = null;
	/** Where the HUD's notes come from right now: this site, or this document. */
	let currentScope = null;
	/**
	* The place where the user hid the HUD with × or Escape.
	*
	* It stays hidden there for the rest of the visit, instead of popping back the
	* next time the list refreshes. Leaving for another place clears it.
	*/
	let hiddenByUserFor = null;
	/**
	* The passage highlighted when a note is written.
	*
	* Watched continuously rather than read at save time: clicking into the HUD
	* moves focus, and on most pages that collapses the selection before any
	* handler could see what it was.
	*/
	const selection = new SelectionKeeper();
	selection.start();
	/**
	* The explanations, each shown once and only when it becomes true.
	*
	* Seen steps live in chrome.storage rather than per-site storage: being told
	* how ViSO works once is enough, not once per website.
	*/
	sendToBackground({ type: "viso/tab-zoom" }).then((res) => {
		if (res?.ok && res.zoom > 0) host.layer.style.setProperty("--viso-page-zoom", String(res.zoom));
	});
	const coach = new Coach(host.layer, {
		onDismiss: (step) => void chrome.storage.local.set({ [`viso:coach:${step}`]: true }),
		onOpenHub: () => window.open(chrome.runtime.getURL("src/agenthub/agenthub.html"), "_blank", "noopener")
	});
	const teachOnce = async (step) => {
		const key = `viso:coach:${step}`;
		try {
			if ((await chrome.storage.local.get(key))[key] === true) return;
			coach.show(step);
		} catch {}
	};
	const contextCard = new ContextCard(host.layer, {
		onDismiss: (memoryId) => {
			sendToBackground({
				type: "viso/dismiss-memory",
				memoryId
			});
		},
		onFeedback: (memoryId, feedback) => {
			sendToBackground({
				type: "viso/memory-feedback",
				memoryId,
				feedback
			});
		},
		onUndo: (memoryId) => {
			sendToBackground({
				type: "viso/undo-save",
				memoryId
			});
		},
		onOpenSource: (url) => {
			window.open(url, "_blank", "noopener,noreferrer");
		}
	});
	const panel = new QuickActionsPanel(host.layer, {
		onOpenHub: () => {
			sendToBackground({ type: "viso/open-hub" });
		},
		onVoice: () => {
			sendToBackground({ type: "viso/orb-summon" }).then((res) => {
				if (res === null || !res.ok) panel.showHint(orbUnavailableMessage(res?.reason ?? "offline"));
			});
		},
		loadNotes: () => {
			refreshScope(false);
		},
		onCollapsedChange: () => {},
		onDraftChange: (draft) => {
			if (composerScopeKey === null) return;
			keepDraft(composerScopeKey, draft);
		},
		onTrace: (event) => trace(event),
		onAutoShowChange: (mode) => {
			chrome.storage.local.set({ [AUTO_SHOW_KEY]: mode });
			setTimeout(() => applyAutoShow(mode, true), 700);
		},
		onViewChange: (view) => {
			chrome.storage.local.set({ [VIEW_KEY]: view }).then(() => refreshScope(false));
		},
		onClose: () => {
			hiddenByUserFor = currentScope?.key ?? null;
		},
		onDeleteNote: (uid) => {
			const memoryId = webNoteId(uid);
			if (memoryId === null) {
				sendToBackground({
					type: "viso/app-note",
					itemId: appNoteId(uid),
					verb: "delete"
				}).then((res) => {
					if (res === null || res.ok) return;
					panel.showHint(res.error ?? "Không xoá được ghi chú của app");
					refreshScope(false);
				});
				return;
			}
			sendToBackground({
				type: "viso/delete-memory",
				memoryId
			});
		},
		onEditNote: async (uid, text) => {
			const memoryId = webNoteId(uid);
			if (memoryId === null) {
				const res = await sendToBackground({
					type: "viso/app-note",
					itemId: appNoteId(uid),
					verb: "edit",
					text
				});
				if (res === null) return "Không sửa được — thử lại";
				return res.ok ? null : res.error ?? "Không sửa được ghi chú của app";
			}
			const res = await sendToBackground({
				type: "viso/edit-memory",
				memoryId,
				text
			});
			if (res === null) return "Không lưu được — thử lại";
			return res.ok ? null : res.error ?? "Không lưu được";
		},
		onLangChange: (lang) => {
			chrome.storage.local.set({ [LANG_KEY]: lang });
		},
		onSetDone: async (uid, done) => {
			const memoryId = webNoteId(uid);
			const res = memoryId === null ? await sendToBackground({
				type: "viso/app-note",
				itemId: appNoteId(uid),
				verb: done ? "done" : "undone"
			}) : await sendToBackground({
				type: "viso/set-done",
				memoryId,
				done
			});
			if (res === null) return "Không lưu được — thử lại";
			return res.ok ? null : res.error ?? "Không lưu được";
		},
		onSetDue: async (uid, when) => {
			const memoryId = webNoteId(uid);
			const res = memoryId === null ? await sendToBackground({
				type: "viso/app-note",
				itemId: appNoteId(uid),
				verb: "due",
				text: JSON.stringify(when)
			}) : await sendToBackground({
				type: "viso/set-due",
				memoryId,
				when
			});
			if (res === null) return "Không lưu được — thử lại";
			if (!res.ok) return res.error ?? "Không lưu được";
			refreshScope(false);
			return null;
		},
		onOpenNote: (url, uid, newTab) => {
			if (newTab) {
				window.open(url, "_blank", "noopener,noreferrer");
				return;
			}
			rememberFollowedNote(uid);
			rememberPanelState("");
			panel.highlight(uid);
			window.location.href = url;
		},
		onCreateGroup: async (name) => {
			const res = await sendToBackground({
				type: "viso/create-group",
				name
			});
			if (res === null) return "Không tạo được nhóm — thử lại";
			if (!res.ok) return res.error;
			refreshGroups();
			return res.group;
		},
		onSetNoteGroup: async (uid, groupId) => {
			const memoryId = webNoteId(uid);
			if (memoryId === null) {
				const name = groupId === null ? "" : panel.groupName(groupId) ?? "";
				const reply = await sendToBackground({
					type: "viso/app-note",
					itemId: appNoteId(uid),
					verb: "group",
					text: name
				});
				if (reply === null) return "Không đổi được nhóm — thử lại";
				if (!reply.ok) return reply.error ?? "Không đổi được nhóm của ghi chú app";
				return null;
			}
			const res = await sendToBackground({
				type: "viso/set-note-group",
				memoryId,
				groupId
			});
			if (res === null) return "Không đổi được nhóm — thử lại";
			if (!res.ok) return res.error ?? "Không đổi được nhóm";
			refreshGroups();
			return null;
		},
		onComposerGroupChange: (groupId) => {
			if (currentScope !== null) rememberLastGroup(currentScope.key, groupId);
		},
		onOpenAll: () => {
			window.open(chrome.runtime.getURL("src/agenthub/agenthub.html"), "_blank", "noopener");
		},
		onSave: (intent, text, remindAt, onContext, repeat, groupId) => {
			const remindOnContext = onContext ? lastContext?.context_hash ?? null : null;
			sendToBackground({
				type: "viso/save-memory",
				intent,
				text,
				context: lastContext,
				remindAt,
				remindOnContext,
				selection: selection.take(),
				repeat,
				groupId
			}).then((res) => {
				if (res === null) {
					log.warn("save failed: background did not respond");
					return;
				}
				if (!res.ok) {
					log.error("save failed:", res.error);
					panel.showHint(`Không lưu được: ${res.error}`);
					return;
				}
				teachOnce("saved");
				hiddenByUserFor = null;
				refreshScope(true);
				contextCard.showSaved({
					id: res.memoryId,
					text,
					sourceTitle: lastContext?.title ?? null,
					deepLink: null,
					createdAt: Date.now(),
					intent,
					remindAt,
					repeat
				});
				log.debug("saved", res.memoryId);
			});
		}
	});
	let hudTop = 72;
	/**
	* Where the HUD actually sits: the user's choice, unless the open panel
	* would run off the bottom of the window — then it is lifted just enough to
	* fit, and put back where it was when it collapses. The tab can be dragged
	* to the very bottom; the panel opening from there used to be a sliver
	* squeezed against the window's edge, scrolling inside itself.
	*/
	const fit = () => {
		const height = host.layer.getBoundingClientRect().height;
		const room = window.innerHeight - 8;
		const top = height > 0 && hudTop + height > room ? Math.max(8, room - height) : hudTop;
		host.setTop(top);
	};
	const applyTop = (top) => {
		hudTop = clampTop(top, window.innerHeight);
		host.layer.style.setProperty("--viso-hud-top", `${hudTop}px`);
		fit();
	};
	if (typeof ResizeObserver !== "undefined") new ResizeObserver(() => fit()).observe(host.layer);
	window.addEventListener("resize", fit);
	const restoreTop = () => {
		loadTopRatio().then((ratio) => applyTop(ratio === null ? 72 : ratio * window.innerHeight));
	};
	applyTop(72);
	restoreTop();
	makeVerticalDrag({
		handle: panel.dragHandle,
		currentTop: () => hudTop,
		onMove: applyTop,
		onDropped: (top) => saveTopRatio(top / Math.max(1, window.innerHeight))
	});
	let resizeTimer = null;
	window.addEventListener("resize", () => {
		if (resizeTimer !== null) clearTimeout(resizeTimer);
		resizeTimer = setTimeout(() => {
			resizeTimer = null;
			restoreTop();
		}, 150);
	}, { passive: true });
	/**
	* Loads this place's notes, and — when `auto` — shows or hides the HUD for them.
	*
	* `auto` is set after a navigation or a save. It shows the HUD only when the
	* place has notes, and only if the user has not hidden it here; it never takes
	* focus, and it restores the collapsed state the user left for this place.
	* Without `auto`, the list is refreshed and visibility is left to whoever
	* opened it.
	*
	* Replies can arrive out of order across fast navigations, so each call is
	* numbered and only the newest one is allowed to touch the HUD.
	*/
	let scopeRequest = 0;
	/** The place whose remembered group the composer shows. */
	let composerScopeKey = null;
	const refreshGroups = async () => {
		const res = await sendToBackground({ type: "viso/groups" });
		if (res !== null) panel.setGroups(res.groups);
	};
	const refreshScope = async (auto) => {
		const context = lastContext;
		const scope = context === null ? null : scopeFor(context.platform_type, context.context_hash, context.source_url);
		const request = ++scopeRequest;
		if (context === null || scope === null) return;
		const view = await hudView();
		panel.setView(view);
		const [res, groups, lastGroup] = await Promise.all([
			view.scope === "all" ? sendToBackground({
				type: "viso/all-notes",
				limit: 200
			}) : sendToBackground({
				type: "viso/scope-notes",
				platform_type: context.platform_type,
				context_hash: context.context_hash,
				source_url: context.source_url,
				limit: 200
			}),
			sendToBackground({ type: "viso/groups" }),
			composerScopeKey === scope.key ? Promise.resolve(null) : lastGroupFor(scope.key)
		]);
		if (request !== scopeRequest || res === null) return;
		if (groups !== null) panel.setGroups(groups.groups);
		if (composerScopeKey !== scope.key) {
			composerScopeKey = scope.key;
			panel.setComposerGroup(lastGroup);
			takeDraft(scope.key).then((draft) => {
				if (draft !== null && composerScopeKey === scope.key) panel.restoreDraft(draft);
			});
		}
		panel.setScopeLabel(view.scope === "all" ? "Tất cả trang" : scopeLabel(scope, context.platform_type, context.source_url, context.title), sourceLabel(context.platform_type, context.source_url));
		panel.setCurrentContext(context.context_hash, context.source_url);
		panel.setNotes(res.notes.map((note) => ({
			...note,
			id: note.uid,
			favicon: faviconFor(note.sourceUrl ?? note.deepLink ?? null)
		})), takeFollowedNote());
		if (res.notes.length >= 2) teachOnce("places");
		if (!auto || hiddenByUserFor === scope.key) return;
		const mode = await autoShowMode();
		if (request !== scopeRequest) return;
		trace(`refreshScope auto mode=${mode} notes=${res.notes.length}`);
		panel.setAutoShow(mode);
		if (mode === "off") return;
		panel.showAuto(mode === "tab");
	};
	/**
	* A new mode applied to a HUD already on screen. Only one ViSO put there
	* itself moves: a HUD the user opened is theirs, whatever the setting.
	*/
	const applyAutoShow = (mode, chosenHere = false) => {
		panel.setAutoShow(mode);
		if (!chosenHere && !panel.wasAutoShown) return;
		if (mode === "off") panel.close();
		else if (mode === "tab") panel.setCollapsed(true, false);
	};
	try {
		chrome.storage.onChanged.addListener((changes, area) => {
			if (area !== "local" || !(AUTO_SHOW_KEY in changes)) return;
			const mode = changes[AUTO_SHOW_KEY]?.newValue;
			applyAutoShow(mode === "tab" || mode === "off" ? "tab" : "open");
		});
	} catch {}
	chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
		if (!isBackgroundPush(message)) return;
		switch (message.type) {
			case "viso/current-context":
				sendResponse({ context: lastContext });
				break;
			case "viso/notes-changed":
				hiddenByUserFor = null;
				if (message.highlightId !== null) panel.highlight(`ext:${message.highlightId}`);
				refreshScope(true);
				break;
			case "viso/orb-unavailable":
				panel.showHint(orbUnavailableMessage(message.reason));
				break;
			case "viso/dot-badge": break;
			case "viso/context-card":
				autoShowMode().then((mode) => {
					if (mode === "open") contextCard.show(message.memory);
				});
				break;
			case "viso/zoom":
				host.layer.style.setProperty("--viso-page-zoom", String(message.zoom > 0 ? message.zoom : 1));
				break;
			case "viso/show-note":
				hiddenByUserFor = null;
				panel.open(false);
				panel.highlight(message.uid);
				break;
			case "viso/toggle-panel":
				panel.toggle();
				if (panel.isOpen) hiddenByUserFor = null;
				if (panel.isOpen && composerScopeKey !== null) takeDraft(composerScopeKey).then((draft) => {
					if (draft !== null) panel.restoreDraft(draft);
				});
		}
	});
	const observer = new ContextObserver({ onChange: (event) => {
		contextCard.hide();
		coach.hide();
		selection.clear();
		whenIdle(() => {
			const extraction = extractContext(document, event.url);
			if (extraction.ok) lastContext = extraction.context;
			else {
				lastContext = minimalContext(event.url, document.title);
				log.debug("extraction produced nothing:", extraction.reason, "— keeping url + title");
			}
			sendToBackground({
				type: "viso/context-changed",
				url: event.url,
				title: event.title,
				reason: event.reason,
				signature: event.signature,
				extraction
			});
			const nextScope = scopeFor(lastContext.platform_type, lastContext.context_hash, lastContext.source_url);
			if ((nextScope?.key ?? null) !== (currentScope?.key ?? null)) {
				panel.close();
				currentScope = nextScope;
				hiddenByUserFor = null;
			}
			const carried = takePanelState();
			if (carried !== null) {
				const followed = takeFollowedNote();
				if (followed !== null) panel.highlight(followed);
				autoShowMode().then((mode) => {
					if (mode === "open") panel.reopenWith(carried);
				});
			}
			refreshScope(true);
		});
	} });
	observer.start();
	window.addEventListener("pagehide", () => {
		observer.stop();
		selection.stop();
		host.dispose();
	}, { once: true });
	teachOnce("welcome");
	sendToBackground({
		type: "viso/hello",
		url: location.href
	}).then((res) => {
		if (res === null) {
			log.warn("background did not respond to hello");
			return;
		}
		log.info("connected, protocol v" + res.protocolVersion);
	});
}
/** URL + title only, for attributing a saved memory to the page it came from. */
function minimalContext(url, title) {
	return {
		title: title.trim(),
		body: "",
		entities: [],
		entity_refs: [],
		source_url: url,
		deep_link: url,
		platform_type: "generic",
		timestamp: Date.now(),
		confidence: 0,
		context_hash: fnv1a(url),
		extractor: "minimal@1"
	};
}
/**
* The note whose link was followed, carried across one navigation.
*
* sessionStorage is per-tab and survives a page load, which is exactly the
* lifetime needed. Wrapped because sites can block storage access outright, and
* losing a highlight is not worth an exception on someone's page.
*/
var FOLLOWED_KEY = "viso:followed-note";
var PANEL_KEY = "viso:panel-open";
/**
* Whether the panel was open across a navigation, and what was in it.
*
* sessionStorage: per tab, survives a page load, gone when the tab closes —
* exactly the lifetime of "I was in the middle of something here".
*/
function rememberPanelState(draft) {
	try {
		sessionStorage.setItem(PANEL_KEY, draft);
	} catch {}
}
/** Reads and clears: the panel reopens once, not on every later load. */
function takePanelState() {
	try {
		const draft = sessionStorage.getItem(PANEL_KEY);
		if (draft === null) return null;
		sessionStorage.removeItem(PANEL_KEY);
		return draft;
	} catch {
		return null;
	}
}
function rememberFollowedNote(uid) {
	try {
		sessionStorage.setItem(FOLLOWED_KEY, uid);
	} catch {}
}
/** Reads and clears — a highlight is for the arrival, not for every reopen. */
function takeFollowedNote() {
	try {
		const uid = sessionStorage.getItem(FOLLOWED_KEY);
		if (uid === null) return null;
		sessionStorage.removeItem(FOLLOWED_KEY);
		return uid;
	} catch {
		return null;
	}
}
/**
* The store a row belongs to, from its id.
*
* `ext:<id>` is this browser's own note and the background can act on it;
* `app:<id>` belongs to the desktop app, which owns editing and deleting it.
*/
/** The app's own id, from a row keyed `app:<id>`. */
function appNoteId(uid) {
	return uid.startsWith("app:") ? uid.slice(4) : uid;
}
function webNoteId(uid) {
	if (!uid.startsWith("ext:")) return null;
	const id = Number(uid.slice(4));
	return Number.isFinite(id) ? id : null;
}
/**
* Places where the user collapsed the HUD.
*
* chrome.storage, keyed by scope ("site:mail.google.com", "file:<hash>"), so
* collapsing Gmail stays collapsed on the next visit and on every device tab,
* without touching any other place. Capped, newest kept, so years of documents
* cannot grow it without bound.
*/
/** How the list is looked at; see HudView. One setting for every site. */
var VIEW_KEY = "viso:hud-view";
var LANG_KEY = "viso:lang";
async function hudView() {
	try {
		const stored = (await chrome.storage.local.get(VIEW_KEY))[VIEW_KEY];
		return {
			scope: stored?.scope === "all" ? "all" : "here",
			groupBy: stored?.groupBy === "kind" || stored?.groupBy === "group" ? stored.groupBy : "none"
		};
	} catch {
		return { ...DEFAULT_VIEW };
	}
}
/** How the HUD arrives on a page; see AutoShowMode. One setting for every site. */
var AUTO_SHOW_KEY = "viso:hud-auto-show";
async function autoShowMode() {
	try {
		const mode = (await chrome.storage.local.get(AUTO_SHOW_KEY))[AUTO_SHOW_KEY];
		return mode === "tab" || mode === "off" ? "tab" : "open";
	} catch {
		return "open";
	}
}
/**
* Drafts, one per place, in chrome.storage.local — they survive a tab closing
* and the browser restarting, which is the whole point. Written a beat after
* the last keystroke, not on each one.
*/
var DRAFT_PREFIX = "viso:draft:";
var draftTimer = null;
function keepDraft(scopeKey, draft) {
	if (draftTimer !== null) clearTimeout(draftTimer);
	draftTimer = setTimeout(() => {
		draftTimer = null;
		const key = DRAFT_PREFIX + scopeKey;
		try {
			if (draft === null) chrome.storage.local.remove(key);
			else chrome.storage.local.set({ [key]: draft });
		} catch {}
	}, 300);
}
async function takeDraft(scopeKey) {
	try {
		const key = DRAFT_PREFIX + scopeKey;
		const stored = (await chrome.storage.local.get(key))[key];
		return stored !== void 0 && typeof stored.text === "string" ? stored : null;
	} catch {
		return null;
	}
}
/** The site's icon for a card, through the extension's favicon service — nothing is fetched from the page. */
function faviconFor(url) {
	if (url === null || !/^https?:/i.test(url)) return null;
	try {
		const src = new URL(chrome.runtime.getURL("/_favicon/"));
		src.searchParams.set("pageUrl", url);
		src.searchParams.set("size", "32");
		return src.toString();
	} catch {
		return null;
	}
}
/**
* The last forty times the HUD came on screen, with why, in chrome.storage —
* readable after the fact when someone says "it opened on its own" and it
* cannot be made to happen while anyone is watching.
*/
var TRACE_KEY = "viso:trace";
var traceLines = [];
var traceTimer = null;
function trace(event) {
	traceLines.push(`${(/* @__PURE__ */ new Date()).toISOString().slice(11, 19)} ${location.hostname} ${event}`);
	traceLines = traceLines.slice(-40);
	if (traceTimer !== null) clearTimeout(traceTimer);
	traceTimer = setTimeout(() => {
		traceTimer = null;
		try {
			chrome.storage.local.get(TRACE_KEY).then((stored) => {
				const previous = Array.isArray(stored[TRACE_KEY]) ? stored[TRACE_KEY] : [];
				chrome.storage.local.set({ [TRACE_KEY]: [...previous, ...traceLines.splice(0)].slice(-60) });
			});
		} catch {}
	}, 500);
}
/**
* The group last chosen in the composer, per place.
*
* Same keys and cap as the collapsed map. Someone writing about one client in
* one Gmail thread keeps that client; another site starts with no group rather
* than inheriting one it has nothing to do with.
*/
var LAST_GROUP_KEY = "viso:hud-group";
var LAST_GROUP_LIMIT = 300;
async function lastGroupFor(key) {
	try {
		const entry = (await chrome.storage.local.get(LAST_GROUP_KEY))[LAST_GROUP_KEY]?.[key];
		return Array.isArray(entry) && typeof entry[0] === "number" ? entry[0] : null;
	} catch {
		return null;
	}
}
async function rememberLastGroup(key, groupId) {
	try {
		const map = { ...(await chrome.storage.local.get(LAST_GROUP_KEY))[LAST_GROUP_KEY] };
		if (groupId === null) delete map[key];
		else map[key] = [groupId, Date.now()];
		const kept = Object.entries(map).sort((a, b) => b[1][1] - a[1][1]).slice(0, LAST_GROUP_LIMIT);
		await chrome.storage.local.set({ [LAST_GROUP_KEY]: Object.fromEntries(kept) });
	} catch {}
}
/** Where to get the desktop app, for the one thing the extension cannot do without it. */
var DESKTOP_DOWNLOAD = "github.com/nhanho133/Viso-releases";
function orbUnavailableMessage(reason) {
	switch (reason) {
		case "mismatch": return "App ViSO trên máy và extension khác phiên bản — cập nhật cả hai.";
		case "no-page": return "Trang này không cho ViSO ghi chú.";
		default: return `Mở app ViSO trên máy tính để nói. Chưa cài? Tải tại ${DESKTOP_DOWNLOAD}`;
	}
}
/** requestIdleCallback where available; Safari and older engines fall back. */
function whenIdle(task) {
	if (typeof requestIdleCallback === "function") requestIdleCallback(() => task(), { timeout: 2e3 });
	else setTimeout(task, 0);
}
main();
//#endregion
